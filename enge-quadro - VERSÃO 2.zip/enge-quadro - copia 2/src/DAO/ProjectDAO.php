<?php
// src/DAO/ProjectDAO.php

require_once __DIR__ . '/../Models/Database.php';

class ProjectDAO {
    
    /**
     * Vai buscar todos os representantes comerciais ativos
     * SINCRO: ALIAS (nome AS name) para bater certo com a linha 215 do home.php
     */
    public function getAllActiveCommercials() {
        try {
            $db = Database::getConnection();
            $stmt = $db->query("SELECT id, name, phone FROM commercial_reps WHERE active = 1");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * Vai buscar todos os projetos ativos ligando apenas com os comerciais
     */
    public function getAllProjects() {
        try {
            $db = Database::getConnection();
            $sql = "SELECT p.*, c.name as commercial_name FROM projects p JOIN commercial_reps c ON p.commercial_id = c.id ORDER BY p.created_at DESC";
            $stmt = $db->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * Cria um novo projeto básico
     */
    public function createProject($projectName, $client, $commercialId) {
        try {
            $db = Database::getConnection();
            $sql = "INSERT INTO projects (project_name, client, commercial_id) VALUES (:name, :client, :commercial_id)";
            $stmt = $db->prepare($sql);
            return $stmt->execute([
                'name' => $projectName,
                'client' => $client,
                'commercial_id' => $commercialId
            ]);
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Elimina um projeto e limpa os quadros associados
     */
    public function deleteProject($projectId) {
        try {
            $db = Database::getConnection();
            $stmt1 = $db->prepare("DELETE FROM switchboards WHERE project_id = :id");
            $stmt1->execute(['id' => $projectId]);
            $stmt2 = $db->prepare("DELETE FROM projects WHERE id = :id");
            return $stmt2->execute(['id' => $projectId]);
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Listar todos os quadros de um projeto específico
     */
    public function getSwitchboardsByProject($projectId) {
        try {
            $db = Database::getConnection();
            $stmt = $db->prepare("SELECT id, board_name FROM switchboards WHERE project_id = :project_id ORDER BY id ASC");
            $stmt->execute(['project_id' => $projectId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * Inserir um novo quadro elétrico
     */
    public function createSwitchboard($projectId, $boardName) {
        try {
            $db = Database::getConnection();
            $stmt = $db->prepare("INSERT INTO switchboards (project_id, board_name) VALUES (:project_id, :board_name)");
            return $stmt->execute([
                'project_id' => $projectId,
                'board_name' => $boardName
            ]);
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Eliminar um quadro elétrico permanentemente
     */
    public function deleteSwitchboard($boardId) {
        try {
            $db = Database::getConnection();
            $stmt = $db->prepare("DELETE FROM switchboards WHERE id = :id");
            return $stmt->execute(['id' => $boardId]);
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * RESTAURADO: Vai buscar todas as marcas disponíveis
     */
    public function getBrands() {
        try {
            $db = Database::getConnection();
            $stmt = $db->query("SELECT id, name FROM brands ORDER BY name ASC");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * RESTAURADO: Vai buscar categorias dependendo do parent_id
     */
    public function getCategoriesByParent($parentId = null) {
        try {
            $db = Database::getConnection();
            if ($parentId === null) {
                $stmt = $db->prepare("SELECT id, nome FROM categories WHERE parent_id IS NULL ORDER BY nome ASC");
                $stmt->execute();
            } else {
                $stmt = $db->prepare("SELECT id, nome FROM categories WHERE parent_id = :parent_id ORDER BY nome ASC");
                $stmt->execute(['parent_id' => $parentId]);
            }
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * Constrói a árvore de marcas filtrando subcategorias vazias
     */
    public function getCatalogTree() {
        try {
            $db = Database::getConnection();
            $brands = $db->query("SELECT id, name FROM brands ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
            $categories = $db->query("SELECT id, nome, parent_id FROM categories ORDER BY nome ASC")->fetchAll(PDO::FETCH_ASSOC);
            $relations = $db->query("SELECT DISTINCT brand_id, category_id FROM products")->fetchAll(PDO::FETCH_ASSOC);

            $validRelations = [];
            foreach ($relations as $rel) {
                $validRelations[$rel['brand_id']][$rel['category_id']] = true;
            }

            $mainCategories = [];
            $subCategoriesByParent = [];
            foreach ($categories as $cat) {
                if ($cat['parent_id'] === null || $cat['parent_id'] == 0) {
                    $mainCategories[] = $cat;
                } else {
                    $subCategoriesByParent[$cat['parent_id']][] = $cat;
                }
            }

            $catalogTree = [];
            foreach ($brands as $brand) {
                $brandNode = ['id' => $brand['id'], 'name' => $brand['name'], 'families' => []];
                foreach ($mainCategories as $mainCat) {
                    $subs = $subCategoriesByParent[$mainCat['id']] ?? [];
                    $filteredSubs = [];
                    foreach ($subs as $sub) {
                        if (isset($validRelations[$brand['id']][$sub['id']])) {
                            $filteredSubs[] = $sub;
                        }
                    }
                    if (!empty($filteredSubs)) {
                        $brandNode['families'][] = [
                            'id' => $mainCat['id'],
                            'nome' => $mainCat['nome'],
                            'subcategories' => $filteredSubs
                        ];
                    }
                }
                if (!empty($brandNode['families'])) {
                    $catalogTree[] = $brandNode;
                }
            }
            return $catalogTree;
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * Puxa os produtos filtrando estritamente por Categoria E por Marca
     */
    public function getProductsByCategory($categoryId = null, $brandId = null) {
        try {
            $db = Database::getConnection();
            if ($categoryId && $brandId) {
                $stmt = $db->prepare("
                    SELECT p.id, b.name AS marca, p.referencia, p.descricao 
                    FROM products p
                    LEFT JOIN brands b ON p.brand_id = b.id
                    WHERE p.category_id = :category_id AND p.brand_id = :brand_id
                    ORDER BY p.referencia ASC
                ");
                $stmt->execute(['category_id' => $categoryId, 'brand_id' => $brandId]);
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            if ($categoryId) {
                $stmt = $db->prepare("
                    SELECT p.id, b.name AS marca, p.referencia, p.descricao 
                    FROM products p
                    LEFT JOIN brands b ON p.brand_id = b.id
                    WHERE p.category_id = :category_id
                    ORDER BY p.referencia ASC
                ");
                $stmt->execute(['category_id' => $categoryId]);
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            $stmt = $db->query("
                SELECT p.id, b.name AS marca, p.referencia, p.descricao 
                FROM products p
                LEFT JOIN brands b ON p.brand_id = b.id
                ORDER BY p.referencia ASC 
                LIMIT 50
            ");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * Lista os produtos com base na categoria/subcategoria e marca selecionadas
     */
    public function getProductsByCategoryAndBrand($categoryId, $brandId) {
        try {
            $db = Database::getConnection();
            $sql = "SELECT p.id, p.referencia, p.descricao, b.name as marca 
                    FROM products p
                    JOIN brands b ON p.brand_id = b.id
                    WHERE p.category_id = :category_id AND p.brand_id = :brand_id
                    ORDER BY p.referencia ASC";
            $stmt = $db->prepare($sql);
            $stmt->execute(['category_id' => $categoryId, 'brand_id' => $brandId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * Descobre quais os atributos técnicos e valores distintos para a Subfamília.
     */
    public function getAttributesBySubfamily($categoryId, $brandId) {
        try {
            $db = Database::getConnection();
            $sql = "SELECT a.id AS atributo_id, a.nome_atributo, pv.valor AS valor_atributo 
                    FROM product_values pv
                    JOIN attributes a ON pv.attribute_id = a.id
                    JOIN products p ON pv.product_id = p.id
                    WHERE p.category_id = :category_id AND p.brand_id = :brand_id
                    ORDER BY a.nome_atributo ASC, pv.valor ASC";
            $stmt = $db->prepare($sql);
            $stmt->execute(['category_id' => $categoryId, 'brand_id' => $brandId]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $attributes = [];
            foreach ($rows as $row) {
                $attrId = $row['atributo_id'];
                if (!isset($attributes[$attrId])) {
                    $attributes[$attrId] = ['id' => $attrId, 'nome' => $row['nome_atributo'], 'valores' => []];
                }
                if (!in_array($row['valor_atributo'], $attributes[$attrId]['valores'])) {
                    $attributes[$attrId]['valores'][] = $row['valor_atributo'];
                }
            }
            return array_values($attributes);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * INTERSEÇÃO EAV: Procura o produto único baseado nas tuas colunas reais.
     */
    public function getProductByExactAttributes($categoryId, $brandId, array $filters) {
        try {
            $db = Database::getConnection();
            if (empty($filters)) return null;
            $sql = "SELECT p.id, p.referencia, p.descricao, b.name AS marca FROM products p 
                    JOIN brands b ON p.brand_id = b.id JOIN product_values pv ON p.id = pv.product_id 
                    WHERE p.category_id = :category_id AND p.brand_id = :brand_id AND (";
            $orConditions = []; $params = ['category_id' => $categoryId, 'brand_id' => $brandId];
            $i = 0;
            foreach ($filters as $attrId => $value) {
                $orConditions[] = "(pv.attribute_id = :attr_$i AND pv.valor = :val_$i)";
                $params["attr_$i"] = $attrId; $params["val_$i"] = $value; $i++;
            }
            $sql .= implode(" OR ", $orConditions) . ") GROUP BY p.id HAVING COUNT(DISTINCT pv.attribute_id) = :filter_count";
            $params['filter_count'] = count($filters);
            $stmt = $db->prepare($sql); $stmt->execute($params);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return null;
        }
    }

    /**
     * Fornece os valores técnicos válidos remanescentes para o sistema de travas.
     */
    public function getValidOptions($categoryId, $brandId, array $filters) {
        try {
            $db = Database::getConnection();
            if (empty($filters)) {
                $subQuery = "SELECT id FROM products WHERE category_id = :category_id AND brand_id = :brand_id";
                $params = ['category_id' => $categoryId, 'brand_id' => $brandId];
            } else {
                $subQuery = "SELECT p.id FROM products p JOIN product_values pv ON p.id = pv.product_id WHERE p.category_id = :category_id AND p.brand_id = :brand_id AND (";
                $orConditions = []; $params = ['category_id' => $categoryId, 'brand_id' => $brandId]; $i = 0;
                foreach ($filters as $attrId => $value) {
                    $orConditions[] = "(pv.attribute_id = :attr_$i AND pv.valor = :val_$i)";
                    $params["attr_$i"] = $attrId; $params["val_$i"] = $value; $i++;
                }
                $subQuery .= implode(" OR ", $orConditions) . ") GROUP BY p.id HAVING COUNT(DISTINCT pv.attribute_id) = :filter_count";
                $params['filter_count'] = count($filters);
            }
            $stmt = $db->prepare("SELECT DISTINCT pv2.attribute_id, pv2.valor FROM product_values pv2 WHERE pv2.product_id IN ($subQuery)");
            $stmt->execute($params);
            $validOptions = [];
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $validOptions[$row['attribute_id']][] = $row['valor'];
            }
            return $validOptions;
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * Grava um artigo no Quadro (Board)
     */
    public function addProductToBoard($boardId, $productId, $qty) {
        try {
            $db = Database::getConnection();
            $stmtCheck = $db->prepare("SELECT id, quantity FROM board_items WHERE board_id = :board_id AND product_id = :product_id");
            $stmtCheck->execute(['board_id' => $boardId, 'product_id' => $productId]);
            $existing = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                return $db->prepare("UPDATE board_items SET quantity = :qty WHERE id = :id")->execute(['qty' => $existing['quantity'] + $qty, 'id' => $existing['id']]);
            } else {
                return $db->prepare("INSERT INTO board_items (board_id, product_id, quantity) VALUES (:board_id, :product_id, :qty)")->execute(['board_id' => $boardId, 'product_id' => $productId, 'qty' => $qty]);
            }
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Puxa os artigos alocados a um Quadro específico
     */
    public function getItemsFromBoard($boardId) {
        try {
            $db = Database::getConnection();
            $sql = "SELECT bi.quantity, p.referencia, p.descricao, p.pvp, b.name AS marca
                    FROM board_items bi
                    JOIN products p ON bi.product_id = p.id
                    JOIN brands b ON p.brand_id = b.id
                    WHERE bi.board_id = :board_id ORDER BY bi.id ASC";
            $stmt = $db->prepare($sql);
            $stmt->execute(['board_id' => $boardId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }


    /**
     * ADICIONADO: Remove um item do quadro baseado no ID da linha de junção
     */
    public function removeItemFromBoard($itemId) {
        try {
            $db = Database::getConnection();
            $stmt = $db->prepare("DELETE FROM board_items WHERE id = :id");
            return $stmt->execute(['id' => $itemId]);
        } catch (PDOException $e) {
            return false;
        }
    }
}
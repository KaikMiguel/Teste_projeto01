<!DOCTYPE html>
<html class="light" lang="pt-pt">
<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Levantamento de Material | Enge-Quadros</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet" />
    
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "on-secondary-fixed-variant": "#394d00", "tertiary": "#4f6300", "surface-container-high": "#ebe7e6",
                        "on-secondary-container": "#526b14", "inverse-primary": "#c7c7c1", "background": "#fcf8f7",
                        "outline": "#767872", "surface-bright": "#fcf8f7", "secondary-container": "#cdeb87",
                        "on-secondary-fixed": "#151f00", "on-surface": "#1c1b1b", "primary-fixed": "#e3e3dd",
                        "surface-container-highest": "#e5e2e0", "surface-container": "#f1edec", "on-background": "#1c1b1b",
                        "secondary": "#4e660f", "on-primary-container": "#fdfdf7", "on-tertiary-fixed": "#161e00",
                        "secondary-fixed": "#d0ee89", "primary-fixed-dim": "#c7c7c1", "error-container": "#ffdad6",
                        "primary-container": "#747570", "surface-variant": "#e5e2e0", "surface-tint": "#5d5f5a",
                        "on-primary": "#ffffff", "tertiary-fixed-dim": "#abd600", "secondary-fixed-dim": "#b4d170",
                        "on-error-container": "#93000a", "on-surface-variant": "#454742", "error": "#ba1a1a",
                        "surface-dim": "#ddd9d8", "on-primary": "#ffffff", "tertiary-container": "#647e00",
                        "surface-container-low": "#f7f3f1", "tertiary-fixed": "#c5f31b", "on-primary-fixed-variant": "#464743",
                        "primary": "#5b5c58", "outline-variant": "#c6c7c0", "on-error": "#ffffff", "surface-container-lowest": "#ffffff",
                        "on-secondary": "#ffffff", "on-primary-fixed": "#1a1c19", "inverse-on-surface": "#f4f0ef",
                        "inverse-surface": "#313030", "surface": "#fcf8f7", "on-tertiary-container": "#fbffe4",
                        "on-tertiary-fixed-variant": "#3c4d00"
                    },
                    "borderRadius": { "DEFAULT": "0.125rem", "lg": "0.25rem", "xl": "0.5rem", "full": "0.75rem" },
                    "spacing": { "unit": "4px", "sm": "8px", "md": "16px", "xl": "48px", "margin": "24px", "xs": "4px", "gutter": "16px", "lg": "24px" },
                    "fontFamily": { "body-md": ["Inter"], "mono-sm": ["monospace"], "headline-sm": ["Inter"], "label-md": ["Inter"], "body-lg": ["Inter"], "headline-md": ["Inter"], "headline-lg": ["Inter"] },
                    "fontSize": { "body-md": ["14px", { "lineHeight": "1.5", "fontWeight": "400" }], "mono-sm": ["12px", { "lineHeight": "1", "fontWeight": "400" }], "headline-sm": ["18px", { "lineHeight": "1.4", "fontWeight": "600" }], "label-md": ["12px", { "lineHeight": "1", "letterSpacing": "0.05em", "fontWeight": "500" }], "body-lg": ["16px", { "lineHeight": "1.6", "fontWeight": "400" }], "headline-md": ["24px", { "lineHeight": "1.2", "letterSpacing": "-0.01em", "fontWeight": "600" }], "headline-lg": ["32px", { "lineHeight": "1.2", "letterSpacing": "-0.02em", "fontWeight": "600" }] }
                }
            }
        }
    </script>
    <style>
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #c6c7c0; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #767872; }
        .rotate-icon { transition: transform 0.2s ease; }
        .collapsed .rotate-icon { transform: rotate(-90deg); }
        .filter-list-item { cursor: pointer; transition: all 0.15s ease; }
        .filter-list-item:hover { background-color: #f1edec; }
        .filter-list-item.active { background-color: #4e660f; color: white; font-weight: 500; }
    </style>
</head>

<body class="bg-background text-on-background font-body-md text-body-md min-h-screen flex flex-col antialiased overflow-hidden">

    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 border-b border-[#e1e2df] dark:border-stone-800">
        <div class="flex items-center gap-md">
            <span class="text-lg font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>
        </div>

        <div class="flex items-center gap-sm">
            <button class="flex items-center gap-2 px-3 py-1.5 text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 border border-transparent hover:border-stone-200 transition-all duration-200 rounded-lg group" title="Guardar Alterações">
                <span class="material-symbols-outlined text-[20px] group-active:scale-90 transition-transform">save</span>
                <span class="text-[11px] font-bold uppercase tracking-widest">Guardar</span>
            </button>

            <button class="p-sm text-[#82837e] dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors active:opacity-80 rounded-full">
                <span class="material-symbols-outlined text-[24px]">notifications</span>
            </button>

            <a href="/enge-quadro/home" class="ml-sm w-9 h-9 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-[#94b053] hover:border-[#94b053] hover:bg-white transition-all duration-200 shadow-sm">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">home</span>
            </a>
        </div>
    </header>

    <div class="flex pt-16 flex-1 h-screen overflow-hidden">
        
        <?php require_once __DIR__ . '/sideMenu/sidebarGeneral.php'; ?>

        <div class="flex-1 flex ml-64 h-full overflow-hidden">
            
            <main class="flex-1 flex h-full overflow-hidden bg-surface">
                
                <section id="catalogSidebar" class="w-[260px] flex-shrink-0 bg-surface-container-lowest border-r border-outline-variant flex flex-col h-full overflow-hidden">
                    <div class="p-md border-b border-outline-variant flex items-center justify-between">
                        <h2 class="font-label-md text-label-md text-on-surface-variant uppercase tracking-wider font-bold">Catálogo</h2>
                        <button class="text-outline hover:text-on-surface"><span class="material-symbols-outlined text-[18px]">filter_list</span></button>
                    </div>
                    <div class="flex-1 overflow-y-auto p-sm">
                        <ul class="flex flex-col gap-xs">
                            <?php if (empty($catalogTree)): ?>
                                <p class="text-xs text-outline italic p-2">Nenhum catálogo registado.</p>
                            <?php else: ?>
                                <?php foreach ($catalogTree as $brand): ?>
                                    <li class="mb-1 brand-container" id="brand-box-<?php echo $brand['id']; ?>">
                                        <button onclick="toggleBrand(<?php echo $brand['id']; ?>)" class="w-full flex items-center gap-sm px-2 py-1.5 text-on-surface font-bold text-sm tracking-wide hover:bg-surface-container-low rounded transition-colors focus:outline-none">
                                            <span class="material-symbols-outlined text-[16px] text-outline rotate-icon brand-icon">expand_more</span>
                                            <span><?php echo htmlspecialchars($brand['name']); ?></span>
                                        </button>
                                        
                                        <?php if (!empty($brand['families'])): ?>
                                            <ul class="pl-3 flex flex-col gap-xs mt-1 brand-content" id="brand-content-<?php echo $brand['id']; ?>">
                                                <?php foreach ($brand['families'] as $family): 
                                                    $unique_family_id = $brand['id'] . "-" . $family['id'];
                                                ?>
                                                    <li class="family-container" id="family-box-<?php echo $unique_family_id; ?>">
                                                        <button onclick="toggleFamily('<?php echo $unique_family_id; ?>')" class="w-full flex items-center justify-between p-1 rounded hover:bg-surface-container-low text-left focus:outline-none transition-colors">
                                                            <span class="font-semibold text-[11px] text-stone-600 uppercase tracking-wider">
                                                                <?php echo htmlspecialchars($family['nome']); ?>
                                                            </span>
                                                            <?php if (!empty($family['subcategories'])): ?>
                                                                <span class="material-symbols-outlined text-[14px] rotate-icon family-icon text-outline">expand_more</span>
                                                            <?php endif; ?>
                                                        </button>
                                                        
                                                        <?php if (!empty($family['subcategories'])): ?>
                                                            <ul class="pl-3 flex flex-col gap-xs mt-xs border-l border-outline-variant/50 ml-1 family-content" id="family-content-<?php echo $unique_family_id; ?>">
                                                                <?php foreach ($family['subcategories'] as $sub): 
                                                                    $is_sub_active = (isset($_GET['category_id']) && $_GET['category_id'] == $sub['id'] && isset($_GET['brand_id']) && $_GET['brand_id'] == $brand['id']);
                                                                    
                                                                    $active_board_id = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;
                                                                    $sub_link = "?project_id=" . $projectId . "&category_id=" . $sub['id'] . "&brand_id=" . $brand['id'];
                                                                    if ($active_board_id > 0) {
                                                                        $sub_link .= "&board_id=" . $active_board_id;
                                                                    }
                                                                ?>
                                                                    <li>
                                                                        <a href="<?php echo $sub_link; ?>" 
                                                                           class="block w-full text-left px-2 py-1 text-xs rounded transition-colors <?php echo $is_sub_active ? 'text-secondary font-bold bg-stone-100 active-sub' : 'text-on-surface-variant hover:text-secondary'; ?>">
                                                                            <?php echo htmlspecialchars($sub['nome']); ?>
                                                                        </a>
                                                                    </li>
                                                                <?php endforeach; ?>
                                                            </ul>
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </section>

                <section class="flex-1 bg-background flex flex-col h-full min-w-0 border-r border-outline-variant overflow-hidden">
                    
                    <div class="bg-surface-container-low border-b border-outline-variant p-md flex-shrink-0">
                        <div class="flex items-center gap-2 text-outline font-label-md text-label-md mb-3">
                            <span>Painel Técnico</span>
                            <span class="material-symbols-outlined text-[14px]">chevron_right</span>
                            <span class="text-on-surface font-semibold">Configurador de Artigos</span>
                        </div>

                        <?php if (empty($attributes)): ?>
                            <div class="border border-dashed border-outline-variant rounded-md p-6 text-center text-outline bg-white">
                                <span class="material-symbols-outlined text-[36px] mb-2 block text-secondary">tune</span>
                                Selecione uma Subfamília no menu lateral esquerdo para expandir as matrizes de características.
                            </div>
                        <?php else: ?>
                            <div class="grid grid-cols-4 gap-md">
                                <?php foreach ($attributes as $attr): ?>
                                    <div class="flex flex-col gap-1 attr-box" data-attr-id="<?php echo $attr['id']; ?>">
                                        <label class="text-[10px] font-bold uppercase text-outline tracking-wider"><?php echo htmlspecialchars($attr['nome']); ?></label>
                                        <div class="h-32 bg-white border border-outline-variant rounded-DEFAULT overflow-y-auto attr-values-wrapper">
                                            <?php foreach ($attr['valores'] as $val): ?>
                                                <div class="px-2 py-1 text-body-md filter-list-item" data-value="<?php echo htmlspecialchars($val); ?>" onclick="selectAttributeValue(this)">
                                                    <?php echo htmlspecialchars($val); ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <div id="panelMatchResult" class="mt-md flex items-center justify-between gap-md border-t border-outline-variant pt-md hidden">
                                <div class="flex items-center gap-sm flex-1">
                                    <div id="matchedRef" class="px-3 py-1 bg-secondary text-white rounded-DEFAULT font-mono-sm text-[11px]">---</div>
                                    <span id="matchedDesc" class="text-body-md font-medium text-on-surface">Mapeando designação técnica...</span>
                                </div>
                                <div class="flex items-center gap-sm">
                                    <div class="flex items-center border border-outline-variant rounded-DEFAULT bg-white h-9">
                                        <button onclick="adjustQty(-1)" class="px-2 text-outline hover:text-on-surface"><span class="material-symbols-outlined text-[18px]">remove</span></button>
                                        <span id="purchaseQty" class="w-10 text-center font-bold text-body-md font-mono-sm select-none">1</span>
                                        <button onclick="adjustQty(1)" class="px-2 text-outline hover:text-on-surface"><span class="material-symbols-outlined text-[18px]">add</span></button>
                                    </div>
                                    <button id="btnAddToBoard" class="bg-secondary text-white px-lg h-9 rounded-DEFAULT flex items-center gap-2 font-label-md uppercase tracking-wider hover:bg-opacity-90 transition-all shadow-sm">
                                        <span class="material-symbols-outlined text-[18px]">add_shopping_cart</span>
                                        Adicionar
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="flex-1 flex flex-col min-h-0 bg-surface-container-lowest">
                        <div class="px-lg py-md border-b border-outline-variant flex items-center justify-between flex-shrink-0">
                            <h2 class="font-label-md text-label-md text-on-surface uppercase tracking-wide flex items-center gap-2">
                                <span class="material-symbols-outlined text-[20px] text-secondary">shopping_cart</span>
                                Materiais alocados no Quadro Selecionado
                            </h2>
                            <div class="text-right">
                                <div class="text-[10px] text-outline uppercase">Total Parcial</div>
                                <div class="font-headline-sm text-on-surface font-semibold" id="cartTotalSum">0,00 €</div>
                            </div>
                        </div>

                        <div class="flex-1 overflow-y-auto">
                            <table class="w-full text-left border-collapse" id="cartTable">
                                <thead class="sticky top-0 bg-white shadow-sm z-10">
                                    <tr class="border-b border-outline-variant">
                                        <th class="px-lg py-3 font-label-md text-label-md text-outline-variant uppercase font-medium">Marca</th>
                                        <th class="px-sm py-3 font-label-md text-label-md text-outline-variant uppercase font-medium">Referência</th>
                                        <th class="px-sm py-3 font-label-md text-label-md text-outline-variant uppercase font-medium">Designação</th>
                                        <th class="px-sm py-3 font-label-md text-label-md text-outline-variant uppercase font-medium text-center w-[120px]">Qtd</th>
                                        <th class="px-sm py-3 font-label-md text-label-md text-outline-variant uppercase font-medium text-right">PVP Unit.</th>
                                        <th class="px-sm py-3 font-label-md text-label-md text-outline-variant uppercase font-medium text-right">Ações</th>
                                    </tr>
                                </thead>
                                <tbody class="font-body-md text-body-md text-on-surface">
                                    <tr>
                                        <td colspan="6" class="px-lg py-8 text-center text-outline italic">
                                            Selecione um Quadro à direita para listar os materiais guardados.
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                <?php require_once __DIR__ . '/sidebarProject.php'; ?>

            </main>
        </div>
    </div>

    <script>
        let currentMatchedProductId = null;
        const urlParams = new URLSearchParams(window.location.search);
        const projectId = urlParams.get('project_id');
        const categoryId = urlParams.get('category_id');
        const brandId = urlParams.get('brand_id');

        function selectAttributeValue(element) {
            const wrapper = element.closest('.attr-values-wrapper');
            
            if (element.classList.contains('active')) {
                element.classList.remove('active');
            } else {
                wrapper.querySelectorAll('.filter-list-item').forEach(item => item.classList.remove('active'));
                element.classList.add('active');
            }

            updateDynamicLocks();
            checkAndMatchProduct();
        }

        function updateDynamicLocks() {
            const attributeBoxes = document.querySelectorAll('.attr-box');
            let filters = {};

            attributeBoxes.forEach(box => {
                const activeItem = box.querySelector('.filter-list-item.active');
                if (activeItem) {
                    const attrId = box.getAttribute('data-attr-id');
                    filters[attrId] = activeItem.getAttribute('data-value');
                }
            });

            let queryString = Object.keys(filters).map(key => `filters[${key}]=${encodeURIComponent(filters[key])}`).join('&');

            fetch(`/enge-quadro/project/material-survey?project_id=${projectId}&category_id=${categoryId}&brand_id=${brandId}&api_action=get_valid_options&${queryString}`)
                .then(res => res.json())
                .then(res => {
                    if (res.success) {
                        attributeBoxes.forEach(box => {
                            const attrId = box.getAttribute('data-attr-id');
                            const validValues = res.validOptions[attrId] || [];

                            box.querySelectorAll('.filter-list-item').forEach(item => {
                                const val = item.getAttribute('data-value');

                                if (validValues.includes(val)) {
                                    item.classList.remove('opacity-25', 'pointer-events-none', 'bg-stone-50');
                                } else {
                                    item.classList.add('opacity-25', 'pointer-events-none', 'bg-stone-50');
                                    if (item.classList.contains('active')) {
                                        item.classList.remove('active');
                                    }
                                }
                            });
                        });
                    }
                })
                .catch(err => console.error("Erro ao processar restrições EAV."));
        }

        function checkAndMatchProduct() {
            const attributeBoxes = document.querySelectorAll('.attr-box');
            let allFilled = true;
            let filters = {};

            attributeBoxes.forEach(box => {
                const totalAvailable = box.querySelectorAll('.filter-list-item:not(.pointer-events-none)');
                const activeItem = box.querySelector('.filter-list-item.active');
                
                if (totalAvailable.length > 0 && !activeItem) {
                    allFilled = false;
                }
                if (activeItem) {
                    filters[box.getAttribute('data-attr-id')] = activeItem.getAttribute('data-value');
                }
            });

            if (!allFilled || Object.keys(filters).length === 0) {
                document.getElementById('panelMatchResult').classList.add('hidden');
                return;
            }

            let queryString = Object.keys(filters).map(key => `filters[${key}]=${encodeURIComponent(filters[key])}`).join('&');

            fetch(`/enge-quadro/project/material-survey?project_id=${projectId}&category_id=${categoryId}&brand_id=${brandId}&api_action=match_product&${queryString}`)
                .then(res => res.json())
                .then(res => {
                    if (res.success) {
                        currentMatchedProductId = res.product.id;
                        document.getElementById('matchedRef').textContent = res.product.referencia;
                        document.getElementById('matchedDesc').textContent = res.product.descricao || "Sem especificação técnica registada.";
                        document.getElementById('panelMatchResult').classList.remove('hidden');
                    } else {
                        currentMatchedProductId = null;
                        document.getElementById('panelMatchResult').classList.add('hidden');
                    }
                });
        }

        function adjustQty(amount) {
            const qtySpan = document.getElementById('purchaseQty');
            let current = parseInt(qtySpan.textContent);
            current += amount;
            if (current < 1) current = 1;
            qtySpan.textContent = current;
        }

        document.getElementById('btnAddToBoard')?.addEventListener('click', () => {
            const boardId = urlParams.get('board_id');
            const qty = document.getElementById('purchaseQty').textContent;

            if (!boardId || boardId === '0') {
                alert("Por favor, selecione primeiro um Quadro Elétrico na barra lateral da direita!");
                return;
            }

            if (currentMatchedProductId) {
                fetch(`/enge-quadro/project/material-survey?project_id=${projectId}&api_action=add_to_board&board_id=${boardId}&product_id=${currentMatchedProductId}&qty=${qty}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            refreshBoardMaterials(boardId);
                            document.getElementById('purchaseQty').textContent = "1";
                        } else {
                            alert("Erro ao alocar material: " + (data.message || "Verifique as tabelas da BD."));
                        }
                    })
                    .catch(err => console.error("Erro na requisição de inserção do item."));
            }
        });

        function refreshBoardMaterials(boardId) {
            fetch(`/enge-quadro/project/material-survey?project_id=${projectId}&api_action=get_board_materials&board_id=${boardId}`)
                .then(res => res.json())
                .then(data => {
                    const tbody = document.querySelector('#cartTable tbody');
                    const totalSumDiv = document.getElementById('cartTotalSum');
                    
                    tbody.innerHTML = ''; 
                    let totalQuadro = 0;

                    if (!data.items || data.items.length === 0) {
                        tbody.innerHTML = `<tr><td colspan="6" class="px-lg py-8 text-center text-outline italic">Este quadro ainda não tem materiais alocados.</td></tr>`;
                        totalSumDiv.textContent = "0,00 €";
                        return;
                    }

                    data.items.forEach(item => {
                        let pvpNum = parseFloat(item.pvp) || 0;
                        let qtdNum = parseInt(item.quantity) || 0;
                        let subTotal = pvpNum * qtdNum;
                        totalQuadro += subTotal;

                        tbody.innerHTML += `
                            <tr class="border-b border-outline-variant/40 hover:bg-surface-container-low transition-colors">
                                <td class="px-lg py-3 text-outline font-medium">${item.marca}</td>
                                <td class="px-sm py-3 font-mono-sm text-secondary font-bold">${item.referencia}</td>
                                <td class="px-sm py-3 text-on-surface">${item.descricao}</td>
                                <td class="px-sm py-3 text-center">
                                    <div class="inline-flex items-center border border-outline-variant rounded bg-white h-8 mx-auto shadow-sm">
                                        <button onclick="updateItemQuantity(${item.id}, ${qtdNum - 1})" class="px-2 text-outline hover:text-on-surface active:scale-95 transition-transform">
                                            <span class="material-symbols-outlined text-[14px]">remove</span>
                                        </button>
                                        <span class="w-8 text-center font-bold text-xs font-mono-sm select-none text-on-surface">${qtdNum}</span>
                                        <button onclick="updateItemQuantity(${item.id}, ${qtdNum + 1})" class="px-2 text-outline hover:text-on-surface active:scale-95 transition-transform">
                                            <span class="material-symbols-outlined text-[14px]">add</span>
                                        </button>
                                    </div>
                                </td>
                                <td class="px-sm py-3 text-right font-mono-sm text-on-surface-variant">${pvpNum.toFixed(2).replace('.', ',')} €</td>
                                <td class="px-sm py-3 text-right">
                                    <button onclick="removeItemFromBoard(${item.id})" class="text-outline hover:text-error p-1 rounded transition-colors" title="Remover Material">
                                        <span class="material-symbols-outlined text-[18px]">delete</span>
                                    </button>
                                </td>
                            </tr>`;
                    });

                    totalSumDiv.textContent = totalQuadro.toFixed(2).replace('.', ',') + " €";
                })
                .catch(err => console.error("Erro ao sincronizar materiais do quadro."));
        }

        function updateItemQuantity(itemId, newQty) {
            const boardId = urlParams.get('board_id');
            if (!boardId || !itemId) return;
            if (newQty < 1) return;

            fetch(`/enge-quadro/project/material-survey?project_id=${projectId}&api_action=update_item_qty&item_id=${itemId}&qty=${newQty}`)
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        refreshBoardMaterials(boardId);
                    } else {
                        console.error("Erro ao atualizar quantidade no servidor.");
                    }
                })
                .catch(err => console.error("Erro na requisição assíncrona de quantidade."));
        }

        function removeItemFromBoard(itemId) {
            const boardId = urlParams.get('board_id');
            if (!boardId) return;

            if (confirm("Deseja remover este artigo do quadro elétrico?")) {
                fetch(`/enge-quadro/project/material-survey?project_id=${projectId}&api_action=remove_from_board&item_id=${itemId}`)
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            refreshBoardMaterials(boardId);
                        } else {
                            alert("Erro ao remover o material.");
                        }
                    })
                    .catch(err => console.error("Erro na requisição de eliminação do item."));
            }
        }

        function toggleBrand(brandId) {
            const container = document.getElementById(`brand-box-${brandId}`);
            const content = document.getElementById(`brand-content-${brandId}`);
            if (content) {
                if (content.style.display === 'none' || container.classList.contains('collapsed')) {
                    container.classList.remove('collapsed'); content.style.display = 'flex';
                } else {
                    container.classList.add('collapsed'); content.style.display = 'none';
                }
            }
        }

        function toggleFamily(uniqueId) {
            const container = document.getElementById(`family-box-${uniqueId}`);
            const content = document.getElementById(`family-content-${uniqueId}`);
            if (content) {
                if (content.style.display === 'none' || container.classList.contains('collapsed')) {
                    container.classList.remove('collapsed'); content.style.display = 'flex';
                } else {
                    container.classList.add('collapsed'); content.style.display = 'none';
                }
            }
        }

        document.addEventListener("DOMContentLoaded", function() {
            const activeBoardId = urlParams.get('board_id');
            if (activeBoardId && activeBoardId !== '0') {
                refreshBoardMaterials(activeBoardId);
            }

            document.querySelectorAll('.brand-container').forEach(container => {
                if (!container.querySelector('.active-sub')) {
                    container.classList.add('collapsed');
                    const content = container.querySelector('.brand-content');
                    if (content) content.style.display = 'none';
                }
            });
            document.querySelectorAll('.family-container').forEach(container => {
                if (!container.querySelector('.active-sub')) {
                    container.classList.add('collapsed');
                    const content = container.querySelector('.family-content');
                    if (content) content.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
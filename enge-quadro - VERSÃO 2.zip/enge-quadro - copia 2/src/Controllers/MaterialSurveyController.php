<?php
// src/Controllers/MaterialSurveyController.php

require_once __DIR__ . '/../DAO/ProjectDAO.php';

class MaterialSurveyController {
    private $projectDAO;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION['user_id'])) {
            header('Location: /enge-quadro/login');
            exit();
        }
        $this->projectDAO = new ProjectDAO();
    }

    public function materialSurvey() {
        $projectId = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
        
        if ($projectId === 0) {
            header('Location: /enge-quadro/home');
            exit();
        }

        $categoryId = isset($_GET['category_id']) ? intval($_GET['category_id']) : null;
        $brandId = isset($_GET['brand_id']) ? intval($_GET['brand_id']) : null;
        $boardId = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;

        // --- API ACTION: CALCULAR TRAVAS TÉCNICAS DINÂMICAS ---
        if (isset($_GET['api_action']) && $_GET['api_action'] === 'get_valid_options') {
            header('Content-Type: application/json');
            $filters = $_GET['filters'] ?? [];
            $validOptions = $this->projectDAO->getValidOptions($categoryId, $brandId, $filters);
            echo json_encode(['success' => true, 'validOptions' => $validOptions]);
            exit();
        }

        // --- API ACTION: MATCH EXACT PRODUCT IN EAV MATRIX ---
        if (isset($_GET['api_action']) && $_GET['api_action'] === 'match_product') {
            header('Content-Type: application/json');
            $filters = $_GET['filters'] ?? [];
            $product = $this->projectDAO->matchProductByAttributes($categoryId, $brandId, $filters);
            
            if ($product) {
                echo json_encode(['success' => true, 'product' => $product]);
            } else {
                echo json_encode(['success' => false]);
            }
            exit();
        }

        // --- API ACTION: ADD PRODUCT TO SWITCHBOARD ---
        if (isset($_GET['api_action']) && $_GET['api_action'] === 'add_to_board') {
            header('Content-Type: application/json');
            $targetBoardId = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;
            $productId = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
            $qty = isset($_GET['qty']) ? intval($_GET['qty']) : 1;

            if ($targetBoardId > 0 && $productId > 0) {
                $res = $this->projectDAO->addProductToBoard($targetBoardId, $productId, $qty);
                echo json_encode(['success' => $res]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Parâmetros em falta.']);
            }
            exit();
        }

        // --- API ACTION: REMOVE PRODUCT FROM BOARD ---
        if (isset($_GET['api_action']) && $_GET['api_action'] === 'remove_from_board') {
            header('Content-Type: application/json');
            $itemId = isset($_GET['item_id']) ? intval($_GET['item_id']) : 0;

            if ($itemId > 0) {
                $res = $this->projectDAO->removeItemFromBoard($itemId);
                echo json_encode(['success' => $res]);
            } else {
                echo json_encode(['success' => false, 'message' => 'ID do item inválido.']);
            }
            exit();
        }

        // --- API ACTION: UPDATE ITEM QUANTITY INLINE ---
        if (isset($_GET['api_action']) && $_GET['api_action'] === 'update_item_qty') {
            header('Content-Type: application/json');
            $itemId = isset($_GET['item_id']) ? intval($_GET['item_id']) : 0;
            $newQty = isset($_GET['qty']) ? intval($_GET['qty']) : 1;

            if ($itemId > 0 && $newQty > 0) {
                $db = Database::getConnection();
                $stmt = $db->prepare("UPDATE board_items SET quantity = :qty WHERE id = :id");
                $res = $stmt->execute(['qty' => $newQty, 'id' => $itemId]);
                echo json_encode(['success' => $res]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Parâmetros inválidos.']);
            }
            exit();
        }

        // --- API ACTION: GET LIVE MATERIAL LIST ---
        if (isset($_GET['api_action']) && $_GET['api_action'] === 'get_board_materials') {
            header('Content-Type: application/json');
            $targetBoardId = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;
            $items = $this->projectDAO->getItemsFromBoard($targetBoardId);
            echo json_encode(['success' => true, 'items' => $items]);
            exit();
        }

        // Carga estática para a renderização inicial do template
        $catalogTree = $this->projectDAO->getCatalogTree();
        $attributes = [];
        if ($categoryId && $brandId) {
            $attributes = $this->projectDAO->getAttributesBySubfamily($categoryId, $brandId);
        }

        $switchboards = $this->projectDAO->getSwitchboardsByProject($projectId);
        
        $boardItems = [];
        if ($boardId > 0) {
            $boardItems = $this->projectDAO->getItemsFromBoard($boardId);
        }

        require_once __DIR__ . '/../Views/materialSurvey.php';
    }

    /**
     * Ação: Criar novo Quadro Elétrico
     */
    public function createBoard() {
        $projectId = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
        $name = isset($_GET['name']) ? trim($_GET['name']) : '';

        if ($projectId > 0 && !empty($name)) {
            $name = preg_replace('/\s+/', ' ', $name);
            $this->projectDAO->createSwitchboard($projectId, $name);
        }

        header("Location: /enge-quadro/project/material-survey?project_id=" . $projectId);
        exit();
    }

    /**
     * Ação: Apagar Quadro Elétrico
     */
    public function deleteBoard() {
        $projectId = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
        $boardId = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;

        if ($boardId > 0) {
            $this->projectDAO->deleteSwitchboard($boardId);
        }

        header("Location: /enge-quadro/project/material-survey?project_id=" . $projectId);
        exit();
    }
}
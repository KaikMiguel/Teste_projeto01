<?php
// src/DAO/UserDAO.php

require_once $_SERVER['DOCUMENT_ROOT'] . '/enge-quadro/src/Models/Database.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/enge-quadro/src/Models/User.php';

class UserDAO {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /**
     * Procura um utilizador pelo E-mail no MySQL
     * Usado diretamente no fluxo de Login
     */
    public function findByEmail($email) {
        // Criar a query com um "placeholder" (:email) para total segurança contra SQL Injection
        $query = "SELECT * FROM users WHERE email = :email LIMIT 1";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute(['email' => $email]);
        
        // Vai buscar a linha de dados do MySQL
        $row = $stmt->fetch();

        // Se encontrar o utilizador, transforma a linha num Objeto da classe User
        if ($row) {
            return new User($row);
        }
        
        return null; // Se não encontrar ninguém com esse e-mail
    }
}
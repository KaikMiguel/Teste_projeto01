<?php
// src/Models/Database.php

// Garante o caminho absoluto correto a partir da raiz do servidor XAMPP
require_once $_SERVER['DOCUMENT_ROOT'] . '/enge-quadro/config.php';

class Database {
    private static $instance = null;
    private $conn;

    private function __construct() {
        try {
            // Configurar a string de conexão PDO usando as constantes do config.php
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            
            // Ativar opções de segurança e tratamento de erros profissionais
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];

            $this->conn = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Se a ligação falhar, mostra o erro no ecrã para sabermos o que falhou
            die("Erro na ligação à Base de Dados: " . $e->getMessage());
        }
    }

    // Método para obter a ligação ativa em qualquer parte do projeto
    public static function getConnection() {
        if (self::$instance == null) {
            self::$instance = new Database();
        }
        return self::$instance->conn;
    }
}
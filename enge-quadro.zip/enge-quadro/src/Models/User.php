<?php
// src/Models/User.php

class User {
    public $id;
    public $nome;
    public $email;
    public $password_hash;
    public $remember_token;
    public $tipo_acesso; // Será apenas 'admin' ou 'user'
    public $estado;

    public function __construct($data = []) {
        $this->id = $data['id'] ?? null;
        $this->nome = $data['nome'] ?? null;
        $this->email = $data['email'] ?? null;
        $this->password_hash = $data['password_hash'] ?? null;
        $this->remember_token = $data['remember_token'] ?? null;
        $this->tipo_acesso = $data['tipo_acesso'] ?? 'user'; // Padrão alterado para 'user'
        $this->estado = $data['estado'] ?? 'ativo';
    }
}
<?php
// src/Utils/PasswordUtils.php

class PasswordUtils {
    /**
     * Limpa os dados vindos dos formulários (Proteção básica)
     */
    public static function sanitize($data) {
        return htmlspecialchars(strip_tags(trim($data)));
    }

    /**
     * Verifica se a password digitada bate certo com o hash seguro da Base de Dados
     */
    public static function verify($password, $hash) {
        return password_verify($password, $hash);
    }
}
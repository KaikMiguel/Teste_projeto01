<?php
// src/Views/sidebarProject.php

$current_project_id = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
$current_board_id = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;

if (!isset($switchboards)) {
    $switchboards = []; 
}
?>
<aside class="w-64 bg-white dark:bg-stone-950 border-l border-[#e1e2df] dark:border-stone-800 h-[calc(100vh-64px)] flex flex-col justify-between flex-shrink-0">
    <div class="p-md flex flex-col gap-md">
        
        <div class="flex justify-between items-center px-xs mb-xs mt-2">
            <span class="font-['Inter'] text-[11px] font-bold text-stone-500 dark:text-stone-400 uppercase tracking-widest">Gestão de Quadros</span>
            <button onclick="openCreateBoardModal()" class="text-[#94b053] hover:text-stone-900 dark:hover:text-white transition-colors flex items-center justify-center p-0.5 rounded">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">add_box</span>
            </button>
        </div>

        <nav class="flex flex-col gap-xs overflow-y-auto max-h-[calc(100vh-240px)] pr-xs">
            <?php if (empty($switchboards)): ?>
                <p class="text-xs text-stone-400 italic px-xs">Nenhum quadro criado.</p>
            <?php else: ?>
                <?php foreach ($switchboards as $board): 
                    $is_selected = ($board['id'] === $current_board_id);
                    // CORREÇÃO CRUCIAL: O link agora é absoluto e aponta para a rota definida no index.php
                    $board_url = "/enge-quadro/project/material-survey?project_id=" . $current_project_id . "&board_id=" . $board['id'];
                ?>
                    <div class="group flex items-center justify-between w-full rounded-md transition-all duration-150 <?php echo $is_selected ? 'bg-[#cdeb87] text-stone-900 font-semibold shadow-sm' : 'text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white'; ?>">
                        
                        <a href="<?php echo $board_url; ?>" class="flex-1 py-2 px-3 flex items-center gap-sm text-[13px] truncate">
                            <span class="truncate"><?php echo htmlspecialchars($board['board_name']); ?></span>
                        </a>

                        <div class="flex items-center gap-1 pr-3">
                            <?php if ($is_selected): ?>
                                <span class="material-symbols-outlined text-[16px] text-stone-700 group-hover:hidden" style="font-variation-settings: 'FILL' 1;">bolt</span>
                            <?php endif; ?>
                            
                            <div class="hidden group-hover:flex items-center gap-1 transition-all">
                                <button onclick="copyBoard(<?php echo $board['id']; ?>)" title="Copiar Quadro" class="text-stone-400 hover:text-stone-900 dark:hover:text-white p-0.5 rounded">
                                    <span class="material-symbols-outlined text-[15px]">content_copy</span>
                                </button>
                                <button onclick="deleteBoard(<?php echo $board['id']; ?>)" title="Eliminar Quadro" class="text-stone-400 hover:text-red-600 p-0.5 rounded">
                                    <span class="material-symbols-outlined text-[15px]">delete</span>
                                </button>
                            </div>
                        </div>

                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </nav>
    </div>

    <div class="p-4 border-t border-[#e1e2df] dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/20">
        <button class="w-full py-2 px-4 border border-stone-400 hover:border-[#4e660f] text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-900 transition-all font-['Inter'] text-[11px] font-bold uppercase tracking-widest rounded flex items-center justify-center gap-2 shadow-sm">
            <span class="material-symbols-outlined text-[18px]">fact_check</span>
            Validar Material
        </button>
    </div>
</aside>

<script>
function openCreateBoardModal() {
    const boardName = prompt("Introduza o nome do novo Quadro Elétrico:");
    if (boardName && boardName.trim() !== "") {
        window.location.href = "/enge-quadro/boards/create?project_id=<?php echo $current_project_id; ?>&name=" + encodeURIComponent(boardName.trim());
    }
}
function deleteBoard(boardId) {
    if (confirm("Tem a certeza de que deseja eliminar este quadro?")) {
        window.location.href = "/enge-quadro/boards/delete?project_id=<?php echo $current_project_id; ?>&board_id=" + boardId;
    }
}
function copyBoard(boardId) {
    if (confirm("Deseja duplicar este quadro elétrico?")) {
        window.location.href = "/enge-quadro/boards/copy?project_id=<?php echo $current_project_id; ?>&board_id=" + boardId;
    }
}
</script>
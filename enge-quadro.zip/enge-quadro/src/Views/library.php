<!DOCTYPE html>
<html class="light" lang="pt-pt">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Library</title>
    
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>

    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "on-secondary-fixed-variant": "#394d00",
                        "tertiary": "#4f6300",
                        "surface-container-high": "#ebe7e6",
                        "on-secondary-container": "#526b14",
                        "inverse-primary": "#c7c7c1",
                        "background": "#fcf8f7",
                        "outline": "#767872",
                        "surface-bright": "#fcf8f7",
                        "secondary-container": "#cdeb87",
                        "on-secondary-fixed": "#151f00",
                        "on-surface": "#1c1b1b",
                        "primary-fixed": "#e3e3dd",
                        "surface-container-highest": "#e5e2e0",
                        "surface-container": "#f1edec",
                        "on-background": "#1c1b1b",
                        "secondary": "#4e660f",
                        "on-primary-container": "#fdfdf7",
                        "on-tertiary-fixed": "#161e00",
                        "secondary-fixed": "#d0ee89",
                        "primary-fixed-dim": "#c7c7c1",
                        "error-container": "#ffdad6",
                        "primary-container": "#747570",
                        "surface-variant": "#e5e2e0",
                        "surface-tint": "#5d5f5a",
                        "on-tertiary": "#ffffff",
                        "tertiary-fixed-dim": "#abd600",
                        "secondary-fixed-dim": "#b4d170",
                        "on-error-container": "#93000a",
                        "on-surface-variant": "#454742",
                        "error": "#ba1a1a",
                        "surface-dim": "#ddd9d8",
                        "on-primary": "#ffffff",
                        "tertiary-container": "#647e00",
                        "surface-container-low": "#f7f3f1",
                        "tertiary-fixed": "#c5f31b",
                        "on-primary-fixed-variant": "#464743",
                        "primary": "#5b5c58",
                        "outline-variant": "#c6c7c0",
                        "on-error": "#ffffff",
                        "surface-container-lowest": "#ffffff",
                        "on-secondary": "#ffffff",
                        "on-primary-fixed": "#1a1c19",
                        "inverse-on-surface": "#f4f0ef",
                        "inverse-surface": "#313030",
                        "surface": "#fcf8f7",
                        "on-tertiary-container": "#fbffe4",
                        "on-tertiary-fixed-variant": "#3c4d00"
                    },
                    "borderRadius": {
                        "DEFAULT": "0.125rem",
                        "lg": "0.25rem",
                        "xl": "0.5rem",
                        "full": "0.75rem"
                    },
                    "spacing": {
                        "unit": "4px",
                        "sm": "8px",
                        "md": "16px",
                        "xl": "48px",
                        "margin": "24px",
                        "xs": "4px",
                        "gutter": "16px",
                        "lg": "24px"
                    },
                    "fontFamily": {
                        "label-md": ["Inter"],
                        "headline-lg": ["Inter"],
                        "body-md": ["Inter"],
                        "headline-sm": ["Inter"],
                        "mono-sm": ["monospace"],
                        "headline-md": ["Inter"],
                        "body-lg": ["Inter"]
                    },
                    "fontSize": {
                        "label-md": ["12px", { "lineHeight": "1", "letterSpacing": "0.05em", "fontWeight": "500" }],
                        "headline-lg": ["32px", { "lineHeight": "1.2", "letterSpacing": "-0.02em", "fontWeight": "600" }],
                        "body-md": ["14px", { "lineHeight": "1.5", "fontWeight": "400" }],
                        "headline-sm": ["18px", { "lineHeight": "1.4", "fontWeight": "600" }],
                        "mono-sm": ["12px", { "lineHeight": "1", "fontWeight": "400" }],
                        "headline-md": ["24px", { "lineHeight": "1.2", "letterSpacing": "-0.01em", "fontWeight": "600" }],
                        "body-lg": ["16px", { "lineHeight": "1.6", "fontWeight": "400" }]
                    }
                }
            }
        }
    </script>

    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        /* Custom scrollbar para manter estética industrial */
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #c6c7c0; border-radius: 2px; }
    </style>
</head>

<body class="bg-background text-on-background font-body-md text-body-md min-h-screen flex flex-col antialiased">

    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 border-b border-[#e1e2df] dark:border-stone-800">
        <div class="flex items-center gap-md">
            <span class="text-lg font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>
        </div>

        <div class="flex items-center gap-sm">
            <button class="flex items-center gap-2 px-3 py-1.5 text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 border border-transparent hover:border-stone-200 transition-all duration-200 rounded-lg group">
                <span class="material-symbols-outlined text-[20px] group-active:scale-90 transition-transform">save</span>
                <span class="text-[11px] font-bold uppercase tracking-widest">Save</span>
            </button>

            <button class="p-sm text-[#82837e] dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors active:opacity-80 rounded-full">
                <span class="material-symbols-outlined text-[24px]">notifications</span>
            </button>

            <a href="Home.html" 
            class="ml-sm w-9 h-9 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-[#94b053] hover:border-[#94b053] hover:bg-white transition-all duration-200 shadow-sm">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">home</span>
            </a>
        </div>
    </header>

    <div class="flex pt-16 flex-1 h-screen overflow-hidden">
       <nav class="bg-white dark:bg-stone-950 fixed left-0 top-16 h-[calc(100vh-64px)] w-64 border-r border-[#e1e2df] dark:border-stone-800 flex flex-col pt-4 overflow-y-auto">

            <ul class="flex flex-col gap-unit">

                <li>
                    <a href="Home.html" 
                    class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                        <span class="material-symbols-outlined text-[20px] " data-icon="inventory_2">precision_manufacturing</span>
                        Home
                    </a>
                </li>
                <li>
                    <a  
                    class="flex items-center gap-md px-lg py-sm bg-stone-100 dark:bg-stone-900 text-stone-900 dark:text-white border-r-4 border-[#94b053] font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                        <span class="material-symbols-outlined text-[20px]" style="font-variation-settings: 'FILL' 1;">inventory_2</span>
                        Biblioteca
                    </a>
                </li>

            </ul>

            <div class="mt-auto pt-4 pb-8 border-t border-[#e1e2df] dark:border-stone-800 flex flex-col gap-unit">
                <a class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                    <span class="material-symbols-outlined text-[20px]">settings</span>
                    Configurações
                </a>
                <a class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-red-600 dark:hover:text-red-400 transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                    <span class="material-symbols-outlined text-[20px]">logout</span>
                    Logout
                </a>
                <div class="flex items-center gap-md px-lg py-sm mt-2">
                    <div class="w-8 h-8 rounded-full bg-stone-200 overflow-hidden border border-stone-300 flex-shrink-0">
                        <img alt="User" class="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDiu2LPPGzfXy4WhsQb79Tce77jM0xg15beLaP_X7cs580Fb2HSGduwo0RwR-1G20EtDS6pEb0vYtjZfdCyv6LLp2mOziHfVeWvptNyv5FUGFm7e-8YojzVGDiAk9buYa3Hlnf0pwJKiJy7gOTp79r5laNS4oGkPmvjjij-dw69cyp2X9w5i3Ggd82TQ6MWZ5DAGTYgZJZ4cYupof87EmLW4-VNDhUMUUye7c44DyXSFwo94Wa6hVIfgatLbEOWnjiW7CewrsUKe9w"/>
                    </div>
                    <span class="font-['Inter'] text-[11px] font-bold uppercase tracking-widest text-stone-900 dark:text-white">Perfil</span>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="ml-64 flex-1 p-xl bg-surface flex flex-col h-full overflow-y-auto">
            <div class="flex justify-between items-end mb-margin pb-md border-b border-outline-variant flex-shrink-0">
                <div>
                    <h1 class="font-headline-lg text-headline-lg text-on-surface mb-xs uppercase">Em Manutenção</h1>
                    <p class="font-body-md text-body-md text-on-surface-variant">Gerencie e acompanhe o progresso de todos os empreendimentos de engenharia atuais.</p>
                </div>
                
                <!-- Botão de acção exemplo -->
                <button class="bg-secondary text-white px-lg py-sm rounded-DEFAULT font-bold uppercase tracking-widest text-[11px] flex items-center gap-2 hover:opacity-90 transition-opacity">
                    <span class="material-symbols-outlined text-[18px]">add</span>
                    Adicionar Catalogo
                </button>
            </div>

            <!-- Área para Cards ou Tabelas -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-lg">
                <!-- Placeholder para conteúdo futuro -->
                <div class="border border-outline-variant p-lg rounded-lg bg-white/50 flex flex-col items-center justify-center min-h-[200px] border-dashed">
                    <span class="material-symbols-outlined text-outline text-[48px] mb-md">construction</span>
                    <p class="text-on-surface-variant italic">Nenhum projecto listado no momento.</p>
                </div>
            </div>
        </main>
    </div>

</body>
</html>
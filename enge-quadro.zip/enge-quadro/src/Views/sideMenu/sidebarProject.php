<?php
// Garantir que temos o ID do projeto ativo e o ID do quadro selecionado na URL
$current_project_id = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
$current_board_id = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;

// No fluxo real MVC, o teu controller irá injetar o array $switchboards.
// Se a variável não existir (fallback), criamos um array vazio.
if (!isset($switchboards)) {
    $switchboards = []; 
}

// Descobrir em que página nos encontramos para manter o botão "Validar Material" com o link correto
$current_page = basename($_SERVER['PHP_SELF']);
?>

<aside class="w-64 bg-white dark:bg-stone-950 border-r border-[#e1e2df] dark:border-stone-800 h-screen flex flex-col justify-between flex-shrink-0">
    <div class="p-md flex flex-col gap-md">
        
        <div class="flex justify-between items-center px-xs mb-xs">
            <span class="font-label-md text-xs font-bold text-on-surface-variant uppercase tracking-wider">Gestão de Quadros</span>
            <button onclick="openCreateBoardModal()" class="text-secondary hover:text-primary transition-colors flex items-center justify-center p-0.5 rounded hover:bg-stone-100">
                <span class="material-symbols-outlined text-[20px] font-bold">add_box</span>
            </button>
        </div>

        <nav class="flex flex-col gap-xs overflow-y-auto max-h-[calc(100vh-220px)] pr-xs">
            <?php if (empty($switchboards)): ?>
                <p class="text-xs text-outline italic px-xs">Nenhum quadro criado.</p>
            <?php else: ?>
                <?php foreach ($switchboards as $board): 
                    $is_selected = ($board['id'] === $current_board_id);
                    // Mantém o link do quadro apontando para a página onde o utilizador já está
                    $board_url = "?project_id=" . $current_project_id . "&board_id=" . $board['id'];
                ?>
                    <div class="group flex items-center justify-between w-full rounded-md transition-all duration-150 <?php echo $is_selected ? 'bg-secondary-container text-on-secondary-container font-semibold shadow-sm' : 'text-on-surface-variant hover:bg-stone-100'; ?>">
                        
                        <a href="<?php echo $board_url; ?>" class="flex-1 py-sm px-md flex items-center gap-sm text-sm truncate">
                            <?php if ($is_selected): ?>
                                <span class="material-symbols-outlined text-[16px] text-secondary">bolt</span>
                            <?php endif; ?>
                            <span class="truncate"><?php echo htmlspecialchars($board['board_name']); ?></span>
                        </a>

                        <div class="flex items-center gap-xs pr-sm opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onclick="copyBoard(<?php echo $board['id']; ?>)" title="Copiar Quadro" class="text-outline hover:text-primary p-0.5 rounded transition-colors">
                                <span class="material-symbols-outlined text-[16px]">content_copy</span>
                            </button>
                            <button onclick="deleteBoard(<?php echo $board['id']; ?>)" title="Eliminar Quadro" class="text-outline hover:text-error p-0.5 rounded transition-colors">
                                <span class="material-symbols-outlined text-[16px]">delete</span>
                            </button>
                        </div>

                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </nav>
    </div>

    <div class="p-md border-t border-[#e1e2df] dark:border-stone-800 bg-surface-container-low/30">
        <button class="w-full py-md px-md border border-secondary text-secondary hover:bg-secondary hover:text-white transition-all font-label-md text-xs font-bold uppercase tracking-wider rounded-DEFAULT flex items-center justify-center gap-sm shadow-sm active:opacity-90">
            <span class="material-symbols-outlined text-[18px]">fact_check</span>
            Validar Material
        </button>
    </div>
</aside>

<script>
function openCreateBoardModal() {
    // Aqui podes disparar um prompt simples ou o teu modal JS customizado
    const boardName = prompt("Introduza o nome do novo Quadro Elétrico:");
    if (boardName && boardName.trim() !== "") {
        window.location.href = "/enge-quadro/boards/create?project_id=<?php echo $current_project_id; ?>&name=" + encodeURIComponent(boardName.trim());
    }
}

function copyBoard(boardId) {
    if (confirm("Deseja duplicar este quadro elétrico com todos os seus disjuntores?")) {
        window.location.href = "/enge-quadro/boards/copy?project_id=<?php echo $current_project_id; ?>&board_id=" + boardId;
    }
}

function deleteBoard(boardId) {
    if (confirm("Aviso Crítico: Tem a certeza de que deseja eliminar permanentemente este quadro e todo o seu dimensionamento?")) {
        window.location.href = "/enge-quadro/boards/delete?project_id=<?php echo $current_project_id; ?>&board_id=" + boardId;
    }
}
</script>
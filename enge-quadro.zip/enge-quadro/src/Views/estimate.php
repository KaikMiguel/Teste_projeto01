<!DOCTYPE html>
<html class="light" lang="pt-pt">
<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Estimate</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet" />
    
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "on-secondary-fixed-variant": "#394d00",
                        "tertiary": "#4f6300",
                        "surface-container-high": "#ebe7e6",
                        "on-secondary-container": "#526b14",
                        "inverse-primary": "#c7c7c1",
                        "background": "#fcf8f7",
                        "outline": "#767872",
                        "surface-bright": "#fcf8f7",
                        "secondary-container": "#cdeb87",
                        "on-secondary-fixed": "#151f00",
                        "on-surface": "#1c1b1b",
                        "primary-fixed": "#e3e3dd",
                        "surface-container-highest": "#e5e2e0",
                        "surface-container": "#f1edec",
                        "on-background": "#1c1b1b",
                        "secondary": "#4e660f",
                        "on-primary-container": "#fdfdf7",
                        "on-tertiary-fixed": "#161e00",
                        "secondary-fixed": "#d0ee89",
                        "primary-fixed-dim": "#c7c7c1",
                        "error-container": "#ffdad6",
                        "primary-container": "#747570",
                        "surface-variant": "#e5e2e0",
                        "surface-tint": "#5d5f5a",
                        "on-tertiary": "#ffffff",
                        "tertiary-fixed-dim": "#abd600",
                        "secondary-fixed-dim": "#b4d170",
                        "on-error-container": "#93000a",
                        "on-surface-variant": "#454742",
                        "error": "#ba1a1a",
                        "surface-dim": "#ddd9d8",
                        "on-primary": "#ffffff",
                        "tertiary-container": "#647e00",
                        "surface-container-low": "#f7f3f1",
                        "tertiary-fixed": "#c5f31b",
                        "on-primary-fixed-variant": "#464743",
                        "primary": "#5b5c58",
                        "outline-variant": "#c6c7c0",
                        "on-error": "#ffffff",
                        "surface-container-lowest": "#ffffff",
                        "on-secondary": "#ffffff",
                        "on-primary-fixed": "#1a1c19",
                        "inverse-on-surface": "#f4f0ef",
                        "inverse-surface": "#313030",
                        "surface": "#fcf8f7",
                        "on-tertiary-container": "#fbffe4",
                        "on-tertiary-fixed-variant": "#3c4d00"
                    },
                    "borderRadius": {
                        "DEFAULT": "0.125rem",
                        "lg": "0.25rem",
                        "xl": "0.5rem",
                        "full": "0.75rem"
                    },
                    "spacing": {
                        "unit": "4px",
                        "sm": "8px",
                        "md": "16px",
                        "xl": "48px",
                        "margin": "24px",
                        "xs": "4px",
                        "gutter": "16px",
                        "lg": "24px"
                    },
                    "fontFamily": {
                        "label-md": ["Inter"],
                        "headline-lg": ["Inter"],
                        "body-md": ["Inter"],
                        "headline-sm": ["Inter"],
                        "mono-sm": ["monospace"],
                        "headline-md": ["Inter"],
                        "body-lg": ["Inter"]
                    },
                    "fontSize": {
                        "label-md": ["12px", { "lineHeight": "1", "letterSpacing": "0.05em", "fontWeight": "500" }],
                        "headline-lg": ["32px", { "lineHeight": "1.2", "letterSpacing": "-0.02em", "fontWeight": "600" }],
                        "body-md": ["14px", { "lineHeight": "1.5", "fontWeight": "400" }],
                        "headline-sm": ["18px", { "lineHeight": "1.4", "fontWeight": "600" }],
                        "mono-sm": ["12px", { "lineHeight": "1", "fontWeight": "400" }],
                        "headline-md": ["24px", { "lineHeight": "1.2", "letterSpacing": "-0.01em", "fontWeight": "600" }],
                        "body-lg": ["16px", { "lineHeight": "1.6", "fontWeight": "400" }]
                    }
                }
            }
        }
    </script>
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #c6c7c0; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #767872; }
    </style>
</head>

<body class="bg-background text-on-surface font-body-md text-body-md min-h-screen flex flex-col antialiased">

    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 border-b border-[#e1e2df] dark:border-stone-800">
        <div class="flex items-center gap-md">
            <span class="text-lg font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>
        </div>

        <div class="flex items-center gap-sm">
            <button class="flex items-center gap-2 px-3 py-1.5 text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 border border-transparent hover:border-stone-200 transition-all duration-200 rounded-lg group">
                <span class="material-symbols-outlined text-[20px] group-active:scale-90 transition-transform">save</span>
                <span class="text-[11px] font-bold uppercase tracking-widest">Save</span>
            </button>

            <button class="p-sm text-[#82837e] dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors active:opacity-80 rounded-full">
                <span class="material-symbols-outlined text-[24px]">notifications</span>
            </button>

            <a href="Home.html" 
            class="ml-sm w-9 h-9 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-[#94b053] hover:border-[#94b053] hover:bg-white transition-all duration-200 shadow-sm">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">home</span>
            </a>
        </div>
    </header>

    <div class="flex pt-16 flex-1 h-screen overflow-hidden">
        <nav class="bg-white dark:bg-stone-950 fixed left-0 top-16 h-[calc(100vh-64px)] w-64 border-r border-[#e1e2df] dark:border-stone-800 flex flex-col pt-4 overflow-y-auto">

            <ul class="flex flex-col gap-unit">
                <li>
                    <a href="MaterialSurvey.html"
                    class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                        <span class="material-symbols-outlined text-[20px]">inventory_2</span>
                        Material
                    </a>
                </li>
                <li>
                    <a href="ElectricalDiagram.html"
                    class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                        <span class="material-symbols-outlined text-[20px]">account_tree</span>
                        Esquema
                    </a>
                </li>
                <li>
                    <a href="Layout.html"
                    class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                        <span class="material-symbols-outlined text-[20px]">grid_view</span>
                        Layout
                    </a>
                </li>
                <li>
                    <a class="flex items-center gap-md px-lg py-sm bg-stone-100 dark:bg-stone-900 text-stone-900 dark:text-white border-r-4 border-[#94b053] font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                        <span class="material-symbols-outlined text-[20px]" style="font-variation-settings: 'FILL' 1;">payments</span>
                        Orçamento
                    </a>
                </li>
            </ul>

            <div class="mt-auto pt-4 pb-8 border-t border-[#e1e2df] dark:border-stone-800 flex flex-col gap-unit">
                <a class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                    <span class="material-symbols-outlined text-[20px]">settings</span>
                    Configurações
                </a>
                <a class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-red-600 dark:hover:text-red-400 transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                    <span class="material-symbols-outlined text-[20px]">logout</span>
                    Logout
                </a>
                <div class="flex items-center gap-md px-lg py-sm mt-2">
                    <div class="w-8 h-8 rounded-full bg-stone-200 overflow-hidden border border-stone-300 flex-shrink-0">
                        <img alt="User" class="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDiu2LPPGzfXy4WhsQb79Tce77jM0xg15beLaP_X7cs580Fb2HSGduwo0RwR-1G20EtDS6pEb0vYtjZfdCyv6LLp2mOziHfVeWvptNyv5FUGFm7e-8YojzVGDiAk9buYa3Hlnf0pwJKiJy7gOTp79r5laNS4oGkPmvjjij-dw69cyp2X9w5i3Ggd82TQ6MWZ5DAGTYgZJZ4cYupof87EmLW4-VNDhUMUUye7c44DyXSFwo94Wa6hVIfgatLbEOWnjiW7CewrsUKe9w"/>
                    </div>
                    <span class="font-['Inter'] text-[11px] font-bold uppercase tracking-widest text-stone-900 dark:text-white">Perfil</span>
                </div>
            </div>
        </nav>

        <div class="flex flex-col flex-1 min-w-0 ml-[256px]">
            <main class="flex-1 overflow-y-auto p-lg flex flex-col gap-lg bg-surface">
                <div class="flex justify-between items-end mb-2">
                    <div>
                        <h2 class="font-headline-md text-headline-md text-on-surface">Resumo Financeiro</h2>
                    </div>
                </div>

                <div class="flex gap-lg h-full pb-xl">
                    <div class="flex-1 bg-surface-container-lowest border border-outline-variant rounded-DEFAULT flex flex-col overflow-hidden">
                        <div class="p-md border-b border-outline-variant flex justify-between items-center bg-surface-container-low">
                            <h3 class="font-headline-sm text-headline-sm text-on-surface">Descontos Aplicados</h3>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse">
                                <thead>
                                    <tr class="border-b border-outline-variant bg-surface-bright">
                                        <th class="p-md font-label-md text-label-md text-on-surface-variant uppercase font-medium">Marca</th>
                                        <th class="p-md font-label-md text-label-md text-on-surface-variant uppercase font-medium">Família de Produto</th>
                                        <th class="p-md font-label-md text-label-md text-on-surface-variant uppercase font-medium text-right">Preço Base (€)</th>
                                        <th class="p-md font-label-md text-label-md text-on-surface-variant uppercase font-medium w-[140px]">Desconto (%)</th>
                                        <th class="p-md font-label-md text-label-md text-on-surface-variant uppercase font-medium text-right">Total Líquido (€)</th>
                                        <th class="p-md w-[60px]"></th>
                                    </tr>
                                </thead>
                                <tbody class="font-body-md text-on-surface">
                                    <tr class="border-b border-outline-variant hover:bg-surface-container-low transition-colors group">
                                        <td class="p-md font-medium flex items-center gap-3">
                                            <div class="w-2 h-2 rounded-full bg-blue-500"></div>
                                            Hager
                                        </td>
                                        <td class="p-md text-on-surface-variant">Aparelhagem Modular (MCB)</td>
                                        <td class="p-md text-right font-mono-sm">4,520.00</td>
                                        <td class="p-md">
                                            <input class="w-full bg-surface-container-lowest border border-outline-variant rounded-DEFAULT px-2 py-1 text-right focus:border-secondary focus:ring-1 focus:ring-secondary outline-none transition-all" type="text" value="35.0" />
                                        </td>
                                        <td class="p-md text-right font-mono-sm font-medium">2,938.00</td>
                                        <td class="p-md text-right">
                                            <button class="text-outline hover:text-on-surface opacity-0 group-hover:opacity-100 transition-opacity">
                                                <span class="material-symbols-outlined text-[18px]">more_vert</span>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="border-b border-outline-variant hover:bg-surface-container-low transition-colors group">
                                        <td class="p-md font-medium flex items-center gap-3">
                                            <div class="w-2 h-2 rounded-full bg-blue-500"></div>
                                            Hager
                                        </td>
                                        <td class="p-md text-on-surface-variant">Quadros e Armários (QGBT)</td>
                                        <td class="p-md text-right font-mono-sm">2,150.50</td>
                                        <td class="p-md">
                                            <input class="w-full bg-surface-container-lowest border border-outline-variant rounded-DEFAULT px-2 py-1 text-right focus:border-secondary focus:ring-1 focus:ring-secondary outline-none transition-all" type="text" value="28.5" />
                                        </td>
                                        <td class="p-md text-right font-mono-sm font-medium">1,537.61</td>
                                        <td class="p-md text-right">
                                            <button class="text-outline hover:text-on-surface opacity-0 group-hover:opacity-100 transition-opacity">
                                                <span class="material-symbols-outlined text-[18px]">more_vert</span>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="p-md mt-auto bg-surface-bright border-t border-outline-variant flex justify-between items-center">
                            <span class="font-body-md text-on-surface-variant">4 famílias listadas</span>
                            <div class="flex gap-md">
                                <span class="font-body-md text-on-surface-variant">Subtotal Bruto: <strong class="font-mono-sm text-on-surface">€ 7,835.50</strong></span>
                                <span class="font-body-md text-on-surface-variant">Subtotal Líquido: <strong class="font-mono-sm text-on-surface">€ 5,238.61</strong></span>
                            </div>
                        </div>
                    </div>

                    <div class="w-[340px] flex flex-col gap-lg flex-shrink-0">
                        <div class="bg-surface-container-lowest border border-outline-variant rounded-DEFAULT p-md">
                            <h3 class="font-headline-sm text-headline-sm text-on-surface mb-md flex items-center gap-2">
                                <span class="material-symbols-outlined text-[20px] text-secondary">tune</span>
                                Parâmetros Globais
                            </h3>
                            <div class="flex flex-col gap-md">
                                <div class="flex flex-col gap-xs">
                                    <label class="font-label-md text-label-md text-on-surface-variant uppercase flex justify-between">
                                        <span>Material Consumíveis</span>
                                        <span class="text-outline">%</span>
                                    </label>
                                    <input class="bg-surface-bright border border-outline-variant rounded-DEFAULT px-sm py-2 font-mono-sm text-on-surface focus:border-secondary focus:ring-1 focus:ring-secondary outline-none text-right transition-all" type="text" value="2.5" />
                                </div>
                                <div class="flex flex-col gap-xs">
                                    <label class="font-label-md text-label-md text-on-surface-variant uppercase flex justify-between">
                                        <span>Mão de Obra (MO)</span>
                                        <span class="text-outline">€/h</span>
                                    </label>
                                    <div class="flex gap-2">
                                        <input class="flex-1 bg-surface-bright border border-outline-variant rounded-DEFAULT px-sm py-2 font-mono-sm text-on-surface text-right" type="text" value="35.00" />
                                        <input class="w-[80px] bg-surface-bright border border-outline-variant rounded-DEFAULT px-sm py-2 font-mono-sm text-on-surface text-right" placeholder="Horas" type="text" value="48" />
                                    </div>
                                </div>
                            </div>
                            <button class="w-full mt-lg bg-surface-container border border-outline-variant text-on-surface rounded-DEFAULT py-2 px-4 hover:bg-surface-variant transition-colors font-label-md text-label-md uppercase tracking-wide">
                                Recalcular Custos
                            </button>
                        </div>

                        <div class="bg-surface-container-lowest border border-outline-variant rounded-DEFAULT p-md flex flex-col">
                            <h3 class="font-headline-sm text-headline-sm text-on-surface mb-md">Estrutura de Custos</h3>
                            <div class="flex flex-col gap-3 font-body-md">
                                <div class="flex justify-between items-center text-on-surface-variant">
                                    <span>Custo Base Material</span>
                                    <span class="font-mono-sm text-on-surface">€ 5,238.61</span>
                                </div>
                                <div class="h-px w-full bg-outline-variant my-1"></div>
                                <div class="bg-surface-container-low rounded-DEFAULT p-md border border-outline-variant flex flex-col items-end relative overflow-hidden">
                                    <div class="absolute left-0 top-0 bottom-0 w-1 bg-secondary"></div>
                                    <span class="font-label-md text-on-surface-variant uppercase tracking-wider mb-1">Preço Final Proposto</span>
                                    <span class="font-headline-lg text-[36px] leading-none font-bold text-secondary">€ 8,293.62</span>
                                </div>
                                <button class="w-full mt-4 bg-secondary text-on-secondary py-3 px-4 rounded-DEFAULT flex items-center justify-center gap-2 hover:bg-secondary/90 transition-colors shadow-sm">
                                    <span class="material-symbols-outlined text-[20px]">download</span>
                                    <span class="font-label-md text-label-md uppercase tracking-widest font-bold">Exportar Orçamento</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>
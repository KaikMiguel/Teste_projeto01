<!DOCTYPE html>
<html class="light" lang="pt-PT">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Perfil - ENG-QUADROS</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "surface": "#fcf8f7",
                        "tertiary-fixed": "#c5f31b",
                        "on-surface": "#1c1b1b",
                        "surface-container-low": "#f7f3f1",
                        "outline": "#767872",
                        "on-secondary-fixed-variant": "#394d00",
                        "on-error": "#ffffff",
                        "on-primary-fixed-variant": "#464743",
                        "inverse-on-surface": "#f4f0ef",
                        "on-primary-fixed": "#1a1c19",
                        "on-secondary": "#ffffff",
                        "surface-dim": "#ddd9d8",
                        "surface-container-lowest": "#ffffff",
                        "primary-fixed-dim": "#c7c7c1",
                        "surface-bright": "#fcf8f7",
                        "surface-container-high": "#ebe7e6",
                        "secondary-fixed": "#d0ee89",
                        "primary": "#5b5c58",
                        "outline-variant": "#c6c7c0",
                        "inverse-surface": "#313030",
                        "on-tertiary-container": "#fbffe4",
                        "on-surface-variant": "#454742",
                        "primary-container": "#747570",
                        "primary-fixed": "#e3e3dd",
                        "surface-tint": "#5d5f5a",
                        "on-primary": "#ffffff",
                        "on-secondary-container": "#526b14",
                        "on-primary-container": "#fdfdf7",
                        "inverse-primary": "#c7c7c1",
                        "on-tertiary-fixed": "#161e00",
                        "secondary-container": "#cdeb87",
                        "tertiary-container": "#647e00",
                        "surface-variant": "#e5e2e0",
                        "on-secondary-fixed": "#151f00",
                        "error-container": "#ffdad6",
                        "error": "#ba1a1a",
                        "on-error-container": "#93000a",
                        "secondary-fixed-dim": "#b4d170",
                        "tertiary-fixed-dim": "#abd600",
                        "on-tertiary": "#ffffff",
                        "tertiary": "#4f6300",
                        "on-background": "#1c1b1b",
                        "surface-container": "#f1edec",
                        "on-tertiary-fixed-variant": "#3c4d00",
                        "background": "#fcf8f7"
                    },
                    "borderRadius": {
                        "DEFAULT": "0.125rem",
                        "lg": "0.25rem",
                        "xl": "0.5rem",
                        "full": "0.75rem"
                    },
                    "spacing": {
                        "unit": "4px",
                        "lg": "24px",
                        "xs": "4px",
                        "xl": "48px",
                        "margin": "24px",
                        "sm": "8px",
                        "gutter": "16px",
                        "md": "16px"
                    },
                    "fontFamily": {
                        "headline-md": ["Inter"],
                        "headline-sm": ["Inter"],
                        "body-md": ["Inter"],
                        "body-lg": ["Inter"],
                        "label-md": ["Inter"],
                        "mono-sm": ["monospace"],
                        "headline-lg": ["Inter"]
                    },
                    "fontSize": {
                        "headline-md": ["24px", {"lineHeight": "1.2", "letterSpacing": "-0.01em", "fontWeight": "600"}],
                        "headline-sm": ["18px", {"lineHeight": "1.4", "fontWeight": "600"}],
                        "body-md": ["14px", {"lineHeight": "1.5", "fontWeight": "400"}],
                        "body-lg": ["16px", {"lineHeight": "1.6", "fontWeight": "400"}],
                        "label-md": ["12px", {"lineHeight": "1", "letterSpacing": "0.05em", "fontWeight": "500"}],
                        "mono-sm": ["12px", {"lineHeight": "1", "fontWeight": "400"}],
                        "headline-lg": ["32px", {"lineHeight": "1.2", "letterSpacing": "-0.02em", "fontWeight": "600"}]
                    }
                },
            },
        }
    </script>
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        body { font-family: 'Inter', sans-serif; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #c6c7c0; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #767872; }
    </style>
</head>
<body class="bg-background text-on-surface font-body-md text-body-md min-h-screen flex flex-col antialiased">

    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 border-b border-[#e1e2df] dark:border-stone-800">
        <div class="flex items-center gap-md">
            <span class="text-lg font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>
        </div>

        <div class="flex items-center gap-sm">
            <button class="flex items-center gap-2 px-3 py-1.5 text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 border border-transparent hover:border-stone-200 transition-all duration-200 rounded-lg group">
                <span class="material-symbols-outlined text-[20px] group-active:scale-90 transition-transform">save</span>
                <span class="text-[11px] font-bold uppercase tracking-widest">Save</span>
            </button>

            <button class="p-sm text-[#82837e] dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors active:opacity-80 rounded-full">
                <span class="material-symbols-outlined text-[24px]">notifications</span>
            </button>

            <a href="Home.html" class="ml-sm w-9 h-9 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-[#94b053] hover:border-[#94b053] hover:bg-white transition-all duration-200 shadow-sm">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">home</span>
            </a>
        </div>
    </header>

    <div class="flex pt-16 flex-1 h-screen overflow-hidden">
        
        <nav class="bg-white dark:bg-stone-950 fixed left-0 top-16 h-[calc(100vh-64px)] w-64 border-r border-[#e1e2df] dark:border-stone-800 flex flex-col pt-4 overflow-y-auto">
            <ul class="flex flex-col gap-unit">
                <li>
                    <a href="MaterialSurvey.html" class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest">
                        <span class="material-symbols-outlined text-[20px]">inventory_2</span>
                        Material
                    </a>
                </li>
                <li>
                    <a href="ElectricalDiagram.html" class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest">
                        <span class="material-symbols-outlined text-[20px]">account_tree</span>
                        Esquema
                    </a>
                </li>
                <li>
                    <a href="Layout.html" class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest">
                        <span class="material-symbols-outlined text-[20px]">grid_view</span>
                        Layout
                    </a>
                </li>
                <li>
                    <a href="#" class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest">
                        <span class="material-symbols-outlined text-[20px]">payments</span>
                        Orçamento
                    </a>
                </li>
            </ul>

            <div class="mt-auto pt-4 pb-8 border-t border-[#e1e2df] dark:border-stone-800 flex flex-col gap-unit">
                <a href="#" class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest">
                    <span class="material-symbols-outlined text-[20px]">settings</span>
                    Configurações
                </a>
                <a href="#" class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-red-600 dark:hover:text-red-400 transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest">
                    <span class="material-symbols-outlined text-[20px]">logout</span>
                    Logout
                </a>
                <div class="flex items-center gap-md px-lg py-sm mt-2 bg-stone-100 dark:bg-stone-900 text-stone-900 dark:text-white border-r-4 border-[#94b053]">
                    <div class="w-8 h-8 rounded-full bg-stone-200 overflow-hidden border border-stone-300 flex-shrink-0">
                        <img alt="User" class="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDiu2LPPGzfXy4WhsQb79Tce77jM0xg15beLaP_X7cs580Fb2HSGduwo0RwR-1G20EtDS6pEb0vYtjZfdCyv6LLp2mOziHfVeWvptNyv5FUGFm7e-8YojzVGDiAk9buYa3Hlnf0pwJKiJy7gOTp79r5laNS4oGkPmvjjij-dw69cyp2X9w5i3Ggd82TQ6MWZ5DAGTYgZJZ4cYupof87EmLW4-VNDhUMUUye7c44DyXSFwo94Wa6hVIfgatLbEOWnjiW7CewrsUKe9w"/>
                    </div>
                    <span class="font-['Inter'] text-[11px] font-bold uppercase tracking-widest">Perfil</span>
                </div>
            </div>
        </nav>

        <div class="flex flex-col flex-1 min-w-0 ml-[256px]">
            <main class="flex-1 overflow-y-auto p-lg flex flex-col gap-lg bg-surface">
                
                <div class="flex justify-between items-end mb-2">
                    <div>
                        <h2 class="font-headline-md text-headline-md text-on-surface">Gestão de Conta</h2>
                    </div>
                </div>

                <div class="max-w-7xl w-full grid grid-cols-1 lg:grid-cols-12 gap-lg pb-xl">
                    <div class="lg:col-span-7 space-y-lg">
                        <div class="bg-surface-container-lowest border border-outline-variant rounded-xl p-lg shadow-sm">
                            <h2 class="font-headline-md text-headline-md text-primary mb-lg flex items-center gap-2">
                                <span class="material-symbols-outlined text-secondary" data-icon="manage_accounts">manage_accounts</span>
                                Informações Pessoais
                            </h2>
                            
                            <div class="flex items-center gap-lg mb-xl pb-lg border-b border-surface-variant">
                                <div class="relative group">
                                    <img alt="João Silva Large" class="w-24 h-24 rounded-full border-2 border-secondary object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDiu2LPPGzfXy4WhsQb79Tce77jM0xg15beLaP_X7cs580Fb2HSGduwo0RwR-1G20EtDS6pEb0vYtjZfdCyv6LLp2mOziHfVeWvptNyv5FUGFm7e-8YojzVGDiAk9buYa3Hlnf0pwJKiJy7gOTp79r5laNS4oGkPmvjjij-dw69cyp2X9w5i3Ggd82TQ6MWZ5DAGTYgZJZ4cYupof87EmLW4-VNDhUMUUye7c44DyXSFwo94Wa6hVIfgatLbEOWnjiW7CewrsUKe9w"/>
                                    <button class="absolute bottom-0 right-0 bg-secondary text-on-secondary p-1 rounded-full border-2 border-surface-container-lowest hover:scale-105 transition-transform">
                                        <span class="material-symbols-outlined text-[18px]" data-icon="edit">edit</span>
                                    </button>
                                </div>
                                <div class="flex flex-col gap-sm">
                                    <h3 class="font-headline-sm text-headline-sm text-on-surface">João Silva</h3>
                                    <p class="font-body-md text-body-md text-on-surface-variant">Senior Engineer & Estimator</p>
                                    <div class="flex gap-sm mt-2">
                                        <button class="bg-black text-white px-4 py-2 rounded font-label-md text-label-md uppercase tracking-wider hover:opacity-80 transition-opacity">
                                            Upload Photo
                                        </button>
                                        <button class="border border-black text-black px-4 py-2 rounded font-label-md text-label-md uppercase tracking-wider hover:bg-stone-100 transition-colors">
                                            Remove
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-lg mb-xl">
                                <div class="space-y-2">
                                    <label class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant">Full Name</label>
                                    <input class="w-full bg-surface-container-low border border-outline-variant rounded px-md py-sm font-body-md text-body-md text-on-surface focus:outline-none focus:border-primary transition-colors cursor-not-allowed" readonly type="text" value="João Silva"/>
                                </div>
                                <div class="space-y-2">
                                    <label class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant">Email Address</label>
                                    <input class="w-full bg-surface-container-low border border-outline-variant rounded px-md py-sm font-body-md text-body-md text-on-surface focus:outline-none focus:border-primary transition-colors cursor-not-allowed" readonly type="email" value="joao.silva@hager.pt"/>
                                </div>
                            </div>

                            <div class="space-y-lg pt-lg border-t border-surface-variant">
                                <h3 class="font-headline-sm text-headline-sm text-primary">Alterar Palavra-passe</h3>
                                <div class="grid grid-cols-1 gap-md">
                                    <div class="space-y-2">
                                        <label class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant">Current Password</label>
                                        <input class="w-full bg-surface border border-outline-variant rounded px-md py-sm font-body-md text-body-md focus:outline-none focus:border-secondary transition-colors" placeholder="••••••••" type="password"/>
                                    </div>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-md">
                                        <div class="space-y-2">
                                            <label class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant">New Password</label>
                                            <input class="w-full bg-surface border border-outline-variant rounded px-md py-sm font-body-md text-body-md focus:outline-none focus:border-secondary transition-colors" placeholder="••••••••" type="password"/>
                                        </div>
                                        <div class="space-y-2">
                                            <label class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant">Confirm New Password</label>
                                            <input class="w-full bg-surface border border-outline-variant rounded px-md py-sm font-body-md text-body-md focus:outline-none focus:border-secondary transition-colors" placeholder="••••••••" type="password"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex justify-end pt-md">
                                    <button class="bg-secondary text-on-secondary px-lg py-sm rounded-lg font-label-md text-label-md uppercase tracking-wider hover:bg-opacity-90 flex items-center gap-2">
                                        <span class="material-symbols-outlined text-[18px]" data-icon="save">save</span>
                                        Save Changes
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="lg:col-span-5 space-y-lg">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-md">
                            <div class="bg-surface-container-lowest border border-outline-variant p-lg rounded-xl shadow-sm">
                                <span class="material-symbols-outlined text-secondary mb-md text-3xl" data-icon="account_balance_wallet">account_balance_wallet</span>
                                <div class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant mb-1">Total Budgeted Value</div>
                                <div class="font-headline-md text-headline-md text-primary">€ 1,240,500.00</div>
                                <div class="mt-2 text-[10px] text-on-secondary-fixed-variant font-bold flex items-center gap-1">
                                    <span class="material-symbols-outlined text-[12px]" data-icon="trending_up">trending_up</span>
                                    +12% from last month
                                </div>
                            </div>
                            <div class="bg-surface-container-lowest border border-outline-variant p-lg rounded-xl shadow-sm">
                                <span class="material-symbols-outlined text-secondary mb-md text-3xl" data-icon="task">task</span>
                                <div class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant mb-1">Projects Created</div>
                                <div class="font-headline-md text-headline-md text-primary">42 projects</div>
                                <div class="mt-2 text-[10px] text-on-surface-variant font-bold flex items-center gap-1">
                                    <span class="material-symbols-outlined text-[12px]" data-icon="history">history</span>
                                    8 pending review
                                </div>
                            </div>
                        </div>

                        <div class="bg-surface-container-lowest border border-outline-variant rounded-xl shadow-sm overflow-hidden">
                            <div class="p-lg border-b border-outline-variant flex justify-between items-center">
                                <h2 class="font-headline-sm text-headline-sm text-primary flex items-center gap-2">
                                    <span class="material-symbols-outlined text-secondary" data-icon="list_alt">list_alt</span>
                                    Recent Budgets
                                </h2>
                                <button class="text-secondary font-label-md text-label-md uppercase tracking-wider hover:underline">View All</button>
                            </div>
                            <div class="overflow-x-auto">
                                <table class="w-full border-collapse">
                                    <thead>
                                        <tr class="bg-surface-container-low border-b border-outline-variant">
                                            <th class="px-lg py-sm text-left font-label-md text-label-md uppercase tracking-wider text-on-surface-variant">Project Name</th>
                                            <th class="px-lg py-sm text-left font-label-md text-label-md uppercase tracking-wider text-on-surface-variant">Date</th>
                                            <th class="px-lg py-sm text-right font-label-md text-label-md uppercase tracking-wider text-on-surface-variant">Total Value</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-outline-variant">
                                        <tr class="hover:bg-surface-container-high transition-colors">
                                            <td class="px-lg py-md">
                                                <div class="font-body-md text-body-md text-on-surface font-semibold">Hager Office HQ</div>
                                                <div class="text-[10px] text-on-surface-variant">Electrical Infrastructure</div>
                                            </td>
                                            <td class="px-lg py-md font-body-md text-body-md text-on-surface">Oct 24, 2023</td>
                                            <td class="px-lg py-md text-right font-body-md text-body-md text-secondary font-bold">€ 45,200.00</td>
                                        </tr>
                                        <tr class="hover:bg-surface-container-high transition-colors">
                                            <td class="px-lg py-md">
                                                <div class="font-body-md text-body-md text-on-surface font-semibold">Industrial Plant V2</div>
                                                <div class="text-[10px] text-on-surface-variant">Switchboard Design</div>
                                            </td>
                                            <td class="px-lg py-md font-body-md text-body-md text-on-surface">Oct 20, 2023</td>
                                            <td class="px-lg py-md text-right font-body-md text-body-md text-secondary font-bold">€ 128,900.00</td>
                                        </tr>
                                        <tr class="hover:bg-surface-container-high transition-colors">
                                            <td class="px-lg py-md">
                                                <div class="font-body-md text-body-md text-on-surface font-semibold">Data Center Alpha</div>
                                                <div class="text-[10px] text-on-surface-variant">UPS Integration</div>
                                            </td>
                                            <td class="px-lg py-md font-body-md text-body-md text-on-surface">Oct 15, 2023</td>
                                            <td class="px-lg py-md text-right font-body-md text-body-md text-secondary font-bold">€ 890,400.00</td>
                                        </tr>
                                        <tr class="hover:bg-surface-container-high transition-colors">
                                            <td class="px-lg py-md">
                                                <div class="font-body-md text-body-md text-on-surface font-semibold">Residential Block B</div>
                                                <div class="text-[10px] text-on-surface-variant">General Budgeting</div>
                                            </td>
                                            <td class="px-lg py-md font-body-md text-body-md text-on-surface">Oct 08, 2023</td>
                                            <td class="px-lg py-md text-right font-body-md text-body-md text-secondary font-bold">€ 176,000.00</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </main>
        </div>
    </div>
</body>
</html>
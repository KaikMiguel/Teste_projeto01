<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet">
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "secondary-container": "#cdeb87",
                        "primary-container": "#747570",
                        "surface-variant": "#e5e2e0",
                        "on-background": "#1c1b1b",
                        "primary": "#5b5c58",
                        "inverse-on-surface": "#f4f0ef",
                        "on-surface-variant": "#454742",
                        "on-surface": "#1c1b1b",
                        "error": "#ba1a1a",
                        "secondary-fixed": "#d0ee89",
                        "on-primary-fixed": "#1a1c19",
                        "tertiary-fixed-dim": "#abd600",
                        "surface": "#fcf8f7",
                        "secondary-container-low": "#f7f3f1",
                        "on-tertiary": "#ffffff",
                        "primary-fixed": "#e3e3dd",
                        "tertiary": "#4f6300",
                        "on-error": "#ffffff",
                        "on-tertiary-fixed-variant": "#3c4d00",
                        "surface-container": "#f1edec",
                        "tertiary-fixed": "#c5f31b",
                        "outline": "#767872",
                        "surface-container-high": "#ebe7e6",
                        "primary-fixed-dim": "#c7c7c1",
                        "surface-container-highest": "#e5e2e0",
                        "on-tertiary-fixed": "#161e00",
                        "on-tertiary-container": "#fbffe4",
                        "on-secondary": "#ffffff",
                        "inverse-surface": "#313030",
                        "outline-variant": "#c6c7c0",
                        "on-primary-container": "#fdfdf7",
                        "tertiary-container": "#647e00",
                        "on-secondary-container": "#526b14",
                        "surface-container-lowest": "#ffffff",
                        "background": "#fcf8f7",
                        "surface-tint": "#5d5f5a",
                        "surface-bright": "#fcf8f7",
                        "inverse-primary": "#c7c7c1",
                        "error-container": "#ffdad6",
                        "on-secondary-fixed-variant": "#394d00",
                        "on-primary-fixed-variant": "#464743",
                        "secondary": "#4e660f",
                        "on-secondary-fixed": "#151f00",
                        "on-error-container": "#93000a",
                        "surface-dim": "#ddd9d8"
                    },
                    "borderRadius": {
                        "DEFAULT": "0.125rem",
                        "lg": "0.25rem",
                        "xl": "0.5rem",
                        "full": "0.75rem"
                    },
                    "spacing": {
                        "unit": "4px",
                        "gutter": "16px",
                        "margin": "24px",
                        "xs": "4px",
                        "sm": "8px",
                        "md": "16px",
                        "xl": "48px",
                        "lg": "24px"
                    },
                    "fontFamily": {
                        "headline-sm": ["Inter"],
                        "headline-lg": ["Inter"],
                        "headline-md": ["Inter"],
                        "body-md": ["Inter"],
                        "mono-sm": ["monospace"],
                        "label-md": ["Inter"],
                        "body-lg": ["Inter"]
                    },
                    "fontSize": {
                        "headline-sm": ["18px", {"lineHeight": "1.4", "fontWeight": "600"}],
                        "headline-lg": ["32px", {"lineHeight": "1.2", "letterSpacing": "-0.02em", "fontWeight": "600"}],
                        "headline-md": ["24px", {"lineHeight": "1.2", "letterSpacing": "-0.01em", "fontWeight": "600"}],
                        "body-md": ["14px", {"lineHeight": "1.5", "fontWeight": "400"}],
                        "mono-sm": ["12px", {"lineHeight": "1", "fontWeight": "400"}],
                        "label-md": ["12px", {"lineHeight": "1", "letterSpacing": "0.05em", "fontWeight": "500"}],
                        "body-lg": ["16px", {"lineHeight": "1.6", "fontWeight": "400"}]
                    }
                },
            },
        }
    </script>
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-background text-on-surface flex min-h-screen">

    <!-- SideNavBar -->
    <aside class="docked fixed left-0 top-0 h-full w-64 z-40 bg-surface-container-low border-r border-outline-variant flex flex-col gap-sm py-lg overflow-y-auto">
        <nav class="bg-white dark:bg-stone-950 fixed left-0 top-16 h-[calc(100vh-64px)] w-64 border-r border-[#e1e2df] dark:border-stone-800 flex flex-col pt-4 overflow-y-auto">
            <ul class="flex flex-col gap-unit">
                <li>
                    <a class="flex items-center gap-md px-lg py-sm bg-stone-100 dark:bg-stone-900 text-stone-900 dark:text-white border-r-4 border-[#94b053] font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                        <span class="material-symbols-outlined text-[20px]" style="font-variation-settings: 'FILL' 1;">bar_chart</span>
                        Dashboard
                    </a>
                </li>
            </ul>

            <div class="mt-auto pt-4 pb-8 border-t border-[#e1e2df] dark:border-stone-800 flex flex-col gap-unit">
                <a class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                    <span class="material-symbols-outlined text-[20px]">settings</span>
                    Configurações
                </a>
                <a class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-red-600 dark:hover:text-red-400 transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" href="#">
                    <span class="material-symbols-outlined text-[20px]">logout</span>
                    Logout
                </a>
                <div class="flex items-center gap-md px-lg py-sm mt-2">
                    <div class="w-8 h-8 rounded-full bg-stone-200 overflow-hidden border border-stone-300 flex-shrink-0">
                        <img alt="User" class="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDiu2LPPGzfXy4WhsQb79Tce77jM0xg15beLaP_X7cs580Fb2HSGduwo0RwR-1G20EtDS6pEb0vYtjZfdCyv6LLp2mOziHfVeWvptNyv5FUGFm7e-8YojzVGDiAk9buYa3Hlnf0pwJKiJy7gOTp79r5laNS4oGkPmvjjij-dw69cyp2X9w5i3Ggd82TQ6MWZ5DAGTYgZJZ4cYupof87EmLW4-VNDhUMUUye7c44DyXSFwo94Wa6hVIfgatLbEOWnjiW7CewrsUKe9w"/>
                    </div>
                    <span class="font-['Inter'] text-[11px] font-bold uppercase tracking-widest text-stone-900 dark:text-white">Perfil</span>
                </div>
            </div>
        </nav>

    </aside>

    <!-- Main Content Area -->
    <main class="ml-64 flex-grow flex flex-col min-h-screen pt-16">
        

        <!-- TopNavBar Corrigido -->
        <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 left-0 border-b border-[#e1e2df] dark:border-stone-800">
            <div class="flex items-center">
                <span class="text-base font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">
                    ENG-QUADROS
                </span>
            </div>

            <div class="flex items-center gap-4">

                <button class="p-2 text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors rounded-full flex items-center justify-center">
                    <span class="material-symbols-outlined text-[22px]">notifications</span>
                </button>

            </div>
        </header>

        <!-- Canvas -->
        <section class="p-margin flex flex-col gap-lg max-w-7xl mx-auto w-full">
            
            <!-- Statistics Panel (Bento Style) -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-lg">
                <div class="col-span-1 md:col-span-2 bg-surface-container-lowest p-lg rounded-xl border border-outline-variant flex flex-col justify-between h-32 relative overflow-hidden">
                    <div class="z-10">
                        <p class="text-label-md font-label-md uppercase text-on-surface-variant mb-xs">Total de Artigos na Base de Dados</p>
                        <h2 class="font-headline-lg text-headline-lg text-primary">45.280</h2>
                    </div>
                    <div class="absolute -right-4 -bottom-4 opacity-5 rotate-12">
                        <span class="material-symbols-outlined text-[120px]" data-icon="inventory_2">inventory_2</span>
                    </div>
                    <div class="flex items-center gap-xs text-secondary font-label-md text-label-md">
                        <span class="material-symbols-outlined text-sm" data-icon="trending_up">trending_up</span>
                        <span class="">+1.2k este mês</span>
                    </div>
                </div>
                
                <div class="col-span-1 bg-surface-container-lowest p-lg rounded-xl border border-outline-variant flex flex-col justify-between h-32">
                    <div>
                        <p class="text-label-md font-label-md uppercase text-on-surface-variant mb-xs">Utilizadores Ativos</p>
                        <h2 class="font-headline-lg text-headline-lg text-primary">12</h2>
                    </div>
                    <div class="flex items-center gap-xs text-secondary font-label-md text-label-md">
                        <span class="inline-block w-2 h-2 rounded-full bg-tertiary-fixed-dim"></span>
                        <span class="">Sessões em tempo real</span>
                    </div>
                </div>
                
                <div class="col-span-1 bg-secondary p-lg rounded-xl border border-secondary flex flex-col justify-between h-32 text-on-secondary">
                    <div>
                        <p class="text-label-md font-label-md uppercase opacity-80 mb-xs">Gestão de Catálogo</p>
                        <p class="font-headline-sm text-headline-sm">Ações Rápidas</p>
                    </div>
                    <button class="flex items-center justify-center gap-xs bg-white text-secondary py-xs px-sm rounded font-label-md text-label-md hover:bg-secondary-container transition-colors">
                        <span class="material-symbols-outlined text-sm" data-icon="upload_file">upload_file</span>
                        Importar Tabela (CSV)
                    </button>
                </div>
            </div>

            <!-- Content Grid: User Management Table -->
            <div class="grid grid-cols-1 gap-lg items-start">
                
                <!-- Expanded User Management Table -->
                <div class="bg-surface-container-lowest rounded-xl border border-outline-variant overflow-hidden">
                    <div class="p-lg border-b border-outline-variant flex justify-between items-center">
                        <div class="flex items-center gap-sm">
                            <span class="material-symbols-outlined text-secondary" data-icon="group">group</span>
                            <h3 class="font-headline-sm text-headline-sm">Gestão de Utilizadores</h3>
                        </div>
                        <button class="text-secondary border border-secondary px-md py-xs rounded font-label-md text-label-md hover:bg-secondary-container transition-colors flex items-center gap-xs">
                            <span class="material-symbols-outlined text-sm" data-icon="person_add">person_add</span>
                            Novo Utilizador
                        </button>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead>
                                <tr class="bg-surface-container-high text-on-surface-variant">
                                    <th class="px-lg py-md font-label-md text-label-md uppercase tracking-wider">Nome</th>
                                    <th class="px-lg py-md font-label-md text-label-md uppercase tracking-wider">Email</th>
                                    <th class="px-lg py-md font-label-md text-label-md uppercase tracking-wider">Cargo</th>
                                    <th class="px-lg py-md font-label-md text-label-md uppercase tracking-wider">Estado</th>
                                    <th class="px-lg py-md font-label-md text-label-md uppercase tracking-wider">Ações</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-outline-variant">
                                <tr class="hover:bg-surface-container-low transition-colors">
                                    <td class="px-lg py-md flex items-center gap-md">
                                        <div class="w-8 h-8 rounded bg-primary-fixed-dim flex items-center justify-center text-primary font-bold text-xs">MA</div>
                                        <span class="text-body-md font-medium">Manuel Almeida</span>
                                    </td>
                                    <td class="px-lg py-md text-body-md text-on-surface-variant">m.almeida@hager.pt</td>
                                    <td class="px-lg py-md">
                                        <select class="bg-transparent border border-outline-variant rounded px-sm py-1 text-xs focus:ring-0 focus:border-secondary">
                                            <option selected="">Admin</option>
                                            <option>Engenheiro</option>
                                            <option>Visualizador</option>
                                        </select>
                                    </td>
                                    <td class="px-lg py-md">
                                        <label class="inline-flex items-center cursor-pointer">
                                            <input checked="" class="sr-only peer" type="checkbox">
                                            <div class="relative w-9 h-5 bg-outline-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-secondary"></div>
                                        </label>
                                    </td>
                                    <td class="px-lg py-md">
                                        <button class="text-on-surface-variant hover:text-primary"><span class="material-symbols-outlined text-xl" data-icon="more_vert">more_vert</span></button>
                                    </td>
                                </tr>
                                
                                <tr class="hover:bg-surface-container-low transition-colors">
                                    <td class="px-lg py-md flex items-center gap-md">
                                        <div class="w-8 h-8 rounded bg-secondary-fixed-dim flex items-center justify-center text-secondary font-bold text-xs">SR</div>
                                        <span class="text-body-md font-medium">Sara Rodrigues</span>
                                    </td>
                                    <td class="px-lg py-md text-body-md text-on-surface-variant">s.rodrigues@eng.com</td>
                                    <td class="px-lg py-md">
                                        <select class="bg-transparent border border-outline-variant rounded px-sm py-1 text-xs focus:ring-0 focus:border-secondary">
                                            <option>Admin</option>
                                            <option selected="">Engenheiro</option>
                                            <option>Visualizador</option>
                                        </select>
                                    </td>
                                    <td class="px-lg py-md">
                                        <label class="inline-flex items-center cursor-pointer">
                                            <input checked="" class="sr-only peer" type="checkbox">
                                            <div class="relative w-9 h-5 bg-outline-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-secondary"></div>
                                        </label>
                                    </td>
                                    <td class="px-lg py-md">
                                        <button class="text-on-surface-variant hover:text-primary"><span class="material-symbols-outlined text-xl" data-icon="more_vert">more_vert</span></button>
                                    </td>
                                </tr>
                                
                                <tr class="hover:bg-surface-container-low transition-colors">
                                    <td class="px-lg py-md flex items-center gap-md">
                                        <div class="w-8 h-8 rounded bg-primary-container flex items-center justify-center text-white font-bold text-xs">TC</div>
                                        <span class="text-body-md font-medium">Tiago Costa</span>
                                    </td>
                                    <td class="px-lg py-md text-body-md text-on-surface-variant">t.costa@partner.org</td>
                                    <td class="px-lg py-md">
                                        <select class="bg-transparent border border-outline-variant rounded px-sm py-1 text-xs focus:ring-0 focus:border-secondary">
                                            <option>Admin</option>
                                            <option>Engenheiro</option>
                                            <option selected="">Visualizador</option>
                                        </select>
                                    </td>
                                    <td class="px-lg py-md">
                                        <label class="inline-flex items-center cursor-pointer">
                                            <input class="sr-only peer" type="checkbox">
                                            <div class="relative w-9 h-5 bg-outline-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-secondary"></div>
                                        </label>
                                    </td>
                                    <td class="px-lg py-md">
                                        <button class="text-on-surface-variant hover:text-primary"><span class="material-symbols-outlined text-xl" data-icon="more_vert">more_vert</span></button>
                                    </td>
                                </tr>
                                
                                <tr class="hover:bg-surface-container-low transition-colors">
                                    <td class="px-lg py-md flex items-center gap-md">
                                        <div class="w-8 h-8 rounded bg-primary-container flex items-center justify-center text-white font-bold text-xs">TC</div>
                                        <span class="text-body-md font-medium">Tiago Costa</span>
                                    </td>
                                    <td class="px-lg py-md text-body-md text-on-surface-variant">t.costa@partner.org</td>
                                    <td class="px-lg py-md">
                                        <select class="bg-transparent border border-outline-variant rounded px-sm py-1 text-xs focus:ring-0 focus:border-secondary">
                                            <option>Admin</option>
                                            <option>Engenheiro</option>
                                            <option selected="">Visualizador</option>
                                        </select>
                                    </td>
                                    <td class="px-lg py-md">
                                        <label class="inline-flex items-center cursor-pointer">
                                            <input class="sr-only peer" type="checkbox">
                                            <div class="relative w-9 h-5 bg-outline-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-secondary"></div>
                                        </label>
                                    </td>
                                    <td class="px-lg py-md">
                                        <button class="text-on-surface-variant hover:text-primary"><span class="material-symbols-outlined text-xl" data-icon="more_vert">more_vert</span></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="p-md bg-surface-container-low flex justify-center">
                        <button class="text-label-md font-label-md uppercase text-primary hover:underline">Ver todos os 24 utilizadores</button>
                    </div>
                </div>
            </div>

            <!-- New Full-Width Catalog Management Section -->
            <div class="bg-surface-container-lowest p-lg rounded-xl border border-outline-variant">
                <div class="flex items-center gap-sm mb-lg border-b border-outline-variant pb-md">
                    <span class="material-symbols-outlined text-secondary" data-icon="database">database</span>
                    <h3 class="font-headline-sm text-headline-sm">Gestão de Catálogo</h3>
                </div>
                
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-xl items-center">
                    <div>
                        <p class="text-body-md text-on-surface-variant mb-lg">Atualize a base de dados industrial importando as tabelas de preços e novos componentes fornecidos pelos fabricantes.</p>
                        <button class="w-full bg-secondary text-on-secondary py-md rounded-lg font-headline-sm text-headline-sm flex items-center justify-center gap-md hover:opacity-90 transition-opacity">
                            <span class="material-symbols-outlined" data-icon="upload_file">upload_file</span>
                            Importar Tabela de Preços
                        </button>
                    </div>
                    
                    <div class="border-2 border-dashed border-outline-variant rounded-lg p-xl flex flex-col items-center justify-center text-center gap-md hover:bg-surface-container-low transition-colors cursor-pointer group">
                        <div class="w-12 h-12 bg-surface-container-high rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                            <span class="material-symbols-outlined text-primary" data-icon="file_open">file_open</span>
                        </div>
                        <div>
                            <p class="font-label-md text-label-md uppercase font-bold text-on-surface">Arraste os ficheiros aqui</p>
                            <p class="text-xs text-on-surface-variant mt-xs">Suporta .xlsx, .csv até 50MB</p>
                        </div>
                    </div>
                </div>
            </div>
            
        </section>
    </main>

</body>
</html>
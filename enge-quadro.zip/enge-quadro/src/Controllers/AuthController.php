<?php
// src/Controllers/AuthController.php

require_once __DIR__ . '/../DAO/UserDAO.php';
require_once __DIR__ . '/../Utils/PasswordUtils.php';

class AuthController {
    private $userDAO;

    public function __construct() {
        $this->userDAO = new UserDAO();
        // Garante que a sessão está ativa para podermos salvar e ler os erros/dados do utilizador
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    /**
     * Exibir o ecrã de login (GET)
     * Rota: /enge-quadro/login
     */
    public function showLogin() {
        // Se o utilizador já tiver uma sessão ativa, manda-o direto para a Home
        if (isset($_SESSION['user_id'])) {
            header('Location: /enge-quadro/home');
            exit();
        }
        
        // Caso contrário, carrega a View do login
        require_once __DIR__ . '/../Views/login.php';
    }

    /**
     * Processar o formulário de login (POST) - MODO SEGURO DEFINITIVO
     */
    public function login() {
        // 1. Captura o email e a password sem alterar os caracteres
        $email = isset($_POST['email']) ? trim($_POST['email']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';

        if (empty($email) || empty($password)) {
            $_SESSION['error'] = "Por favor, preencha todos os campos.";
            header("Location: /enge-quadro/login");
            exit();
        }

        // 2. Procura o utilizador na Base de Dados pelo email
        $user = $this->userDAO->findByEmail($email);

        // 3. Validação segura usando o password_verify contra o hash corrigido
        if ($user && $user->estado === 'ativo' && password_verify($password, $user->password_hash)) {
            
            // Gravar dados oficiais na sessão
            $_SESSION['user_id'] = $user->id;
            $_SESSION['nome'] = $user->nome;
            $_SESSION['email'] = $user->email;
            $_SESSION['tipo_acesso'] = $user->tipo_acesso;

            unset($_SESSION['error']);

            // 4. Redireciona para a Home
            header("Location: /enge-quadro/home");
            exit();
        } else {
            // Se falhar, define o erro e volta para o login
            $_SESSION['error'] = "E-mail ou password incorretos!";
            header("Location: /enge-quadro/login");
            exit();
        }
    }

    /**
     * Efetuar o logout do sistema
     */
    public function logout() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        session_destroy();
        header("Location: /enge-quadro/login");
        exit();
    }
}
<?php
// src/Controllers/ProjectController.php

require_once __DIR__ . '/../DAO/ProjectDAO.php';

class ProjectController {
    private $projectDAO;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION['user_id'])) {
            header('Location: /enge-quadro/login');
            exit();
        }
        $this->projectDAO = new ProjectDAO();
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $projectName = isset($_POST['project_name']) ? trim($_POST['project_name']) : '';
            $client = isset($_POST['client']) ? trim($_POST['client']) : '';
            $commercialId = isset($_POST['commercial_id']) ? intval($_POST['commercial_id']) : 0;

            if (empty($projectName) || empty($client) || $commercialId === 0) {
                $_SESSION['error'] = "Todos os campos são obrigatórios.";
                header('Location: /enge-quadro/home');
                exit();
            }

            $projectName = preg_replace('/\s+/', ' ', $projectName);
            $client = preg_replace('/\s+/', ' ', $client);

            $this->projectDAO->createProject($projectName, $client, $commercialId);
            header('Location: /enge-quadro/home');
            exit();
        }
    }

    public function delete() {
        $projectId = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
        if ($projectId > 0) {
            $this->projectDAO->deleteProject($projectId);
        }
        header('Location: /enge-quadro/home');
        exit();
    }
}
<?php
// src/Controllers/HomeController.php

require_once __DIR__ . '/../DAO/ProjectDAO.php';

class HomeController {
    private $projectDAO;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        // Proteção de Rota: Se não houver sessão ativa, expulsa para o login
        if (!isset($_SESSION['user_id'])) {
            header('Location: /enge-quadro/login');
            exit();
        }
        $this->projectDAO = new ProjectDAO();
    }

    /**
     * Renderizar a página principal com os dados reais
     */
    public function index() {
        // O controlador recolhe os dados do Model/DAO
        $commercials = $this->projectDAO->getAllActiveCommercials();
        $projects = $this->projectDAO->getAllProjects();

        // E disponibiliza-os para a View (as variáveis ficam acessíveis no require)
        require_once __DIR__ . '/../Views/home.php';
    }
}
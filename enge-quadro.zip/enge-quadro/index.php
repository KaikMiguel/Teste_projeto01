<?php
// index.php - O Front Controller (Roteador) do Enge-Quadro

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Importar os controladores necessários
require_once __DIR__ . '/src/Controllers/AuthController.php';
require_once __DIR__ . '/src/Controllers/HomeController.php';
require_once __DIR__ . '/src/Controllers/ProjectController.php';
require_once __DIR__ . '/src/Controllers/MaterialSurveyController.php'; // Novo Controlador Especializado

$route = $_SERVER['REQUEST_URI'];
$basePath = '/enge-quadro'; 

$route = str_replace($basePath, '', $route);
$route = parse_url($route, PHP_URL_PATH);

// CORREÇÃO: Removemos a instanciação global daqui para evitar que os construtores
// que barram utilizadores corram em rotas públicas como o '/login'.

switch ($route) {
    case '/':
    case '/home':
        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: ' . $basePath . '/login');
            exit;
        }
        $homeController = new HomeController();
        $homeController->index();
        break;

    case '/login':
        $authController = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $authController->login();
        } else {
            $authController->showLogin();
        }
        break;

    case '/logout':
        $authController = new AuthController();
        $authController->logout();
        break;

    case '/projects/create':
        $projectController = new ProjectController();
        $projectController->store();
        break;

    case '/projects/delete':
        $projectController = new ProjectController();
        $projectController->delete();
        break;

    case '/project/material-survey':
        $materialSurveyController = new MaterialSurveyController();
        $materialSurveyController->materialSurvey();
        break;

    case '/boards/create':
        $materialSurveyController = new MaterialSurveyController();
        $materialSurveyController->createBoard();
        break;

    case '/boards/delete':
        $materialSurveyController = new MaterialSurveyController();
        $materialSurveyController->deleteBoard();
        break;

    default:
        http_response_code(404);
        echo "Página não encontrada.";
        break;
}
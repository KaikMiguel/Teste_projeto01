<?php
// config.php - Credenciais Globais do Enge-Quadro

define('DB_HOST', 'localhost');
define('DB_NAME', 'enge_quadro'); 
define('DB_USER', 'root');
define('DB_PASS', '');            // No XAMPP por padrão a password é vazia


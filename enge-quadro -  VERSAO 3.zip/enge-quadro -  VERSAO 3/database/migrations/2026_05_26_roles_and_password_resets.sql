CREATE TABLE IF NOT EXISTS roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_views (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL,
  path VARCHAR(160) NOT NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS role_view_permissions (
  role_id INT NOT NULL,
  view_id INT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (role_id, view_id),
  CONSTRAINT fk_role_view_permissions_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  CONSTRAINT fk_role_view_permissions_view FOREIGN KEY (view_id) REFERENCES app_views(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  token_hash VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  used_at DATETIME DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_password_reset_user (user_id),
  INDEX idx_password_reset_expiry (expires_at),
  CONSTRAINT fk_password_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO roles (nome) VALUES
('admin'),
('user')
ON DUPLICATE KEY UPDATE nome = VALUES(nome);

INSERT INTO app_views (nome, path) VALUES
('Home', '/home'),
('Library', '/library'),
('Perfil', '/profile'),
('Material', '/project/material-survey'),
('Material Alias', '/material-survey'),
('Esquema', '/electrical-diagram'),
('Layout', '/layout'),
('Orçamento', '/estimate'),
('Admin Painel', '/admin-panel')
ON DUPLICATE KEY UPDATE nome = VALUES(nome);

INSERT IGNORE INTO role_view_permissions (role_id, view_id)
SELECT r.id, v.id
FROM roles r
JOIN app_views v
WHERE r.nome = 'admin';

INSERT IGNORE INTO role_view_permissions (role_id, view_id)
SELECT r.id, v.id
FROM roles r
JOIN app_views v ON v.path IN (
  '/home',
  '/library',
  '/profile',
  '/project/material-survey',
  '/material-survey',
  '/electrical-diagram',
  '/layout',
  '/estimate'
)
WHERE r.nome = 'user';

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS role_id INT NULL AFTER remember_token;

UPDATE users u
JOIN roles r ON r.nome = CASE WHEN u.tipo_acesso IN ('admin', 'cliente') THEN 'admin' ELSE 'user' END
SET u.role_id = r.id
WHERE u.role_id IS NULL;

ALTER TABLE users
  ADD INDEX IF NOT EXISTS idx_users_role_id (role_id);

ALTER TABLE roles
  DROP COLUMN IF EXISTS slug;

ALTER TABLE users
  DROP COLUMN IF EXISTS tipo_acesso;

UPDATE roles SET nome = 'admin' WHERE slug = 'admin';
UPDATE roles SET nome = 'user' WHERE slug = 'user';

ALTER TABLE roles
  DROP INDEX slug;

ALTER TABLE roles
  ADD UNIQUE KEY nome (nome);

ALTER TABLE roles
  DROP COLUMN slug;

ALTER TABLE users
  DROP COLUMN tipo_acesso;

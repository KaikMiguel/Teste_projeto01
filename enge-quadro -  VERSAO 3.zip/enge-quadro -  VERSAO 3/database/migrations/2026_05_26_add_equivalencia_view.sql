INSERT INTO app_views (nome, path) VALUES
('Equivalência', '/equivalencia')
ON DUPLICATE KEY UPDATE nome = VALUES(nome);

INSERT IGNORE INTO role_view_permissions (role_id, view_id)
SELECT r.id, v.id
FROM roles r
JOIN app_views v ON v.path = '/equivalencia'
WHERE r.nome IN ('admin', 'user');

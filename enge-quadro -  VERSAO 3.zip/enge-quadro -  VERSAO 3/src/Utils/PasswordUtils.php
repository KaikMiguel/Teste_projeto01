<?php
// src/Utils/PasswordUtils.php

class PasswordUtils {
    /**
     * Limpa os dados vindos dos formulários (Proteção básica)
     */
    public static function sanitize($data) {
        return htmlspecialchars(strip_tags(trim($data)));
    }

    /**
     * Verifica se a password digitada bate certo com o hash seguro da Base de Dados
     */
    public static function verify($password, $hash) {
        return password_verify($password, $hash);
    }

    public static function validateStrength($password) {
        $errors = [];

        if (strlen($password) < 8) {
            $errors[] = 'ter pelo menos 8 caracteres';
        }
        if (!preg_match('/[A-Z]/', $password)) {
            $errors[] = 'ter pelo menos 1 letra maiúscula';
        }
        if (!preg_match('/[a-z]/', $password)) {
            $errors[] = 'ter pelo menos 1 letra minúscula';
        }
        if (!preg_match('/[0-9]/', $password)) {
            $errors[] = 'ter pelo menos 1 número';
        }
        if (!preg_match('/[!@#$%&*()_\+\-=\[\]{};:\'",.<>\/?\\\\|`~^]/', $password)) {
            $errors[] = 'ter pelo menos 1 caractere especial';
        }
        if (preg_match('/\s/', $password)) {
            $errors[] = 'não conter espaços';
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    public static function requirementsText() {
        return 'A password deve ter pelo menos 8 caracteres, 1 letra maiúscula, 1 letra minúscula, 1 número, 1 caractere especial e não pode conter espaços.';
    }
}

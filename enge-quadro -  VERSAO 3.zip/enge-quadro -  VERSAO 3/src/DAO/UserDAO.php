<?php
// src/DAO/UserDAO.php

require_once $_SERVER['DOCUMENT_ROOT'] . '/enge-quadro/src/Models/Database.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/enge-quadro/src/Models/User.php';

class UserDAO {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    /**
     * Procura um utilizador pelo E-mail no MySQL
     * Usado diretamente no fluxo de Login
     */
    public function findByEmail($email) {
        // Criar a query com um "placeholder" (:email) para total segurança contra SQL Injection
        $query = "SELECT * FROM users WHERE email = :email LIMIT 1";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute(['email' => $email]);
        
        // Vai buscar a linha de dados do MySQL
        $row = $stmt->fetch();

        // Se encontrar o utilizador, transforma a linha num Objeto da classe User
        if ($row) {
            return new User($row);
        }
        
        return null; // Se não encontrar ninguém com esse e-mail
    }

    public function findById($id) {
        $query = "SELECT * FROM users WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();

        return $row ? new User($row) : null;
    }

    public function updatePassword($id, $passwordHash) {
        $query = "UPDATE users SET password_hash = :password_hash WHERE id = :id";
        $stmt = $this->db->prepare($query);

        return $stmt->execute([
            'id' => $id,
            'password_hash' => $passwordHash
        ]);
    }

    public function createPasswordResetCode($userId, $code, $expiresAt) {
        $this->db->prepare("UPDATE password_reset_tokens SET used_at = NOW() WHERE user_id = :user_id AND used_at IS NULL")
            ->execute(['user_id' => $userId]);

        $query = "INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES (:user_id, :token_hash, :expires_at)";
        $stmt = $this->db->prepare($query);

        return $stmt->execute([
            'user_id' => $userId,
            'token_hash' => password_hash($code, PASSWORD_DEFAULT),
            'expires_at' => $expiresAt
        ]);
    }

    public function findValidPasswordReset($email, $code) {
        $query = "SELECT prt.*, u.email, u.nome
                  FROM password_reset_tokens prt
                  JOIN users u ON u.id = prt.user_id
                  WHERE u.email = :email
                    AND prt.used_at IS NULL
                    AND prt.expires_at > NOW()
                  ORDER BY prt.id DESC
                  LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->execute(['email' => $email]);
        $row = $stmt->fetch();

        if (!$row || !password_verify($code, $row['token_hash'])) {
            return null;
        }

        return $row;
    }

    public function markPasswordResetUsed($resetId) {
        $stmt = $this->db->prepare("UPDATE password_reset_tokens SET used_at = NOW() WHERE id = :id");
        return $stmt->execute(['id' => $resetId]);
    }
}

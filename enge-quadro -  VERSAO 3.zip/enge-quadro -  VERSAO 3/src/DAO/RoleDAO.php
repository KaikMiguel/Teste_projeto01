<?php
// src/DAO/RoleDAO.php

require_once __DIR__ . '/../Models/Database.php';
require_once __DIR__ . '/../Models/Role.php';

class RoleDAO {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getRoleForUser($userId) {
        $sql = "SELECT r.*
                FROM users u
                LEFT JOIN roles r ON r.id = u.role_id
                WHERE u.id = :user_id
                LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['user_id' => $userId]);
        $role = $stmt->fetch();

        if (!$role) {
            return null;
        }

        $role['permissoes'] = $this->getAllowedPathsForRole($role['id']);
        return new Role($role);
    }

    public function getAllowedPathsForRole($roleId) {
        $sql = "SELECT v.path
                FROM role_view_permissions rvp
                JOIN app_views v ON v.id = rvp.view_id
                WHERE rvp.role_id = :role_id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['role_id' => $roleId]);

        return array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'path');
    }

    public function userCanAccess($userId, $path) {
        $role = $this->getRoleForUser($userId);

        if (!$role) {
            return false;
        }

        if ($role->nome === 'admin') {
            return true;
        }

        return in_array($path, $role->permissoes, true);
    }
}

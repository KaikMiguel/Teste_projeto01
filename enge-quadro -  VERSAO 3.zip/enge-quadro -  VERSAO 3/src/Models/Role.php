<?php
// src/Models/Role.php

class Role {
    public $id;
    public $nome;
    public $permissoes = []; // Um array com as rotas/views permitidas (ex: ['/home', '/admin-panel'])

    public function __construct($data = []) {
        $this->id = $data['id'] ?? null;
        $this->nome = $data['nome'] ?? null;
        $this->permissoes = $data['permissoes'] ?? [];
    }
}

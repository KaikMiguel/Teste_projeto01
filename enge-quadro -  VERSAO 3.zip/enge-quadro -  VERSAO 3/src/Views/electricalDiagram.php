<!DOCTYPE html>
<html class="light" lang="pt-pt">
<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Electrical Diagram</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet" />
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        background: "#fcf8f7",
                        surface: "#fcf8f7",
                        "on-surface": "#1c1b1b",
                        "on-background": "#1c1b1b",
                        "on-surface-variant": "#454742",
                        "outline-variant": "#c6c7c0",
                        secondary: "#4e660f"
                    },
                    spacing: { unit: "4px", sm: "8px", md: "16px", lg: "24px", xl: "48px", margin: "24px" },
                    fontFamily: { "body-md": ["Inter"], "headline-lg": ["Inter"], "headline-md": ["Inter"] },
                    fontSize: {
                        "body-md": ["14px", { lineHeight: "1.5", fontWeight: "400" }],
                        "headline-lg": ["32px", { lineHeight: "1.2", fontWeight: "600" }],
                        "headline-md": ["24px", { lineHeight: "1.2", fontWeight: "600" }]
                    }
                }
            }
        }
    </script>
    <style>
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-background text-on-background font-body-md text-body-md min-h-screen flex flex-col antialiased">
    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 border-b border-[#e1e2df] dark:border-stone-800">
        <span class="text-lg font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>
        <?php require __DIR__ . '/partials/projectIndicator.php'; ?>
        <div class="flex items-center gap-sm">
            <button class="p-sm text-[#82837e] dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors rounded-full">
                <span class="material-symbols-outlined text-[24px]">notifications</span>
            </button>
            <a href="/enge-quadro/home" class="ml-sm w-9 h-9 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-[#94b053] hover:border-[#94b053] hover:bg-white transition-all duration-200 shadow-sm">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">home</span>
            </a>
        </div>
    </header>

    <div class="flex pt-16 flex-1 h-screen overflow-hidden">
        <?php require_once __DIR__ . '/sideMenu/sidebarProjectPages.php'; ?>

        <main class="ml-64 flex-1 p-xl bg-surface flex flex-col h-full overflow-hidden">
            <div class="flex justify-between items-end mb-margin pb-md border-b border-outline-variant flex-shrink-0">
                <div>
                    <h1 class="font-headline-lg text-headline-lg text-on-surface mb-1 uppercase">Esquema</h1>
                    <p class="font-body-md text-body-md text-on-surface-variant">Area de esquema eletrico em manutencao.</p>
                </div>
            </div>
        </main>

        <?php require_once __DIR__ . '/sideMenu/sidebarProject.php'; ?>
    </div>
</body>
</html>

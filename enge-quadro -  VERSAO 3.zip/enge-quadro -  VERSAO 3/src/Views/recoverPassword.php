<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../Utils/PasswordUtils.php';

$step = $_SESSION['recover_step'] ?? 'email';
$recoverError = $_SESSION['recover_error'] ?? '';
$recoverSuccess = $_SESSION['recover_success'] ?? '';
$recoverEmail = $_SESSION['recover_email'] ?? '';
unset($_SESSION['recover_error'], $_SESSION['recover_success']);
?>
<!DOCTYPE html>
<html class="light" lang="pt-PT">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Recuperar Password | ENG-QUADROS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: "#fcf8f7",
                        surface: "#ffffff",
                        secondary: "#4e660f",
                        "secondary-container": "#cdeb87",
                        "on-secondary-container": "#526b14",
                        "on-surface": "#1c1b1b",
                        "on-surface-variant": "#454742",
                        "outline-variant": "#c6c7c0",
                        error: "#ba1a1a",
                        "error-container": "#ffdad6"
                    },
                    fontFamily: { inter: ["Inter"] }
                }
            }
        }
    </script>
</head>
<body class="bg-background font-inter text-on-surface min-h-screen flex items-center justify-center px-4">
    <main class="w-full max-w-md bg-surface border border-outline-variant rounded-xl shadow-xl p-8">
        <div class="text-center mb-6">
            <h1 class="text-2xl font-black tracking-widest">ENG-QUADROS</h1>
            <p class="text-sm text-on-surface-variant mt-1">Recuperar password</p>
        </div>

        <?php if ($recoverError): ?>
            <div class="mb-4 bg-error-container text-error border border-error p-3 rounded-md font-semibold">
                <?php echo htmlspecialchars($recoverError); ?>
            </div>
        <?php endif; ?>

        <?php if ($recoverSuccess): ?>
            <div class="mb-4 bg-secondary-container text-on-secondary-container border border-secondary p-3 rounded-md font-semibold">
                <?php echo htmlspecialchars($recoverSuccess); ?>
            </div>
        <?php endif; ?>

        <?php if ($step === 'password'): ?>
            <form method="POST" action="/enge-quadro/recover-password" class="space-y-4">
                <input type="hidden" name="action" value="reset_password">
                <p class="text-sm text-on-surface-variant"><?php echo htmlspecialchars(PasswordUtils::requirementsText()); ?></p>
                <label class="block">
                    <span class="text-xs uppercase tracking-wider font-bold text-on-surface-variant">Nova password</span>
                    <input id="newPassword" name="new_password" type="password" class="mt-2 w-full border border-outline-variant rounded px-4 py-3" required>
                </label>
                <label class="block">
                    <span class="text-xs uppercase tracking-wider font-bold text-on-surface-variant">Confirmar password</span>
                    <input id="confirmPassword" name="confirm_password" type="password" class="mt-2 w-full border border-outline-variant rounded px-4 py-3" required>
                </label>
                <ul id="passwordRules" class="text-xs text-on-surface-variant space-y-1"></ul>
                <button class="w-full bg-secondary text-white rounded-md py-3 font-bold uppercase tracking-widest" type="submit">Alterar password</button>
            </form>
        <?php elseif ($step === 'code'): ?>
            <form method="POST" action="/enge-quadro/recover-password" class="space-y-4">
                <input type="hidden" name="action" value="verify_code">
                <p class="text-sm text-on-surface-variant">Introduza o código de 6 dígitos enviado para <?php echo htmlspecialchars($recoverEmail); ?>.</p>
                <label class="block">
                    <span class="text-xs uppercase tracking-wider font-bold text-on-surface-variant">Código</span>
                    <input name="code" type="text" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" class="mt-2 w-full border border-outline-variant rounded px-4 py-3 tracking-[0.35em] text-center text-lg font-bold" required>
                </label>
                <button class="w-full bg-secondary text-white rounded-md py-3 font-bold uppercase tracking-widest" type="submit">Validar código</button>
            </form>
        <?php else: ?>
            <form method="POST" action="/enge-quadro/recover-password" class="space-y-4">
                <input type="hidden" name="action" value="send_code">
                <label class="block">
                    <span class="text-xs uppercase tracking-wider font-bold text-on-surface-variant">Email</span>
                    <input name="email" type="email" class="mt-2 w-full border border-outline-variant rounded px-4 py-3" required>
                </label>
                <button class="w-full bg-secondary text-white rounded-md py-3 font-bold uppercase tracking-widest" type="submit">Enviar código</button>
            </form>
        <?php endif; ?>

        <a href="/enge-quadro/login" class="mt-6 inline-flex w-full justify-center text-sm text-secondary font-bold hover:underline">Voltar ao login</a>
    </main>

    <script>
        const newPassword = document.getElementById('newPassword');
        const passwordRules = document.getElementById('passwordRules');
        const rules = [
            ['Pelo menos 8 caracteres', value => value.length >= 8],
            ['Pelo menos 1 letra maiúscula (A-Z)', value => /[A-Z]/.test(value)],
            ['Pelo menos 1 letra minúscula (a-z)', value => /[a-z]/.test(value)],
            ['Pelo menos 1 número (0-9)', value => /[0-9]/.test(value)],
            ['Pelo menos 1 caractere especial (!@#$%&*...)', value => /[!@#$%&*()_+\-=\[\]{};:'",.<>/?\\|`~^]/.test(value)],
            ['Não conter espaços', value => !/\s/.test(value)]
        ];

        function renderRules() {
            if (!newPassword || !passwordRules) return;
            passwordRules.innerHTML = rules.map(([label, test]) => {
                const ok = test(newPassword.value);
                return `<li class="${ok ? 'text-secondary' : 'text-on-surface-variant'}">${ok ? '✓' : '•'} ${label}</li>`;
            }).join('');
        }

        newPassword?.addEventListener('input', renderRules);
        renderRules();
    </script>
</body>
</html>

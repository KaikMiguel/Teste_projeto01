<?php
$estimateBoards = $estimateBoards ?? [];
$estimateProjectId = isset($projectId) ? (int) $projectId : (isset($_GET['project_id']) ? intval($_GET['project_id']) : 0);
?>
<!DOCTYPE html>
<html class="light" lang="pt-pt">
<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Estimate</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet" />
    
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "on-secondary-fixed-variant": "#394d00",
                        "tertiary": "#4f6300",
                        "surface-container-high": "#ebe7e6",
                        "on-secondary-container": "#526b14",
                        "inverse-primary": "#c7c7c1",
                        "background": "#fcf8f7",
                        "outline": "#767872",
                        "surface-bright": "#fcf8f7",
                        "secondary-container": "#cdeb87",
                        "on-secondary-fixed": "#151f00",
                        "on-surface": "#1c1b1b",
                        "primary-fixed": "#e3e3dd",
                        "surface-container-highest": "#e5e2e0",
                        "surface-container": "#f1edec",
                        "on-background": "#1c1b1b",
                        "secondary": "#4e660f",
                        "on-primary-container": "#fdfdf7",
                        "on-tertiary-fixed": "#161e00",
                        "secondary-fixed": "#d0ee89",
                        "primary-fixed-dim": "#c7c7c1",
                        "error-container": "#ffdad6",
                        "primary-container": "#747570",
                        "surface-variant": "#e5e2e0",
                        "surface-tint": "#5d5f5a",
                        "on-tertiary": "#ffffff",
                        "tertiary-fixed-dim": "#abd600",
                        "secondary-fixed-dim": "#b4d170",
                        "on-error-container": "#93000a",
                        "on-surface-variant": "#454742",
                        "error": "#ba1a1a",
                        "surface-dim": "#ddd9d8",
                        "on-primary": "#ffffff",
                        "tertiary-container": "#647e00",
                        "surface-container-low": "#f7f3f1",
                        "tertiary-fixed": "#c5f31b",
                        "on-primary-fixed-variant": "#464743",
                        "primary": "#5b5c58",
                        "outline-variant": "#c6c7c0",
                        "on-error": "#ffffff",
                        "surface-container-lowest": "#ffffff",
                        "on-secondary": "#ffffff",
                        "on-primary-fixed": "#1a1c19",
                        "inverse-on-surface": "#f4f0ef",
                        "inverse-surface": "#313030",
                        "surface": "#fcf8f7",
                        "on-tertiary-container": "#fbffe4",
                        "on-tertiary-fixed-variant": "#3c4d00"
                    },
                    "borderRadius": {
                        "DEFAULT": "0.125rem",
                        "lg": "0.25rem",
                        "xl": "0.5rem",
                        "full": "0.75rem"
                    },
                    "spacing": {
                        "unit": "4px",
                        "sm": "8px",
                        "md": "16px",
                        "xl": "48px",
                        "margin": "24px",
                        "xs": "4px",
                        "gutter": "16px",
                        "lg": "24px"
                    },
                    "fontFamily": {
                        "label-md": ["Inter"],
                        "headline-lg": ["Inter"],
                        "body-md": ["Inter"],
                        "headline-sm": ["Inter"],
                        "mono-sm": ["monospace"],
                        "headline-md": ["Inter"],
                        "body-lg": ["Inter"]
                    },
                    "fontSize": {
                        "label-md": ["12px", { "lineHeight": "1", "letterSpacing": "0.05em", "fontWeight": "500" }],
                        "headline-lg": ["32px", { "lineHeight": "1.2", "letterSpacing": "-0.02em", "fontWeight": "600" }],
                        "body-md": ["14px", { "lineHeight": "1.5", "fontWeight": "400" }],
                        "headline-sm": ["18px", { "lineHeight": "1.4", "fontWeight": "600" }],
                        "mono-sm": ["12px", { "lineHeight": "1", "fontWeight": "400" }],
                        "headline-md": ["24px", { "lineHeight": "1.2", "letterSpacing": "-0.01em", "fontWeight": "600" }],
                        "body-lg": ["16px", { "lineHeight": "1.6", "fontWeight": "400" }]
                    }
                }
            }
        }
    </script>
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #c6c7c0; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #767872; }
    </style>
</head>

<body class="bg-background text-on-surface font-body-md text-body-md min-h-screen flex flex-col antialiased">

    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 border-b border-[#e1e2df] dark:border-stone-800">
        <div class="flex items-center gap-md">
            <span class="text-lg font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>
        </div>

        <?php require __DIR__ . '/partials/projectIndicator.php'; ?>

        <div class="flex items-center gap-sm">
<button class="p-sm text-[#82837e] dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors active:opacity-80 rounded-full">
                <span class="material-symbols-outlined text-[24px]">notifications</span>
            </button>

            <a href="/enge-quadro/home" 
            class="ml-sm w-9 h-9 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-[#94b053] hover:border-[#94b053] hover:bg-white transition-all duration-200 shadow-sm">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">home</span>
            </a>
        </div>
    </header>

    <div class="flex pt-16 flex-1 h-screen overflow-hidden">
        <?php require_once __DIR__ . '/sideMenu/sidebarProjectPages.php'; ?>

        <div class="flex flex-col flex-1 min-w-0 ml-[256px]">
            <main class="flex-1 overflow-y-auto p-lg flex flex-col gap-lg bg-surface">
                <div class="flex justify-between items-end mb-2">
                    <div>
                        <h2 class="font-headline-md text-headline-md text-on-surface">Orçamento por Quadro</h2>
                        <p class="text-on-surface-variant">Materiais vindos da aba Material, com custos e margens calculados por quadro.</p>
                    </div>
                    <?php if ($estimateProjectId > 0): ?>
                        <a href="/enge-quadro/estimate/export-materials?project_id=<?php echo $estimateProjectId; ?>"
                           class="inline-flex items-center gap-sm bg-secondary text-white hover:bg-[#3f540c] transition-colors rounded-DEFAULT px-md py-2 font-label-md text-label-md uppercase tracking-widest shadow-sm">
                            <span class="material-symbols-outlined text-[18px]">download</span>
                            Exportar CSV
                        </a>
                    <?php endif; ?>
                </div>

                <?php if (empty($estimateBoards)): ?>
                    <div class="border border-dashed border-outline-variant rounded-DEFAULT bg-surface-container-lowest p-xl text-center text-on-surface-variant">
                        <span class="material-symbols-outlined text-[40px] text-secondary mb-sm block">request_quote</span>
                        Crie quadros e adicione materiais na aba Material para construir o orçamento.
                    </div>
                <?php else: ?>
                    <div class="flex flex-col gap-lg pb-xl">
                        <section class="bg-surface-container-lowest border border-outline-variant rounded-DEFAULT p-lg shadow-sm">
                            <div class="flex flex-wrap items-end justify-between gap-lg">
                                <div>
                                    <div class="font-label-md text-label-md uppercase text-on-surface-variant mb-xs">Total do Projeto</div>
                                    <div class="font-headline-lg text-[36px] leading-none text-secondary font-bold" id="projectFinalTotal">0,00 €</div>
                                </div>
                                <div class="grid grid-cols-2 md:grid-cols-4 gap-lg text-right">
                                    <div>
                                        <div class="text-[10px] uppercase text-outline">Material bruto</div>
                                        <div class="font-mono-sm font-semibold" id="projectMaterialTotal">0,00 €</div>
                                    </div>
                                    <div>
                                        <div class="text-[10px] uppercase text-outline">Consumíveis</div>
                                        <div class="font-mono-sm font-semibold" id="projectConsumablesTotal">0,00 €</div>
                                    </div>
                                    <div>
                                        <div class="text-[10px] uppercase text-outline">Mão de obra</div>
                                        <div class="font-mono-sm font-semibold" id="projectLaborTotal">0,00 €</div>
                                    </div>
                                    <div>
                                        <div class="text-[10px] uppercase text-outline">Custo total</div>
                                        <div class="font-mono-sm font-semibold" id="projectCostTotal">0,00 €</div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <?php foreach ($estimateBoards as $board): ?>
                            <?php
                                $boardMaterialTotal = 0;
                                foreach ($board['items'] as $item) {
                                    $boardMaterialTotal += ((float) ($item['pvp'] ?? 0)) * ((int) ($item['quantity'] ?? 0));
                                }
                            ?>
                            <section class="estimate-board bg-surface-container-lowest border <?php echo (isset($_GET['board_id']) && intval($_GET['board_id']) === (int) $board['id']) ? 'border-secondary shadow-sm' : 'border-outline-variant'; ?> rounded-DEFAULT overflow-hidden" data-material-total="<?php echo htmlspecialchars((string) $boardMaterialTotal); ?>">
                                <div class="p-md border-b border-outline-variant bg-surface-container-low flex flex-wrap items-center justify-between gap-md">
                                    <div>
                                        <h3 class="font-headline-sm text-headline-sm text-on-surface flex items-center gap-2">
                                            <span class="material-symbols-outlined text-secondary">developer_board</span>
                                            <?php echo htmlspecialchars($board['board_name']); ?>
                                        </h3>
                                        <p class="text-xs text-on-surface-variant"><?php echo count($board['items']); ?> referências no quadro</p>
                                    </div>

                                    <div class="grid grid-cols-2 xl:grid-cols-5 gap-sm">
                                        <label class="flex flex-col gap-xs">
                                            <span class="font-label-md text-label-md text-on-surface-variant uppercase">Desconto %</span>
                                            <input class="estimate-input board-discount w-24 bg-white border border-outline-variant rounded-DEFAULT px-sm py-2 font-mono-sm text-right" type="number" step="0.01" value="0">
                                        </label>
                                        <label class="flex flex-col gap-xs">
                                            <span class="font-label-md text-label-md text-on-surface-variant uppercase">Margem %</span>
                                            <input class="estimate-input board-margin w-24 bg-white border border-outline-variant rounded-DEFAULT px-sm py-2 font-mono-sm text-right" type="number" step="0.01" value="0">
                                        </label>
                                        <label class="flex flex-col gap-xs">
                                            <span class="font-label-md text-label-md text-on-surface-variant uppercase">Consumíveis €</span>
                                            <input class="estimate-input board-consumables w-28 bg-white border border-outline-variant rounded-DEFAULT px-sm py-2 font-mono-sm text-right" type="number" step="0.01" value="0">
                                        </label>
                                        <label class="flex flex-col gap-xs">
                                            <span class="font-label-md text-label-md text-on-surface-variant uppercase">MO €/h</span>
                                            <input class="estimate-input board-labor-rate w-24 bg-white border border-outline-variant rounded-DEFAULT px-sm py-2 font-mono-sm text-right" type="number" step="0.01" value="0">
                                        </label>
                                        <label class="flex flex-col gap-xs">
                                            <span class="font-label-md text-label-md text-on-surface-variant uppercase">Horas</span>
                                            <input class="estimate-input board-labor-hours w-24 bg-white border border-outline-variant rounded-DEFAULT px-sm py-2 font-mono-sm text-right" type="number" step="0.01" value="0">
                                        </label>
                                    </div>
                                </div>

                                <div class="max-h-80 overflow-y-auto">
                                    <table class="w-full text-left border-collapse">
                                        <thead class="sticky top-0 bg-white z-10 shadow-sm">
                                            <tr class="border-b border-outline-variant">
                                                <th class="px-md py-3 font-label-md text-label-md text-on-surface-variant uppercase">Marca</th>
                                                <th class="px-md py-3 font-label-md text-label-md text-on-surface-variant uppercase">Referência</th>
                                                <th class="px-md py-3 font-label-md text-label-md text-on-surface-variant uppercase">Designação</th>
                                                <th class="px-md py-3 font-label-md text-label-md text-on-surface-variant uppercase text-center">Qtd</th>
                                                <th class="px-md py-3 font-label-md text-label-md text-on-surface-variant uppercase text-right">PVP Unit.</th>
                                                <th class="px-md py-3 font-label-md text-label-md text-on-surface-variant uppercase text-right">Subtotal</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($board['items'])): ?>
                                                <tr>
                                                    <td colspan="6" class="px-md py-8 text-center text-outline italic">Este quadro ainda não tem materiais.</td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($board['items'] as $item): ?>
                                                    <?php
                                                        $quantity = (int) ($item['quantity'] ?? 0);
                                                        $unitPrice = (float) ($item['pvp'] ?? 0);
                                                        $lineTotal = $quantity * $unitPrice;
                                                    ?>
                                                    <tr class="border-b border-outline-variant/40 hover:bg-surface-container-low">
                                                        <td class="px-md py-3 text-outline font-medium"><?php echo htmlspecialchars($item['marca'] ?? ''); ?></td>
                                                        <td class="px-md py-3 font-mono-sm text-secondary font-bold"><?php echo htmlspecialchars($item['referencia'] ?? ''); ?></td>
                                                        <td class="px-md py-3 text-on-surface"><?php echo htmlspecialchars($item['descricao'] ?? ''); ?></td>
                                                        <td class="px-md py-3 text-center font-mono-sm"><?php echo $quantity; ?></td>
                                                        <td class="px-md py-3 text-right font-mono-sm"><?php echo number_format($unitPrice, 2, ',', '.'); ?> €</td>
                                                        <td class="px-md py-3 text-right font-mono-sm font-semibold"><?php echo number_format($lineTotal, 2, ',', '.'); ?> €</td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>

                                <div class="p-md bg-surface-bright border-t border-outline-variant grid grid-cols-2 md:grid-cols-6 gap-md">
                                    <div>
                                        <div class="text-[10px] uppercase text-outline">Material bruto</div>
                                        <div class="font-mono-sm font-semibold board-material-total">0,00 €</div>
                                    </div>
                                    <div>
                                        <div class="text-[10px] uppercase text-outline">Após desconto</div>
                                        <div class="font-mono-sm font-semibold board-net-material">0,00 €</div>
                                    </div>
                                    <div>
                                        <div class="text-[10px] uppercase text-outline">Consumíveis</div>
                                        <div class="font-mono-sm font-semibold board-consumables-total">0,00 €</div>
                                    </div>
                                    <div>
                                        <div class="text-[10px] uppercase text-outline">Mão de obra</div>
                                        <div class="font-mono-sm font-semibold board-labor-total">0,00 €</div>
                                    </div>
                                    <div>
                                        <div class="text-[10px] uppercase text-outline">Custo</div>
                                        <div class="font-mono-sm font-semibold board-cost-total">0,00 €</div>
                                    </div>
                                    <div class="text-right">
                                        <div class="text-[10px] uppercase text-outline">Total quadro</div>
                                        <div class="font-headline-sm text-secondary board-final-total">0,00 €</div>
                                    </div>
                                </div>
                            </section>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </main>
        </div>

        <?php require_once __DIR__ . '/sideMenu/sidebarProject.php'; ?>
    </div>

    <script>
        function parseNumber(value) {
            const normalized = String(value || '0').replace(',', '.');
            const number = parseFloat(normalized);
            return Number.isNaN(number) ? 0 : number;
        }

        function formatCurrency(value) {
            return new Intl.NumberFormat('pt-PT', {
                style: 'currency',
                currency: 'EUR'
            }).format(value || 0);
        }

        function setText(scope, selector, value) {
            const element = scope.querySelector(selector);
            if (element) {
                element.textContent = formatCurrency(value);
            }
        }

        function recalculateEstimate() {
            let projectMaterial = 0;
            let projectConsumables = 0;
            let projectLabor = 0;
            let projectCost = 0;
            let projectFinal = 0;

            document.querySelectorAll('.estimate-board').forEach((board) => {
                const material = parseNumber(board.dataset.materialTotal);
                const discount = parseNumber(board.querySelector('.board-discount')?.value);
                const margin = parseNumber(board.querySelector('.board-margin')?.value);
                const consumablesValue = parseNumber(board.querySelector('.board-consumables')?.value);
                const laborRate = parseNumber(board.querySelector('.board-labor-rate')?.value);
                const laborHours = parseNumber(board.querySelector('.board-labor-hours')?.value);

                const netMaterial = material * Math.max(0, 1 - discount / 100);
                const consumables = Math.max(0, consumablesValue);
                const labor = Math.max(0, laborRate) * Math.max(0, laborHours);
                const cost = netMaterial + consumables + labor;
                const marginRate = Math.max(0, Math.min(margin, 99.99));
                const finalTotal = cost / (1 - marginRate / 100);

                setText(board, '.board-material-total', material);
                setText(board, '.board-net-material', netMaterial);
                setText(board, '.board-consumables-total', consumables);
                setText(board, '.board-labor-total', labor);
                setText(board, '.board-cost-total', cost);
                setText(board, '.board-final-total', finalTotal);

                projectMaterial += material;
                projectConsumables += consumables;
                projectLabor += labor;
                projectCost += cost;
                projectFinal += finalTotal;
            });

            if (!document.getElementById('projectFinalTotal')) {
                return;
            }

            document.getElementById('projectMaterialTotal').textContent = formatCurrency(projectMaterial);
            document.getElementById('projectConsumablesTotal').textContent = formatCurrency(projectConsumables);
            document.getElementById('projectLaborTotal').textContent = formatCurrency(projectLabor);
            document.getElementById('projectCostTotal').textContent = formatCurrency(projectCost);
            document.getElementById('projectFinalTotal').textContent = formatCurrency(projectFinal);
        }

        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.estimate-input').forEach((input) => {
                input.addEventListener('input', recalculateEstimate);
            });
            recalculateEstimate();
        });
    </script>
</body>
</html>

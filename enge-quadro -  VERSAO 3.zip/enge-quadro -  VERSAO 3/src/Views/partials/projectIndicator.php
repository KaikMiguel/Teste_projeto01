<?php
$indicatorProjectId = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
$indicatorProject = $currentProject ?? null;

if ($indicatorProjectId > 0 && empty($indicatorProject)) {
    require_once __DIR__ . '/../../DAO/ProjectDAO.php';
    $indicatorProjectDAO = new ProjectDAO();
    $indicatorProject = $indicatorProjectDAO->getProjectById($indicatorProjectId);
}
?>

<?php if (!empty($indicatorProject)): ?>
    <div class="hidden md:flex items-center gap-2 min-w-0 max-w-[42vw] px-3 py-1.5 bg-stone-50 dark:bg-stone-900 border border-[#e1e2df] dark:border-stone-800 rounded-lg">
        <span class="material-symbols-outlined text-[18px] text-[#94b053] flex-shrink-0">folder_open</span>
        <div class="min-w-0 leading-tight">
            <div class="text-[10px] font-bold uppercase tracking-widest text-stone-500 dark:text-stone-400">Projeto atual</div>
            <div class="text-[12px] font-semibold text-stone-900 dark:text-stone-100 truncate">
                <?php echo htmlspecialchars($indicatorProject['project_name'] ?? 'Projeto'); ?>
                <?php if (!empty($indicatorProject['client'])): ?>
                    <span class="font-normal text-stone-500 dark:text-stone-400">/ <?php echo htmlspecialchars($indicatorProject['client']); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

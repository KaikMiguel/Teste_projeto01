<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html class="light" lang="pt-pt">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Início | Eng-Quadros</title>
    
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet"/>
    
    <link rel="stylesheet" href="projects.css">
    
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "on-secondary-fixed-variant": "#394d00", "tertiary": "#4f6300", "surface-container-high": "#ebe7e6",
                        "on-secondary-container": "#526b14", "inverse-primary": "#c7c7c1", "background": "#fcf8f7",
                        "outline": "#767872", "surface-bright": "#fcf8f7", "secondary-container": "#cdeb87",
                        "on-secondary-fixed": "#151f00", "on-surface": "#1c1b1b", "primary-fixed": "#e3e3dd",
                        "surface-container-highest": "#e5e2e0", "surface-container": "#f1edec", "on-background": "#1c1b1b",
                        "secondary": "#4e660f", "on-primary-container": "#fdfdf7", "on-tertiary-fixed": "#161e00",
                        "secondary-fixed": "#d0ee89", "primary-fixed-dim": "#c7c7c1", "error-container": "#ffdad6",
                        "primary-container": "#747570", "surface-variant": "#e5e2e0", "surface-tint": "#5d5f5a",
                        "on-tertiary": "#ffffff", "tertiary-fixed-dim": "#abd600", "secondary-fixed-dim": "#b4d170",
                        "on-error-container": "#93000a", "on-surface-variant": "#454742", "error": "#ba1a1a",
                        "surface-dim": "#ddd9d8", "on-primary": "#ffffff", "tertiary-container": "#647e00",
                        "surface-container-low": "#f7f3f1", "tertiary-fixed": "#c5f31b", "on-primary-fixed-variant": "#464743",
                        "primary": "#5b5c58", "outline-variant": "#c6c7c0", "on-error": "#ffffff", "surface-container-lowest": "#ffffff",
                        "on-secondary": "#ffffff", "on-primary-fixed": "#1a1c19", "inverse-on-surface": "#f4f0ef",
                        "inverse-surface": "#313030", "surface": "#fcf8f7", "on-tertiary-container": "#fbffe4",
                        "on-tertiary-fixed-variant": "#3c4d00"
                    },
                    "borderRadius": { "DEFAULT": "0.125rem", "lg": "0.25rem", "xl": "0.5rem", "full": "0.75rem" },
                    "spacing": { "unit": "4px", "sm": "8px", "md": "16px", "xl": "48px", "margin": "24px", "xs": "4px", "gutter": "16px", "lg": "24px" },
                    "fontFamily": { "label-md": ["Inter"], "headline-lg": ["Inter"], "body-md": ["Inter"], "headline-sm": ["Inter"], "mono-sm": ["monospace"], "headline-md": ["Inter"], "body-lg": ["Inter"] },
                    "fontSize": { "label-md": ["12px", { "lineHeight": "1", "letterSpacing": "0.05em", "fontWeight": "500" }], "headline-lg": ["32px", { "lineHeight": "1.2", "letterSpacing": "-0.02em", "fontWeight": "600" }], "body-md": ["14px", { "lineHeight": "1.5", "fontWeight": "400" }], "headline-sm": ["18px", { "lineHeight": "1.4", "fontWeight": "600" }], "mono-sm": ["12px", { "lineHeight": "1", "fontWeight": "400" }], "headline-md": ["24px", { "lineHeight": "1.2", "letterSpacing": "-0.01em", "fontWeight": "600" }], "body-lg": ["16px", { "lineHeight": "1.6", "fontWeight": "400" }] }
                }
            }
        }
    </script>
    <style>
        .select-scroll-lock { position: absolute; z-index: 50; }
    </style>
</head>
<body class="bg-background text-on-background font-body-md text-body-md min-h-screen flex flex-col antialiased">

    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 border-b border-[#e1e2df] dark:border-stone-800">
        <div class="flex items-center gap-md">
            <span class="text-lg font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>
        </div>
        <div class="flex items-center gap-sm">
            <button class="p-sm text-[#82837e] dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors active:opacity-80 rounded-full">
                <span class="material-symbols-outlined text-[24px]">notifications</span>
            </button>
        </div>
    </header>

    <div class="flex pt-16 flex-1 h-screen overflow-hidden">

         <?php require_once __DIR__ . '/sideMenu/sidebarGeneral.php'; ?>

        <main class="ml-64 flex-1 p-xl bg-surface flex flex-col h-full overflow-hidden">
            
            <div class="flex justify-between items-end mb-margin pb-md border-b border-outline-variant flex-shrink-0">
                <div>
                    <h1 class="font-headline-lg text-headline-lg text-on-surface mb-xs">Projetos Ativos</h1>
                    <p class="font-body-md text-body-md text-on-surface-variant">Gerir e acompanhar o progresso de todos os projetos de engenharia atuais.</p>
                </div>
                <button id="btnNewProject" class="bg-secondary text-on-secondary px-md py-sm rounded-DEFAULT flex items-center gap-sm hover:opacity-90 transition-opacity font-label-md text-label-md uppercase tracking-wider inline-flex cursor-pointer">
                    <span class="material-symbols-outlined text-[18px]">add</span>
                    Criar Novo Projeto
                </button>
            </div>

            <?php if (isset($_SESSION['success'])): ?>
                <div class="bg-emerald-100 border border-emerald-400 text-emerald-800 p-4 rounded-md mb-md flex items-center gap-sm font-semibold flex-shrink-0">
                    <span class="material-symbols-outlined">check_circle</span>
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="bg-red-100 border border-red-400 text-red-800 p-4 rounded-md mb-md flex items-center gap-sm font-semibold flex-shrink-0">
                    <span class="material-symbols-outlined">error</span>
                    <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>

            <div class="sticky top-0 bg-surface py-sm z-20 flex justify-between items-center mb-md gap-md flex-shrink-0 border-b border-outline-variant/30 shadow-[0_4px_6px_-1px_rgba(0,0,0,0.02)]">
                <div class="flex-1 max-w-sm relative">
                    <span class="material-symbols-outlined absolute left-sm top-1/2 -translate-y-1/2 text-outline">search</span>
                    <input id="inputFilter" class="w-full pl-xl pr-md py-sm bg-surface-container-lowest border border-outline-variant rounded-DEFAULT focus:border-outline focus:ring-0 text-body-md font-body-md text-on-surface transition-colors shadow-sm" placeholder="Filtrar por nome ou cliente..." type="text"/>
                </div>
            </div>

            <div class="bg-surface-container-lowest border border-outline-variant rounded-DEFAULT shadow-sm flex-1 overflow-y-auto relative">
                <table class="w-full text-left border-collapse">
                    <thead class="sticky top-0 bg-surface-container-lowest z-10 shadow-sm">
                        <tr>
                            <th class="font-label-md text-label-md text-on-surface-variant uppercase p-md border-b border-outline-variant font-semibold">Nome do Projeto</th>
                            <th class="font-label-md text-label-md text-on-surface-variant uppercase p-md border-b border-outline-variant font-semibold">Cliente</th>
                            <th class="font-label-md text-label-md text-on-surface-variant uppercase p-md border-b border-outline-variant font-semibold">Comercial</th>
                            <th class="font-label-md text-label-md text-on-surface-variant uppercase p-md border-b border-outline-variant font-semibold">Autor</th>
                            <th id="th-created" class="font-label-md text-label-md text-on-surface-variant uppercase p-md border-b border-outline-variant font-semibold cursor-pointer hover:bg-surface-container transition-colors select-none">
                                <div class="flex items-center gap-1">
                                    Data de Criação
                                    <span class="material-symbols-outlined text-[16px] sort-icon text-outline">unfold_more</span>
                                </div>
                            </th>
                            <th id="th-updated" class="font-label-md text-label-md text-on-surface-variant uppercase p-md border-b border-outline-variant font-semibold cursor-pointer hover:bg-surface-container transition-colors select-none">
                                <div class="flex items-center gap-1">
                                    Última Modificação
                                    <span class="material-symbols-outlined text-[16px] sort-icon text-outline">unfold_more</span>
                                </div>
                            </th>
                            <th class="font-label-md text-label-md text-on-surface-variant uppercase p-md border-b border-outline-variant font-semibold text-right w-48">Ações</th>
                        </tr>
                    </thead>
                    <tbody id="projectTableBody" class="font-body-md text-body-md text-on-surface">
                        <?php if (empty($projects)): ?>
                            <tr>
                                <td colspan="7" class="p-xl text-center text-outline font-medium">Nenhum projeto encontrado. Comece por criar um!</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($projects as $project): ?>
                                <tr class="project-row hover:bg-surface-container-low transition-colors border-b border-outline-variant last:border-0 select-none" 
                                    data-id="<?php echo $project['id']; ?>"
                                    data-created="<?php echo strtotime($project['created_at']); ?>"
                                    data-updated="<?php echo strtotime($project['updated_at']); ?>">
                                    <td class="p-md font-medium text-on-surface"><?php echo htmlspecialchars($project['project_name']); ?></td>
                                    <td class="p-md text-on-surface-variant"><?php echo htmlspecialchars($project['client']); ?></td>
                                    <td class="p-md text-on-surface-variant"><?php echo htmlspecialchars($project['commercial_name']); ?></td>
                                    <td class="p-md text-on-surface-variant"><?php echo htmlspecialchars($project['author_name'] ?? ''); ?></td>
                                    <td class="p-md text-on-surface-variant"><?php echo date('d/m/Y H:i', strtotime($project['created_at'])); ?></td>
                                    <td class="p-md text-on-surface-variant"><?php echo date('d/m/Y H:i', strtotime($project['updated_at'])); ?></td>
                                    
                                    <td class="p-md text-right whitespace-nowrap">
                                        <div class="flex items-center justify-end gap-2">
                                            <a href="/enge-quadro/project/material-survey?project_id=<?php echo $project['id']; ?>" 
                                               class="bg-secondary text-white text-xs px-3 py-1.5 rounded-md font-medium hover:opacity-90 transition-opacity flex items-center gap-1 shadow-sm">
                                                <span class="material-symbols-outlined text-[16px]">folder_open</span>
                                                Abrir
                                            </a>
                                            <a href="/enge-quadro/projects/delete?project_id=<?php echo $project['id']; ?>" 
                                               onclick="return confirm('Tem a certeza absoluta de que deseja eliminar permanentemente este projeto de engenharia e todos os seus quadros associados?');" 
                                               class="border border-red-200 text-error hover:bg-red-50 text-xs px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1 shadow-sm">
                                                <span class="material-symbols-outlined text-[16px]">delete</span>
                                                Eliminar
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <div id="projectModal" class="fixed inset-0 bg-stone-900/40 backdrop-blur-sm z-50 flex items-center justify-center hidden opacity-0 transition-opacity duration-200">
        <div class="bg-surface-container-lowest border border-outline-variant w-full max-w-[800px] p-10 shadow-2xl rounded-2xl transform scale-95 transition-transform duration-200">
            
            <div class="flex justify-between items-center mb-lg pb-md border-b border-outline-variant">
                <div class="flex items-center gap-sm">
                    <span class="material-symbols-outlined text-primary text-[32px]">folder_open</span>
                    <h3 class="font-headline-md text-2xl font-bold text-on-surface uppercase tracking-wide">Novo Projeto de Engenharia</h3>
                </div>
                <button id="btnCloseModal" class="text-outline hover:text-on-surface transition-colors focus:outline-none flex items-center justify-center p-1 rounded-full hover:bg-surface-container">
                    <span class="material-symbols-outlined text-[26px]">close</span>
                </button>
            </div>

            <form id="createProjectForm" action="/enge-quadro/projects/create" method="POST" class="flex flex-col gap-lg">
                <div class="flex flex-col gap-xs">
                    <div class="flex justify-between items-center">
                        <label class="font-label-md text-sm text-on-surface-variant uppercase tracking-wider font-extrabold" for="project_name">Nome do Projeto</label>
                        <span id="counter_project_name" class="text-xs font-semibold text-outline tracking-wider font-mono-sm">0 / 60</span>
                    </div>
                    <input class="w-full p-md bg-white border border-outline-variant focus:border-primary focus:ring-0 text-body-lg rounded-md font-body-md transition-colors placeholder:text-outline-variant" 
                           id="project_name" name="project_name" placeholder="Ex: Quadro de Distribuição Central Hidroelétrica Y" type="text" maxlength="60" required>
                </div>

                <div class="flex flex-col gap-xs">
                    <div class="flex justify-between items-center">
                        <label class="font-label-md text-sm text-on-surface-variant uppercase tracking-wider font-extrabold" for="client">Nome do Cliente</label>
                        <span id="counter_client" class="text-xs font-semibold text-outline tracking-wider font-mono-sm">0 / 60</span>
                    </div>
                    <input class="w-full p-md bg-white border border-outline-variant focus:border-primary focus:ring-0 text-body-lg rounded-md font-body-md transition-colors placeholder:text-outline-variant" 
                           id="client" name="client" placeholder="Ex: EDP Renováveis ou Quadrinorte" type="text" maxlength="60" required>
                </div>

                <div class="flex flex-col gap-xs pb-12 relative">
                    <label class="font-label-md text-sm text-on-surface-variant uppercase tracking-wider font-extrabold" for="commercial_id">Representante Comercial</label>
                    <div class="relative">
                        <select class="w-full p-md bg-white border border-outline-variant focus:border-primary focus:ring-0 text-body-lg rounded-md font-body-md transition-colors appearance-none cursor-pointer transition-all duration-150" 
                                id="commercial_id" name="commercial_id" required
                                onfocus="this.size=9;" onblur="this.size=0;" onchange="this.size=1; this.blur();">
                            <option value="" disabled selected class="text-outline-variant">Selecione um representative comercial...</option>
                            <?php foreach ($commercials as $rep): ?>
                                <option value="<?php echo $rep['id']; ?>">
                                    <?php echo htmlspecialchars($rep['name']) . " — (" . htmlspecialchars($rep['phone']) . ")"; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <span class="material-symbols-outlined absolute right-4 top-[22px] -translate-y-1/2 text-outline pointer-events-none">arrow_drop_down</span>
                    </div>
                </div>

                <div class="flex justify-end items-center gap-md mt-xl pt-lg border-t border-outline-variant/50">
                    <button type="button" id="btnCancelModal" class="px-lg py-md border border-outline-variant rounded-md text-on-surface-variant font-bold text-sm uppercase tracking-wider hover:bg-surface-container transition-colors cursor-pointer">
                        Cancelar
                    </button>
                    <button type="submit" class="bg-secondary text-white font-bold text-sm py-md px-lg rounded-md hover:opacity-90 transition-all flex items-center gap-xs cursor-pointer shadow-md">
                        <span class="tracking-wider uppercase">Guardar Projeto</span>
                        <span class="material-symbols-outlined text-[18px]">save</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const projectRows = document.querySelectorAll('.project-row');
        const inputFilter = document.getElementById('inputFilter');
        const tableBody = document.getElementById('projectTableBody');
        const thCreated = document.getElementById('th-created');
        const thUpdated = document.getElementById('th-updated');

        // --- MOTOR DE ORDENAÇÃO POR DATAS ---
        let sortOrders = { 'data-created': true, 'data-updated': true };

        thCreated.addEventListener('click', () => { executeRowSort('data-created'); toggleHeaderVisuals(thCreated, 'data-created'); });
        thUpdated.addEventListener('click', () => { executeRowSort('data-updated'); toggleHeaderVisuals(thUpdated, 'data-updated'); });

        function executeRowSort(dataAttribute) {
            const currentRows = Array.from(document.querySelectorAll('.project-row'));
            const isAscending = sortOrders[dataAttribute];

            currentRows.sort((rowA, rowB) => {
                const valA = parseInt(rowA.getAttribute(dataAttribute)) || 0;
                const valB = parseInt(rowB.getAttribute(dataAttribute)) || 0;
                return isAscending ? valA - valB : valB - valA;
            });

            sortOrders[dataAttribute] = !isAscending;
            currentRows.forEach(row => tableBody.appendChild(row));
        }

        function toggleHeaderVisuals(activeTh, dataAttribute) {
            document.querySelectorAll('.sort-icon').forEach(icon => { icon.textContent = 'unfold_more'; icon.classList.remove('text-primary'); icon.classList.add('text-outline'); });
            const targetIcon = activeTh.querySelector('.sort-icon');
            targetIcon.classList.remove('text-outline');
            targetIcon.classList.add('text-primary');
            targetIcon.textContent = sortOrders[dataAttribute] ? 'arrow_downward' : 'arrow_upward';
        }

        // --- FILTRO DE TEXTO EM TEMPO REAL ---
        inputFilter.addEventListener('input', function() {
            const filterText = this.value.toLowerCase().trim();
            projectRows.forEach(row => {
                const projectName = row.cells[0].textContent.toLowerCase();
                const clientName = row.cells[1].textContent.toLowerCase();
                row.style.display = (projectName.includes(filterText) || clientName.includes(filterText)) ? '' : 'none';
            });
        });

        // --- MODAL COMPORTAMENTO ---
        const modal = document.getElementById('projectModal');
        const modalContent = modal.querySelector('.transform');
        const btnOpen = document.getElementById('btnNewProject');
        const btnClose = document.getElementById('btnCloseModal');
        const btnCancel = document.getElementById('btnCancelModal');
        const form = document.getElementById('createProjectForm');

        function openModal() { modal.classList.remove('hidden'); setTimeout(() => { modal.classList.remove('opacity-0'); modalContent.classList.remove('scale-95'); modalContent.classList.add('scale-100'); }, 10); }
        function closeModal() { modal.classList.add('opacity-0'); modalContent.classList.remove('scale-100'); modalContent.classList.add('scale-95'); setTimeout(() => { modal.classList.add('hidden'); }, 200); }

        const textInputs = form.querySelectorAll('input[type="text"]');
        textInputs.forEach(input => {
            const counterSpan = document.getElementById(`counter_${input.id}`);
            input.addEventListener('input', function () {
                let currentValue = input.value;
                let normalizedValue = currentValue.replace(/ {2,}/g, ' ');
                if (currentValue !== normalizedValue) { input.value = normalizedValue; }
                let length = input.value.length;
                if (length >= 60) {
                    counterSpan.textContent = "Limite atingido! (60/60)"; counterSpan.classList.remove('text-outline'); counterSpan.classList.add('text-error', 'font-black');
                } else {
                    counterSpan.textContent = `${length} / 60`; counterSpan.classList.remove('text-error', 'font-black'); counterSpan.classList.add('text-outline');
                }
            });
        });

        btnOpen.addEventListener('click', openModal);
        btnClose.addEventListener('click', closeModal);
        btnCancel.addEventListener('click', closeModal);
    </script>
</body>
</html>

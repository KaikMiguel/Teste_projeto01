<?php
require_once __DIR__ . '/../DAO/ProjectDAO.php';
require_once __DIR__ . '/../DAO/UserDAO.php';
require_once __DIR__ . '/../Utils/PasswordUtils.php';

$projectDAO = new ProjectDAO();
$userDAO = new UserDAO();

$profileUser = null;
if (isset($_SESSION['user_id'])) {
    $profileUser = $userDAO->findById($_SESSION['user_id']);
}

$userName = $profileUser->nome ?? ($_SESSION['nome'] ?? 'Utilizador');
$userEmail = $profileUser->email ?? ($_SESSION['email'] ?? '');
$profileUserId = isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : 0;
$budgetCount = $profileUserId > 0 ? $projectDAO->countProjectsByUser($profileUserId) : 0;
$recentProjects = $profileUserId > 0 ? $projectDAO->getRecentlyUpdatedProjects(4, $profileUserId) : [];
$userInitial = strtoupper(substr($userName, 0, 1));
$passwordRequirementText = PasswordUtils::requirementsText();
$profileSuccess = $_SESSION['profile_success'] ?? '';
$profileError = $_SESSION['profile_error'] ?? '';
unset($_SESSION['profile_success'], $_SESSION['profile_error']);
?>
<!DOCTYPE html>
<html class="light" lang="pt-PT">
<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Perfil - ENG-QUADROS</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        background: "#fcf8f7",
                        surface: "#fcf8f7",
                        "surface-container-lowest": "#ffffff",
                        "surface-container-low": "#f7f3f1",
                        "surface-container-high": "#ebe7e6",
                        "on-surface": "#1c1b1b",
                        "on-background": "#1c1b1b",
                        "on-surface-variant": "#454742",
                        "outline": "#767872",
                        "outline-variant": "#c6c7c0",
                        secondary: "#4e660f",
                        "secondary-container": "#cdeb87",
                        "on-secondary": "#ffffff",
                        error: "#ba1a1a",
                        "error-container": "#ffdad6"
                    },
                    borderRadius: { DEFAULT: "0.125rem", lg: "0.25rem", xl: "0.5rem", full: "0.75rem" },
                    spacing: { xs: "4px", sm: "8px", md: "16px", lg: "24px", xl: "48px", gutter: "16px" },
                    fontFamily: {
                        "body-md": ["Inter"],
                        "body-lg": ["Inter"],
                        "headline-md": ["Inter"],
                        "headline-sm": ["Inter"],
                        "label-md": ["Inter"],
                        "mono-sm": ["monospace"]
                    },
                    fontSize: {
                        "body-md": ["14px", { lineHeight: "1.5", fontWeight: "400" }],
                        "body-lg": ["16px", { lineHeight: "1.6", fontWeight: "400" }],
                        "headline-md": ["24px", { lineHeight: "1.2", fontWeight: "600" }],
                        "headline-sm": ["18px", { lineHeight: "1.4", fontWeight: "600" }],
                        "label-md": ["12px", { lineHeight: "1", letterSpacing: "0.05em", fontWeight: "500" }],
                        "mono-sm": ["12px", { lineHeight: "1", fontWeight: "400" }]
                    }
                }
            }
        }
    </script>
    <style>
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-background text-on-surface font-body-md text-body-md min-h-screen flex flex-col antialiased">
    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 border-b border-[#e1e2df] dark:border-stone-800">
        <span class="text-lg font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>
        <div class="flex items-center gap-sm">
            <button class="p-sm text-[#82837e] dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors rounded-full">
                <span class="material-symbols-outlined text-[24px]">notifications</span>
            </button>
            <a href="/enge-quadro/home" class="ml-sm w-9 h-9 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-[#94b053] hover:border-[#94b053] hover:bg-white transition-all duration-200 shadow-sm">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">home</span>
            </a>
        </div>
    </header>

    <div class="flex pt-16 flex-1 h-screen overflow-hidden">
        <?php require_once __DIR__ . '/sideMenu/sidebarGeneral.php'; ?>

        <main class="ml-64 flex-1 overflow-y-auto p-lg bg-surface">
            <div class="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-lg">
                <section class="lg:col-span-7 bg-surface-container-lowest border border-outline-variant rounded-xl p-lg shadow-sm">
                    <div class="flex items-center justify-between gap-md mb-lg">
                        <div>
                            <h1 class="font-headline-md text-headline-md text-on-surface flex items-center gap-sm">
                                <span class="material-symbols-outlined text-secondary">manage_accounts</span>
                                Gestão de Conta
                            </h1>
                            <p class="text-on-surface-variant mt-xs">Dados de acesso e segurança do utilizador.</p>
                        </div>
                        <div class="w-12 h-12 rounded-full bg-secondary-container text-secondary flex items-center justify-center font-bold text-lg">
                            <?php echo htmlspecialchars($userInitial); ?>
                        </div>
                    </div>

                    <?php if ($profileSuccess): ?>
                        <div class="mb-md border border-secondary-container bg-secondary-container/40 text-secondary px-md py-sm rounded-lg">
                            <?php echo htmlspecialchars($profileSuccess); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($profileError): ?>
                        <div class="mb-md border border-error-container bg-error-container text-error px-md py-sm rounded-lg">
                            <?php echo htmlspecialchars($profileError); ?>
                        </div>
                    <?php endif; ?>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-lg mb-xl">
                        <label class="flex flex-col gap-2">
                            <span class="font-label-md text-label-md uppercase text-on-surface-variant">Nome</span>
                            <input class="w-full bg-surface-container-low border border-outline-variant rounded px-md py-sm text-on-surface cursor-not-allowed" readonly type="text" value="<?php echo htmlspecialchars($userName); ?>" />
                        </label>
                        <label class="flex flex-col gap-2">
                            <span class="font-label-md text-label-md uppercase text-on-surface-variant">Email</span>
                            <input class="w-full bg-surface-container-low border border-outline-variant rounded px-md py-sm text-on-surface cursor-not-allowed" readonly type="email" value="<?php echo htmlspecialchars($userEmail); ?>" />
                        </label>
                    </div>

                    <form action="/enge-quadro/profile/change-password" method="POST" class="space-y-lg pt-lg border-t border-outline-variant">
                        <h2 class="font-headline-sm text-headline-sm text-on-surface flex items-center gap-sm">
                            <span class="material-symbols-outlined text-secondary">lock_reset</span>
                            Alterar Password
                        </h2>

                        <label class="flex flex-col gap-2">
                            <span class="font-label-md text-label-md uppercase text-on-surface-variant">Password Atual</span>
                            <div class="relative">
                                <input id="currentPassword" name="current_password" class="w-full bg-white border border-outline-variant rounded px-md py-sm pr-10 focus:outline-none focus:border-secondary" type="password" autocomplete="current-password" required />
                                <button type="button" class="toggle-password absolute right-3 top-1/2 -translate-y-1/2 text-outline hover:text-on-surface" data-target="currentPassword" title="Mostrar password">
                                    <span class="material-symbols-outlined text-[20px]">visibility</span>
                                </button>
                            </div>
                        </label>
                        <div id="currentPasswordStatus" class="hidden text-sm font-semibold"></div>

                        <div class="bg-surface-container-low border border-outline-variant rounded-lg p-md text-sm text-on-surface-variant">
                            <div class="font-label-md text-label-md uppercase text-on-surface mb-sm">Regras da nova password</div>
                            <p class="mb-sm"><?php echo htmlspecialchars($passwordRequirementText); ?></p>
                            <ul id="profilePasswordRules" class="space-y-1 text-xs"></ul>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-md">
                            <label class="flex flex-col gap-2">
                                <span class="font-label-md text-label-md uppercase text-on-surface-variant">Nova Password</span>
                                <div class="relative">
                                    <input id="profileNewPassword" name="new_password" class="w-full bg-white border border-outline-variant rounded px-md py-sm pr-10 focus:outline-none focus:border-secondary disabled:bg-surface-container-low disabled:cursor-not-allowed disabled:text-outline" type="password" autocomplete="new-password" minlength="8" required disabled />
                                    <button type="button" class="toggle-password absolute right-3 top-1/2 -translate-y-1/2 text-outline hover:text-on-surface disabled:opacity-40" data-target="profileNewPassword" title="Mostrar password" disabled>
                                        <span class="material-symbols-outlined text-[20px]">visibility</span>
                                    </button>
                                </div>
                            </label>
                            <label class="flex flex-col gap-2">
                                <span class="font-label-md text-label-md uppercase text-on-surface-variant">Confirmar Nova Password</span>
                                <div class="relative">
                                    <input id="profileConfirmPassword" name="confirm_password" class="w-full bg-white border border-outline-variant rounded px-md py-sm pr-10 focus:outline-none focus:border-secondary disabled:bg-surface-container-low disabled:cursor-not-allowed disabled:text-outline" type="password" autocomplete="new-password" minlength="8" required disabled />
                                    <button type="button" class="toggle-password absolute right-3 top-1/2 -translate-y-1/2 text-outline hover:text-on-surface disabled:opacity-40" data-target="profileConfirmPassword" title="Mostrar password" disabled>
                                        <span class="material-symbols-outlined text-[20px]">visibility</span>
                                    </button>
                                </div>
                            </label>
                        </div>

                        <div class="flex justify-end">
                            <button id="profilePasswordButton" class="bg-secondary text-on-secondary px-lg py-sm rounded-lg font-label-md text-label-md uppercase tracking-wider hover:opacity-90 flex items-center gap-sm disabled:opacity-40 disabled:cursor-not-allowed" type="button" disabled>
                                <span class="material-symbols-outlined text-[18px]">verified_user</span>
                                <span id="profilePasswordButtonText">Validar Password</span>
                            </button>
                        </div>
                    </form>
                </section>

                <aside class="lg:col-span-5 space-y-lg">
                    <section class="bg-surface-container-lowest border border-outline-variant rounded-xl p-lg shadow-sm">
                        <span class="material-symbols-outlined text-secondary mb-md text-3xl">folder_open</span>
                        <div class="font-label-md text-label-md uppercase text-on-surface-variant mb-xs">Projetos</div>
                        <div class="font-headline-md text-headline-md text-on-surface"><?php echo $budgetCount; ?></div>
                    </section>

                    <section class="bg-surface-container-lowest border border-outline-variant rounded-xl shadow-sm overflow-hidden">
                        <div class="p-lg border-b border-outline-variant">
                            <h2 class="font-headline-sm text-headline-sm text-on-surface flex items-center gap-sm">
                                <span class="material-symbols-outlined text-secondary">history</span>
                                Últimos Projetos Alterados
                            </h2>
                        </div>

                        <div class="overflow-x-auto">
                            <table class="w-full border-collapse">
                                <thead>
                                    <tr class="bg-surface-container-low border-b border-outline-variant">
                                        <th class="px-lg py-sm text-left font-label-md text-label-md uppercase text-on-surface-variant">Projeto</th>
                                        <th class="px-lg py-sm text-left font-label-md text-label-md uppercase text-on-surface-variant">Cliente</th>
                                        <th class="px-lg py-sm text-right font-label-md text-label-md uppercase text-on-surface-variant">Total</th>
                                        <th class="px-lg py-sm text-right font-label-md text-label-md uppercase text-on-surface-variant">Alterado</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-outline-variant">
                                    <?php if (empty($recentProjects)): ?>
                                        <tr>
                                            <td class="px-lg py-lg text-center text-on-surface-variant italic" colspan="4">Ainda não existem projetos.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($recentProjects as $project): ?>
                                            <?php $updatedAt = $project['updated_at'] ?? $project['created_at'] ?? null; ?>
                                            <tr class="hover:bg-surface-container-high transition-colors">
                                                <td class="px-lg py-md">
                                                    <a class="font-body-md text-body-md text-on-surface font-semibold hover:text-secondary" href="/enge-quadro/project/material-survey?project_id=<?php echo (int) $project['id']; ?>">
                                                        <?php echo htmlspecialchars($project['project_name'] ?? 'Projeto'); ?>
                                                    </a>
                                                    <div class="text-[10px] text-on-surface-variant"><?php echo htmlspecialchars($project['commercial_name'] ?? ''); ?></div>
                                                </td>
                                                <td class="px-lg py-md text-on-surface-variant"><?php echo htmlspecialchars($project['client'] ?? ''); ?></td>
                                                <td class="px-lg py-md text-right font-mono-sm text-on-surface">
                                                    <?php echo number_format((float) ($project['project_total'] ?? 0), 2, ',', '.'); ?> €
                                                </td>
                                                <td class="px-lg py-md text-right font-mono-sm text-secondary font-bold">
                                                    <?php echo $updatedAt ? date('d/m/Y H:i', strtotime($updatedAt)) : '-'; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </section>
                </aside>
            </div>
        </main>
    </div>
    <script>
        const currentPassword = document.getElementById('currentPassword');
        const profileNewPassword = document.getElementById('profileNewPassword');
        const profileConfirmPassword = document.getElementById('profileConfirmPassword');
        const profilePasswordButton = document.getElementById('profilePasswordButton');
        const profilePasswordButtonText = document.getElementById('profilePasswordButtonText');
        const profilePasswordRules = document.getElementById('profilePasswordRules');
        const currentPasswordStatus = document.getElementById('currentPasswordStatus');
        let currentPasswordValidated = false;

        const profileRules = [
            ['Pelo menos 8 caracteres', value => value.length >= 8],
            ['Pelo menos 1 letra maiúscula (A-Z)', value => /[A-Z]/.test(value)],
            ['Pelo menos 1 letra minúscula (a-z)', value => /[a-z]/.test(value)],
            ['Pelo menos 1 número (0-9)', value => /[0-9]/.test(value)],
            ['Pelo menos 1 caractere especial (!@#$%&*...)', value => /[!@#$%&*()_+\-=\[\]{};:'",.<>/?\\|`~^]/.test(value)],
            ['Não conter espaços', value => !/\s/.test(value)]
        ];

        function renderProfilePasswordRules() {
            if (!profilePasswordRules || !profileNewPassword) return;

            profilePasswordRules.innerHTML = profileRules.map(([label, test]) => {
                const ok = test(profileNewPassword.value);
                return `<li class="${ok ? 'text-secondary' : 'text-on-surface-variant'}">${ok ? '✓' : '•'} ${label}</li>`;
            }).join('');
        }

        function syncPasswordFields() {
            const hasCurrentPassword = currentPassword && currentPassword.value.length > 0;
            profileNewPassword.disabled = !currentPasswordValidated;
            profileConfirmPassword.disabled = !currentPasswordValidated;
            profilePasswordButton.disabled = !hasCurrentPassword;
            profilePasswordButton.type = currentPasswordValidated ? 'submit' : 'button';
            profilePasswordButtonText.textContent = currentPasswordValidated ? 'Guardar Password' : 'Validar Password';
            profilePasswordButton.querySelector('.material-symbols-outlined').textContent = currentPasswordValidated ? 'save' : 'verified_user';
            document.querySelectorAll('.toggle-password[data-target="profileNewPassword"], .toggle-password[data-target="profileConfirmPassword"]').forEach((button) => {
                button.disabled = !currentPasswordValidated;
            });

            if (!currentPasswordValidated) {
                profileNewPassword.value = '';
                profileConfirmPassword.value = '';
            }

            renderProfilePasswordRules();
        }

        currentPassword?.addEventListener('input', () => {
            currentPasswordValidated = false;
            currentPasswordStatus.className = 'hidden text-sm font-semibold';
            currentPasswordStatus.textContent = '';
            syncPasswordFields();
        });

        profilePasswordButton?.addEventListener('click', async (event) => {
            if (currentPasswordValidated) {
                return;
            }

            event.preventDefault();
            profilePasswordButton.disabled = true;
            profilePasswordButtonText.textContent = 'A validar...';

            const formData = new FormData();
            formData.append('current_password', currentPassword.value);

            try {
                const response = await fetch('/enge-quadro/profile/validate-password', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                currentPasswordValidated = Boolean(result.valid);
                currentPasswordStatus.className = currentPasswordValidated
                    ? 'text-sm font-semibold text-secondary'
                    : 'text-sm font-semibold text-error';
                currentPasswordStatus.textContent = result.message || (currentPasswordValidated ? 'Password validada.' : 'Password inválida.');
            } catch (error) {
                currentPasswordValidated = false;
                currentPasswordStatus.className = 'text-sm font-semibold text-error';
                currentPasswordStatus.textContent = 'Não foi possível validar a password agora.';
            }

            syncPasswordFields();
        });

        profileNewPassword?.addEventListener('input', renderProfilePasswordRules);
        document.querySelectorAll('.toggle-password').forEach((button) => {
            button.addEventListener('click', () => {
                const input = document.getElementById(button.dataset.target);
                const icon = button.querySelector('.material-symbols-outlined');
                if (!input || button.disabled) return;

                input.type = input.type === 'password' ? 'text' : 'password';
                icon.textContent = input.type === 'password' ? 'visibility' : 'visibility_off';
            });
        });
        syncPasswordFields();
    </script>
</body>
</html>

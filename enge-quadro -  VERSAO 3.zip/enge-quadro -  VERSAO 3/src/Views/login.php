<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html class="light" lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Login | IndustrialOS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "surface-container": "#f1edec",
                        "surface-container-high": "#ebe7e6",
                        "secondary-fixed-dim": "#b4d170",
                        "on-surface-variant": "#454742",
                        "tertiary-fixed": "#c5f31b",
                        "surface-tint": "#5d5f5a",
                        "secondary-container": "#cdeb87",
                        "primary-fixed-dim": "#c7c7c1",
                        "on-tertiary-fixed-variant": "#3c4d00",
                        "background": "#fcf8f7",
                        "outline": "#767872",
                        "tertiary": "#4f6300",
                        "on-surface": "#1c1b1b",
                        "primary-fixed": "#e3e3dd",
                        "tertiary-container": "#647e00",
                        "surface-bright": "#fcf8f7",
                        "on-secondary": "#ffffff",
                        "on-background": "#1c1b1b",
                        "on-secondary-container": "#526b14",
                        "on-primary-container": "#fdfdf7",
                        "surface-variant": "#e5e2e0",
                        "surface-container-highest": "#e5e2e0",
                        "inverse-primary": "#c7c7c1",
                        "surface": "#fcf8f7",
                        "primary-container": "#747570",
                        "secondary": "#4e660f",
                        "secondary-fixed": "#d0ee89",
                        "surface-dim": "#ddd9d8",
                        "on-tertiary-fixed": "#161e00",
                        "on-secondary-fixed-variant": "#394d00",
                        "on-primary": "#ffffff",
                        "on-error-container": "#93000a",
                        "outline-variant": "#c6c7c0",
                        "inverse-on-surface": "#f4f0ef",
                        "error-container": "#ffdad6",
                        "primary": "#5b5c58",
                        "on-tertiary": "#ffffff",
                        "inverse-surface": "#313030",
                        "on-error": "#ffffff",
                        "surface-container-lowest": "#ffffff",
                        "on-primary-fixed": "#1a1c19",
                        "on-primary-fixed-variant": "#464743",
                        "error": "#ba1a1a",
                        "tertiary-fixed-dim": "#abd600",
                        "surface-container-low": "#f7f3f1",
                        "on-tertiary-container": "#fbffe4",
                        "on-secondary-fixed": "#151f00"
                    },
                    "borderRadius": {
                        "DEFAULT": "0.125rem",
                        "lg": "0.25rem",
                        "xl": "0.5rem",
                        "full": "0.75rem"
                    },
                    "spacing": {
                        "unit": "4px",
                        "gutter": "16px",
                        "xl": "48px",
                        "lg": "24px",
                        "xs": "4px",
                        "sm": "8px",
                        "md": "16px",
                        "margin": "24px"
                    },
                    "fontFamily": {
                        "headline-lg": ["Inter"],
                        "headline-sm": ["Inter"],
                        "label-md": ["Inter"],
                        "headline-md": ["Inter"],
                        "body-lg": ["Inter"],
                        "body-md": ["Inter"],
                        "mono-sm": ["monospace"]
                    },
                    "fontSize": {
                        "headline-lg": ["32px", {"lineHeight": "1.2", "letterSpacing": "-0.02em", "fontWeight": "600"}],
                        "headline-sm": ["18px", {"lineHeight": "1.4", "fontWeight": "600"}],
                        "label-md": ["12px", {"lineHeight": "1", "letterSpacing": "0.05em", "fontWeight": "500"}],
                        "headline-md": ["24px", {"lineHeight": "1.2", "letterSpacing": "-0.01em", "fontWeight": "600"}],
                        "body-lg": ["16px", {"lineHeight": "1.6", "fontWeight": "400"}],
                        "body-md": ["14px", {"lineHeight": "1.5", "fontWeight": "400"}],
                        "mono-sm": ["12px", {"lineHeight": "1", "fontWeight": "400"}]
                    }
                },
            },
        }
    </script>
    <style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
        body {
            background-image: linear-gradient(rgba(252, 248, 247, 0.7), rgba(252, 248, 247, 0.7)), url('https://www.vrenergia.com.br/doutor/uploads/6/blog/2025/08/blog-melhores-fabricantes-de-paineis-eletricos-para-qualidade-e-confiabilidade-58210de2db.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
        }
    </style>
</head>
<body class="font-body-md text-on-background flex flex-col min-h-screen">
    
    <main class="flex-grow flex items-center justify-center px-gutter min-h-screen">
        <div class="w-full max-w-[450px] flex flex-col gap-lg z-10 py-6">
            
            <div class="flex flex-col items-center gap-xs mb-2">
                <h1 class="font-headline-lg text-[36px] font-black text-on-surface uppercase tracking-[0.15em] text-center">ENG-QUADROS</h1>
                <p class="font-label-md text-[13px] text-outline uppercase tracking-[0.22em] font-semibold">Ferramenta de Orçamentação</p>
            </div>
            
            <div class="bg-surface-container-lowest/95 backdrop-blur-sm border border-outline-variant p-8 shadow-2xl rounded-xl">
                
                <form class="flex flex-col gap-md" method="POST" action="/enge-quadro/login">
                    
                    <div class="flex flex-col gap-sm">
                        <?php if (isset($_SESSION['error'])): ?>
                            <div class="bg-error-container text-on-error-container border border-error p-3 rounded-md font-semibold text-base flex items-center gap-sm mb-2">
                                <span class="material-symbols-outlined text-[20px]">error</span>
                                <span><?php echo $_SESSION['error']; ?></span>
                            </div>
                            <?php unset($_SESSION['error']); ?>
                        <?php endif; ?>
                        <?php if (isset($_SESSION['success'])): ?>
                            <div class="bg-secondary-container text-on-secondary-container border border-secondary p-3 rounded-md font-semibold text-base flex items-center gap-sm mb-2">
                                <span class="material-symbols-outlined text-[20px]">check_circle</span>
                                <span><?php echo $_SESSION['success']; ?></span>
                            </div>
                            <?php unset($_SESSION['success']); ?>
                        <?php endif; ?>

                        <label class="font-label-md text-[13px] text-on-surface-variant uppercase tracking-wider font-extrabold" for="username">Email</label>
                        
                        <div class="relative">
                            <span class="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-outline text-[22px]">person</span>
                            <input class="w-full pl-11 pr-4 py-3 bg-white border border-outline-variant focus:border-primary focus:ring-0 text-base rounded-md font-body-md transition-colors placeholder:text-outline-variant" id="username" name="email" placeholder="engineer@industrial.os" type="text" required>
                        </div>
                    </div>
                    
                    <div class="flex flex-col gap-sm">
                        <div class="flex justify-between items-center">
                            <label class="font-label-md text-[13px] text-on-surface-variant uppercase tracking-wider font-extrabold" for="password">Password</label>
                            <a class="font-label-md text-[13px] text-secondary hover:underline transition-all font-semibold" href="/enge-quadro/recover-password">Recuperar password</a>
                        </div>
                        
                        <div class="relative">
                            <span class="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-outline text-[22px]">lock</span>
                            
                            <input class="w-full pl-11 pr-11 py-3 bg-white border border-outline-variant focus:border-primary focus:ring-0 text-base rounded-md font-body-md transition-colors placeholder:text-outline-variant" id="password" name="password" placeholder="••••••••" type="password" required>
                            
                            <button type="button" id="togglePassword" class="absolute right-4 top-1/2 -translate-y-1/2 text-outline hover:text-on-surface transition-colors flex items-center justify-center focus:outline-none">
                                <span class="material-symbols-outlined text-[22px]" id="eyeIcon">visibility</span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="flex items-center gap-sm py-1">
                        <input class="w-5 h-5 rounded border-outline-variant text-secondary focus:ring-0 focus:ring-offset-0 transition-all cursor-pointer" id="remember" name="remember_me" type="checkbox">
                        <label class="font-body-md text-base text-on-surface-variant cursor-pointer select-none font-semibold pl-1" for="remember">Remember me for 30 days</label>
                    </div>
                    
                    <button class="mt-2 w-full bg-secondary text-white font-bold rounded-md hover:opacity-90 active:opacity-100 transition-all flex items-center justify-center gap-sm cursor-pointer shadow-md py-3 px-gutter" type="submit">
                        <span class="tracking-widest uppercase text-sm font-black">Entrar no Sistema</span>
                        <span class="material-symbols-outlined text-[22px]">login</span>
                    </button>
                    
                </form>
            </div>
            
        </div>
    </main>

    <script>
        const passwordInput = document.getElementById('password');
        const togglePasswordButton = document.getElementById('togglePassword');
        const eyeIcon = document.getElementById('eyeIcon');

        togglePasswordButton.addEventListener('click', function () {
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                eyeIcon.textContent = 'visibility_off';
            } else {
                passwordInput.type = 'password';
                eyeIcon.textContent = 'visibility';
            }
        });
    </script>

</body>
</html>

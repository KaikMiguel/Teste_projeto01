<!DOCTYPE html>
<html class="light" lang="pt">
<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Admin Metrics - ENG-QUADROS</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        background: "#fcf8f7",
                        surface: "#fcf8f7",
                        "surface-container-lowest": "#ffffff",
                        "surface-container-low": "#f7f3f1",
                        "on-surface": "#1c1b1b",
                        "on-background": "#1c1b1b",
                        "on-surface-variant": "#454742",
                        "outline-variant": "#c6c7c0",
                        secondary: "#4e660f",
                        "on-secondary": "#ffffff"
                    },
                    borderRadius: { DEFAULT: "0.125rem", lg: "0.25rem", xl: "0.5rem" },
                    spacing: { unit: "4px", sm: "8px", md: "16px", lg: "24px", xl: "48px", margin: "24px" },
                    fontFamily: { "body-md": ["Inter"], "headline-lg": ["Inter"], "headline-sm": ["Inter"] },
                    fontSize: {
                        "body-md": ["14px", { lineHeight: "1.5", fontWeight: "400" }],
                        "headline-lg": ["32px", { lineHeight: "1.2", fontWeight: "600" }],
                        "headline-sm": ["18px", { lineHeight: "1.4", fontWeight: "600" }]
                    }
                }
            }
        }
    </script>
    <style>
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-background text-on-surface min-h-screen">
    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 left-0 border-b border-[#e1e2df] dark:border-stone-800">
        <span class="text-base font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>
        <div class="flex items-center gap-sm">
            <button class="p-2 text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors rounded-full flex items-center justify-center">
                <span class="material-symbols-outlined text-[22px]">notifications</span>
            </button>
            <a href="/enge-quadro/home" class="ml-sm w-9 h-9 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-[#94b053] hover:border-[#94b053] hover:bg-white transition-all duration-200 shadow-sm">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">home</span>
            </a>
        </div>
    </header>

    <?php require_once __DIR__ . '/sideMenu/sidebarGeneral.php'; ?>

    <main class="ml-64 flex-grow flex flex-col min-h-screen pt-16">
        <section class="p-margin flex flex-col gap-lg max-w-7xl mx-auto w-full">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-lg">
                <div class="bg-surface-container-lowest p-lg rounded-xl border border-outline-variant">
                    <p class="text-xs font-bold uppercase tracking-wider text-on-surface-variant mb-xs">Total de Artigos</p>
                    <h2 class="font-headline-lg text-headline-lg text-secondary">45.280</h2>
                </div>
                <div class="bg-surface-container-lowest p-lg rounded-xl border border-outline-variant">
                    <p class="text-xs font-bold uppercase tracking-wider text-on-surface-variant mb-xs">Utilizadores Ativos</p>
                    <h2 class="font-headline-lg text-headline-lg text-secondary">12</h2>
                </div>
                <div class="bg-secondary p-lg rounded-xl border border-secondary text-on-secondary">
                    <p class="text-xs font-bold uppercase tracking-wider opacity-80 mb-xs">Catalogo</p>
                    <h2 class="font-headline-sm text-headline-sm">Acoes Rapidas</h2>
                </div>
            </div>

            <div class="bg-surface-container-lowest rounded-xl border border-outline-variant overflow-hidden">
                <div class="p-lg border-b border-outline-variant flex items-center gap-sm">
                    <span class="material-symbols-outlined text-secondary">group</span>
                    <h1 class="font-headline-sm text-headline-sm">Gestao de Utilizadores</h1>
                </div>
                <div class="p-lg text-on-surface-variant">Painel administrativo em manutencao.</div>
            </div>
        </section>
    </main>
</body>
</html>

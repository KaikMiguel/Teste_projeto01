<?php
$equivalenceRows = $equivalenceData['rows'] ?? [];
$sourceTotal = (float) ($equivalenceData['source_total'] ?? 0);
$equivalentTotal = (float) ($equivalenceData['equivalent_total'] ?? 0);
$matchedCount = (int) ($equivalenceData['matched_count'] ?? 0);
$lineCount = (int) ($equivalenceData['line_count'] ?? 0);
$coverage = $lineCount > 0 ? ($matchedCount / $lineCount) * 100 : 0;
$difference = $equivalentTotal - $sourceTotal;
$differencePercent = $sourceTotal > 0 ? ($difference / $sourceTotal) * 100 : 0;
$selectedBrandName = '';
foreach ($equivalenceBrands as $brand) {
    if ((int) $brand['id'] === (int) $targetBrandId) {
        $selectedBrandName = $brand['name'];
        break;
    }
}
?>
<!DOCTYPE html>
<html class="light" lang="pt-PT">
<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>Equivalência | ENG-QUADROS</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        background: "#fcf8f7",
                        surface: "#fcf8f7",
                        "surface-container-lowest": "#ffffff",
                        "surface-container-low": "#f7f3f1",
                        "surface-container": "#f1edec",
                        "surface-container-high": "#ebe7e6",
                        "on-surface": "#1c1b1b",
                        "on-surface-variant": "#454742",
                        outline: "#767872",
                        "outline-variant": "#c6c7c0",
                        secondary: "#4e660f",
                        "secondary-container": "#cdeb87",
                        "on-secondary": "#ffffff",
                        error: "#ba1a1a"
                    },
                    borderRadius: { DEFAULT: "0.125rem", lg: "0.25rem", xl: "0.5rem", full: "0.75rem" },
                    spacing: { xs: "4px", sm: "8px", md: "16px", lg: "24px", xl: "48px", margin: "24px" },
                    fontFamily: { "body-md": ["Inter"], "headline-md": ["Inter"], "headline-sm": ["Inter"], "label-md": ["Inter"], "mono-sm": ["monospace"] },
                    fontSize: {
                        "body-md": ["14px", { lineHeight: "1.5", fontWeight: "400" }],
                        "headline-md": ["24px", { lineHeight: "1.2", fontWeight: "600" }],
                        "headline-sm": ["18px", { lineHeight: "1.4", fontWeight: "600" }],
                        "label-md": ["12px", { lineHeight: "1", letterSpacing: "0.05em", fontWeight: "500" }],
                        "mono-sm": ["12px", { lineHeight: "1", fontWeight: "400" }]
                    }
                }
            }
        }
    </script>
    <style>
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #c6c7c0; border-radius: 3px; }
    </style>
</head>
<body class="bg-background text-on-surface font-body-md text-body-md min-h-screen flex flex-col antialiased">
    <header class="bg-white dark:bg-stone-950 flex justify-between items-center w-full px-6 h-16 z-50 fixed top-0 border-b border-[#e1e2df] dark:border-stone-800">
        <span class="text-lg font-black uppercase tracking-widest text-stone-900 dark:text-stone-100">ENG-QUADROS</span>

        <?php require __DIR__ . '/partials/projectIndicator.php'; ?>

        <div class="flex items-center gap-sm">
            <button class="p-sm text-[#82837e] dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors rounded-full">
                <span class="material-symbols-outlined text-[24px]">notifications</span>
            </button>
            <a href="/enge-quadro/home" class="ml-sm w-9 h-9 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 hover:text-[#94b053] hover:border-[#94b053] hover:bg-white transition-all duration-200 shadow-sm">
                <span class="material-symbols-outlined text-[22px]" style="font-variation-settings: 'FILL' 1;">home</span>
            </a>
        </div>
    </header>

    <div class="flex pt-16 flex-1 h-screen overflow-hidden">
        <?php require_once __DIR__ . '/sideMenu/sidebarProjectPages.php'; ?>

        <div class="flex flex-col flex-1 min-w-0 ml-[256px]">
            <main class="flex-1 overflow-y-auto p-lg flex flex-col gap-lg bg-surface">
                <section class="grid grid-cols-1 xl:grid-cols-3 gap-lg">
                    <div class="xl:col-span-2 bg-surface-container-lowest border border-outline-variant rounded-xl p-lg shadow-sm">
                        <div>
                            <h1 class="font-headline-md text-headline-md text-on-surface">Equivalência de Materiais</h1>
                            <p class="text-on-surface-variant mt-xs">Comparação linha a linha baseada na família e características técnicas existentes na base de dados.</p>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-lg mt-lg">
                            <div>
                                <div class="font-label-md text-label-md uppercase text-on-surface-variant mb-xs">Material Original</div>
                                <div class="font-headline-md text-headline-md text-on-surface"><?php echo number_format($sourceTotal, 2, ',', '.'); ?> €</div>
                            </div>
                            <div>
                                <div class="font-label-md text-label-md uppercase text-on-surface-variant mb-xs">Equivalência <?php echo htmlspecialchars($selectedBrandName); ?></div>
                                <div class="font-headline-md text-headline-md text-secondary"><?php echo number_format($equivalentTotal, 2, ',', '.'); ?> €</div>
                            </div>
                            <div class="flex items-center">
                                <div class="<?php echo $difference <= 0 ? 'bg-secondary-container text-secondary' : 'bg-red-50 text-error'; ?> rounded-lg px-md py-sm font-label-md text-label-md uppercase tracking-wider">
                                    <?php echo $difference <= 0 ? 'Poupança' : 'Acréscimo'; ?> <?php echo number_format(abs($differencePercent), 2, ',', '.'); ?>%
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="bg-surface-container-lowest border border-outline-variant rounded-xl p-lg shadow-sm">
                        <h2 class="font-headline-sm text-headline-sm mb-md">Marca de equivalência</h2>
                        <form method="GET" action="/enge-quadro/equivalencia" class="flex flex-col gap-md">
                            <input type="hidden" name="project_id" value="<?php echo (int) $projectId; ?>">
                            <?php if (isset($_GET['board_id'])): ?>
                                <input type="hidden" name="board_id" value="<?php echo (int) $_GET['board_id']; ?>">
                            <?php endif; ?>
                            <label class="flex flex-col gap-sm">
                                <span class="font-label-md text-label-md uppercase text-on-surface-variant">Comparar com</span>
                                <select name="target_brand_id" class="bg-white border border-outline-variant rounded px-md py-sm focus:outline-none focus:border-secondary">
                                    <?php foreach ($equivalenceBrands as $brand): ?>
                                        <option value="<?php echo (int) $brand['id']; ?>" <?php echo (int) $brand['id'] === (int) $targetBrandId ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($brand['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                            <button class="bg-secondary text-on-secondary rounded-lg px-md py-sm font-label-md text-label-md uppercase tracking-wider flex items-center justify-center gap-sm" type="submit">
                                <span class="material-symbols-outlined text-[18px]">sync</span>
                                Validar
                            </button>
                        </form>
                        <div class="mt-lg text-sm text-on-surface-variant">
                            <?php echo $matchedCount; ?> de <?php echo $lineCount; ?> linhas com equivalência encontrada.
                            <div class="mt-sm h-2 bg-surface-container rounded-full overflow-hidden">
                                <div class="h-full bg-secondary" style="width: <?php echo number_format($coverage, 2, '.', ''); ?>%"></div>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="bg-surface-container-lowest border border-outline-variant rounded-xl overflow-hidden shadow-sm">
                    <div class="grid grid-cols-12 bg-surface-container-low border-b border-outline-variant font-label-md text-label-md text-on-surface-variant uppercase tracking-widest">
                        <div class="col-span-5 px-lg py-md border-r border-outline-variant">Material original</div>
                        <div class="col-span-2 px-md py-md text-center">Estado</div>
                        <div class="col-span-5 px-lg py-md border-l border-outline-variant">Material equivalente</div>
                    </div>

                    <?php if (empty($equivalenceRows)): ?>
                        <div class="p-xl text-center text-on-surface-variant italic">Adicione materiais ao projeto para calcular equivalências.</div>
                    <?php else: ?>
                        <div class="divide-y divide-outline-variant">
                            <?php foreach ($equivalenceRows as $row): ?>
                                <?php
                                    $source = $row['source'];
                                    $equivalent = $row['equivalent'];
                                    $quantity = (int) $row['quantity'];
                                    $sourceLineTotal = (float) $row['source_line_total'];
                                    $equivalentLineTotal = (float) $row['equivalent_line_total'];
                                    $lineDiffPercent = $sourceLineTotal > 0 && $equivalent ? (($equivalentLineTotal - $sourceLineTotal) / $sourceLineTotal) * 100 : 0;
                                ?>
                                <div class="grid grid-cols-12 hover:bg-surface-container-low transition-colors">
                                    <div class="col-span-5 px-lg py-md border-r border-outline-variant">
                                        <div class="text-[10px] uppercase text-outline mb-xs"><?php echo htmlspecialchars($row['board']['board_name'] ?? 'Quadro'); ?> · Qtd <?php echo $quantity; ?></div>
                                        <div class="font-mono-sm text-secondary font-bold mb-xs"><?php echo htmlspecialchars($source['referencia'] ?? ''); ?></div>
                                        <div class="font-semibold text-on-surface"><?php echo htmlspecialchars($source['descricao'] ?? ''); ?></div>
                                        <div class="mt-sm flex items-center gap-md">
                                            <span class="text-on-surface-variant"><?php echo htmlspecialchars($source['marca'] ?? ''); ?></span>
                                            <span class="font-headline-sm"><?php echo number_format($sourceLineTotal, 2, ',', '.'); ?> €</span>
                                        </div>
                                    </div>

                                    <div class="col-span-2 px-md py-md flex flex-col items-center justify-center gap-sm text-center">
                                        <?php if ($equivalent): ?>
                                            <div class="flex items-center gap-xs text-secondary">
                                                <span class="material-symbols-outlined text-[18px]" style="font-variation-settings: 'FILL' 1;">check_circle</span>
                                                <span class="font-label-md text-label-md uppercase">Exata</span>
                                            </div>
                                            <span class="text-[10px] text-on-surface-variant uppercase">Características iguais</span>
                                        <?php else: ?>
                                            <div class="flex items-center gap-xs text-error">
                                                <span class="material-symbols-outlined text-[18px]">error</span>
                                                <span class="font-label-md text-label-md uppercase">Sem match</span>
                                            </div>
                                            <span class="text-[10px] text-on-surface-variant uppercase">Requer análise</span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-span-5 px-lg py-md border-l border-outline-variant bg-secondary-container/5">
                                        <?php if ($equivalent): ?>
                                            <div class="font-mono-sm text-secondary font-bold mb-xs"><?php echo htmlspecialchars($equivalent['referencia'] ?? ''); ?></div>
                                            <div class="font-semibold text-on-surface"><?php echo htmlspecialchars($equivalent['descricao'] ?? ''); ?></div>
                                            <div class="mt-sm flex items-center gap-md">
                                                <span class="text-on-surface-variant"><?php echo htmlspecialchars($equivalent['marca'] ?? ''); ?></span>
                                                <span class="font-headline-sm text-secondary"><?php echo number_format($equivalentLineTotal, 2, ',', '.'); ?> €</span>
                                                <span class="<?php echo $lineDiffPercent <= 0 ? 'text-secondary' : 'text-error'; ?> text-[11px] font-bold">
                                                    <?php echo $lineDiffPercent <= 0 ? '-' : '+'; ?><?php echo number_format(abs($lineDiffPercent), 2, ',', '.'); ?>%
                                                </span>
                                            </div>
                                        <?php else: ?>
                                            <div class="h-full flex items-center text-on-surface-variant italic">Sem equivalência automática para esta linha.</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
            </main>
        </div>

        <?php require_once __DIR__ . '/sideMenu/sidebarProject.php'; ?>
    </div>
</body>
</html>

<?php
$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
$basePath = '/enge-quadro';
require_once __DIR__ . '/../../DAO/RoleDAO.php';

if (strpos($currentPath, $basePath) === 0) {
    $currentPath = substr($currentPath, strlen($basePath)) ?: '/';
}

$activeItemClass = "flex items-center gap-md px-lg py-sm bg-stone-100 dark:bg-stone-900 text-stone-900 dark:text-white border-r-4 border-[#94b053] font-['Inter'] text-[11px] font-bold uppercase tracking-widest";
$inactiveItemClass = "flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest";
$dangerItemClass = "flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-red-600 dark:hover:text-red-400 transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest";

$menuItems = [
    ['path' => '/home', 'href' => '/enge-quadro/home', 'icon' => 'precision_manufacturing', 'label' => 'Home'],
    ['path' => '/library', 'href' => '/enge-quadro/library', 'icon' => 'inventory_2', 'label' => 'Library'],
];

$canAccessAdminPanel = false;
if (isset($_SESSION['user_id'])) {
    $roleDAO = new RoleDAO();
    $canAccessAdminPanel = $roleDAO->userCanAccess($_SESSION['user_id'], '/admin-panel');
}

if ($canAccessAdminPanel) {
    $menuItems[] = ['path' => '/admin-panel', 'href' => '/enge-quadro/admin-panel', 'icon' => 'monitoring', 'label' => 'Admin Metrics', 'danger' => true];
}

$isProfileActive = $currentPath === '/profile';
?>

<nav class="bg-white dark:bg-stone-950 fixed left-0 top-16 h-[calc(100vh-64px)] w-64 border-r border-[#e1e2df] dark:border-stone-800 flex flex-col pt-4 overflow-y-auto z-40">

    <ul class="flex flex-col gap-unit">
        <?php foreach ($menuItems as $item): ?>
            <?php
                $isActive = $currentPath === $item['path']
                    || ($currentPath === '/' && $item['path'] === '/home');
                $itemClass = $isActive ? $activeItemClass : (($item['danger'] ?? false) ? $dangerItemClass : $inactiveItemClass);
            ?>
        <li>
            <a class="<?php echo $itemClass; ?>" href="<?php echo $item['href']; ?>">
                <span class="material-symbols-outlined text-[20px]"<?php echo $isActive ? " style=\"font-variation-settings: 'FILL' 1;\"" : ''; ?>><?php echo $item['icon']; ?></span>
                <?php echo $item['label']; ?>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>

    <div class="mt-auto pt-4 pb-8 border-t border-[#e1e2df] dark:border-stone-800 flex flex-col gap-unit">
        <a class="flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-red-600 dark:hover:text-red-400 transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest" 
           href="/enge-quadro/logout">
            <span class="material-symbols-outlined text-[20px]">logout</span>
            Sign Out
        </a>
        
        <a class="flex items-center gap-md px-lg py-sm mt-2 <?php echo $isProfileActive ? 'bg-stone-100 dark:bg-stone-900 text-stone-900 dark:text-white border-r-4 border-[#94b053]' : ''; ?>"
           href="/enge-quadro/profile">
            <div class="w-8 h-8 rounded-full bg-stone-200 overflow-hidden border border-stone-300 flex-shrink-0">
                <img alt="User" class="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDiu2LPPGzfXy4WhsQb79Tce77jM0xg15beLaP_X7cs580Fb2HSGduwo0RwR-1G20EtDS6pEb0vYtjZfdCyv6LLp2mOziHfVeWvptNyv5FUGFm7e-8YojzVGDiAk9buYa3Hlnf0pwJKiJy7gOTp79r5laNS4oGkPmvjjij-dw69cyp2X9w5i3Ggd82TQ6MWZ5DAGTYgZJZ4cYupof87EmLW4-VNDhUMUUye7c44DyXSFwo94Wa6hVIfgatLbEOWnjiW7CewrsUKe9w"/>
            </div>
            <span class="font-['Inter'] text-[11px] font-bold uppercase tracking-widest text-stone-900 dark:text-white truncate">
                <?php echo $_SESSION['nome'] ?? 'Profile'; ?>
            </span>
        </a>
    </div>
</nav>

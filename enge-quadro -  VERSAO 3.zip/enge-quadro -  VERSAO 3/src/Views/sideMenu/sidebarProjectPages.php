<?php
$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
$basePath = '/enge-quadro';

if (strpos($currentPath, $basePath) === 0) {
    $currentPath = substr($currentPath, strlen($basePath)) ?: '/';
}

$projectId = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
$boardId = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;
$projectQueryParams = [];
if ($projectId > 0) {
    $projectQueryParams['project_id'] = $projectId;
}
if ($boardId > 0) {
    $projectQueryParams['board_id'] = $boardId;
}
$projectQuery = !empty($projectQueryParams) ? '?' . http_build_query($projectQueryParams) : '';

$activeItemClass = "flex items-center gap-md px-lg py-sm bg-stone-100 dark:bg-stone-900 text-stone-900 dark:text-white border-r-4 border-[#94b053] font-['Inter'] text-[11px] font-bold uppercase tracking-widest";
$inactiveItemClass = "flex items-center gap-md px-lg py-sm text-stone-500 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white transition-all ease-in-out duration-150 font-['Inter'] text-[11px] font-bold uppercase tracking-widest";

$menuItems = [
    ['paths' => ['/project/material-survey', '/material-survey', '/materialSurvey'], 'href' => '/enge-quadro/project/material-survey' . $projectQuery, 'icon' => 'inventory_2', 'label' => 'Material'],
    ['paths' => ['/electrical-diagram', '/electricalDiagram'], 'href' => '/enge-quadro/electrical-diagram' . $projectQuery, 'icon' => 'account_tree', 'label' => 'Esquema'],
    ['paths' => ['/layout'], 'href' => '/enge-quadro/layout' . $projectQuery, 'icon' => 'grid_view', 'label' => 'Layout'],
    ['paths' => ['/estimate'], 'href' => '/enge-quadro/estimate' . $projectQuery, 'icon' => 'payments', 'label' => 'Orçamento'],
    ['paths' => ['/equivalencia'], 'href' => '/enge-quadro/equivalencia' . $projectQuery, 'icon' => 'compare_arrows', 'label' => 'Equivalência'],
];

?>

<nav class="bg-white dark:bg-stone-950 fixed left-0 top-16 h-[calc(100vh-64px)] w-64 border-r border-[#e1e2df] dark:border-stone-800 flex flex-col pt-4 overflow-y-auto z-40">
    <ul class="flex flex-col gap-unit">
        <?php foreach ($menuItems as $item): ?>
            <?php
                $isActive = in_array($currentPath, $item['paths'], true);
                $itemClass = $isActive ? $activeItemClass : $inactiveItemClass;
            ?>
            <li>
                <a class="<?php echo $itemClass; ?>" href="<?php echo $item['href']; ?>">
                    <span class="material-symbols-outlined text-[20px]"<?php echo $isActive ? " style=\"font-variation-settings: 'FILL' 1;\"" : ''; ?>><?php echo $item['icon']; ?></span>
                    <?php echo $item['label']; ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>

</nav>

<?php
$current_project_id = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
$current_board_id = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;

if (!isset($switchboards)) {
    $switchboards = [];
    if ($current_project_id > 0) {
        require_once __DIR__ . '/../../DAO/ProjectDAO.php';
        $sidebarProjectDAO = new ProjectDAO();
        $switchboards = $sidebarProjectDAO->getSwitchboardsByProject($current_project_id);
    }
}

$current_path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '/enge-quadro/project/material-survey';
if (strpos($current_path, '/enge-quadro') !== 0) {
    $current_path = '/enge-quadro/project/material-survey';
}
$return_to = $_SERVER['REQUEST_URI'] ?? ('/enge-quadro/project/material-survey?project_id=' . $current_project_id);
?>

<aside class="w-64 bg-white dark:bg-stone-950 border-l border-[#e1e2df] dark:border-stone-800 h-[calc(100vh-64px)] flex flex-col flex-shrink-0">
    <div class="p-md flex flex-col gap-md">
        <div class="flex justify-between items-center px-xs mb-xs mt-2">
            <span class="font-['Inter'] text-[11px] font-bold text-stone-500 dark:text-stone-400 uppercase tracking-widest">Gestao de Quadros</span>
        </div>

        <form action="/enge-quadro/boards/create" method="GET" class="flex items-center gap-xs">
            <input type="hidden" name="project_id" value="<?php echo $current_project_id; ?>">
            <input type="hidden" name="return_to" value="<?php echo htmlspecialchars($return_to); ?>">
            <input name="name" required class="min-w-0 flex-1 bg-white dark:bg-stone-950 border border-[#e1e2df] dark:border-stone-800 rounded px-2 py-1.5 text-[12px] text-stone-900 dark:text-stone-100 focus:outline-none focus:border-[#94b053]" placeholder="Novo quadro" type="text">
            <button type="submit" class="h-8 w-8 text-[#94b053] hover:text-stone-900 dark:hover:text-white hover:bg-stone-50 dark:hover:bg-stone-900 transition-colors flex items-center justify-center rounded border border-[#e1e2df] dark:border-stone-800" title="Criar quadro">
                <span class="material-symbols-outlined text-[20px]" style="font-variation-settings: 'FILL' 1;">add</span>
            </button>
        </form>

        <nav class="flex flex-col gap-xs overflow-y-auto max-h-[calc(100vh-240px)] pr-xs">
            <?php if (empty($switchboards)): ?>
                <p class="text-xs text-stone-400 italic px-xs">Nenhum quadro criado.</p>
            <?php else: ?>
                <?php foreach ($switchboards as $board):
                    $is_selected = ((int) $board['id'] === $current_board_id);
                    $board_query = ['project_id' => $current_project_id, 'board_id' => $board['id']];

                    if ($current_path === '/enge-quadro/project/material-survey') {
                        if (isset($_GET['category_id'])) {
                            $board_query['category_id'] = intval($_GET['category_id']);
                        }
                        if (isset($_GET['brand_id'])) {
                            $board_query['brand_id'] = intval($_GET['brand_id']);
                        }
                    }

                    $board_url = $current_path . '?' . http_build_query($board_query);
                ?>
                    <div class="group flex items-center justify-between w-full rounded-md transition-all duration-150 <?php echo $is_selected ? 'bg-[#cdeb87] text-stone-900 font-semibold shadow-sm' : 'text-stone-600 dark:text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-900 hover:text-stone-900 dark:hover:text-white'; ?>">
                        <a href="<?php echo $board_url; ?>" class="flex-1 py-2 px-3 flex items-center gap-sm text-[13px] truncate">
                            <span class="truncate"><?php echo htmlspecialchars($board['board_name']); ?></span>
                        </a>

                        <div class="flex items-center gap-1 pr-3">
                            <?php if ($is_selected): ?>
                                <span class="material-symbols-outlined text-[16px] text-stone-700 group-hover:hidden" style="font-variation-settings: 'FILL' 1;">bolt</span>
                            <?php endif; ?>

                            <div class="hidden group-hover:flex items-center gap-1 transition-all">
                                <button onclick="copyBoard(<?php echo $board['id']; ?>)" title="Copiar Quadro" class="text-stone-400 hover:text-stone-900 dark:hover:text-white p-0.5 rounded">
                                    <span class="material-symbols-outlined text-[15px]">content_copy</span>
                                </button>
                                <button onclick="deleteBoard(<?php echo $board['id']; ?>)" title="Eliminar Quadro" class="text-stone-400 hover:text-red-600 p-0.5 rounded">
                                    <span class="material-symbols-outlined text-[15px]">delete</span>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </nav>
    </div>

</aside>

<script>
function deleteBoard(boardId) {
    if (confirm("Tem a certeza de que deseja eliminar este quadro?")) {
        window.location.href = "/enge-quadro/boards/delete?project_id=<?php echo $current_project_id; ?>&return_to=<?php echo rawurlencode($return_to); ?>&board_id=" + boardId;
    }
}
function copyBoard(boardId) {
    if (confirm("Deseja duplicar este quadro eletrico?")) {
        window.location.href = "/enge-quadro/boards/copy?project_id=<?php echo $current_project_id; ?>&board_id=" + boardId;
    }
}
</script>

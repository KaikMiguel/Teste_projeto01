<?php
// src/Controllers/EquivalenciaController.php

require_once __DIR__ . '/../DAO/ProjectDAO.php';

class EquivalenciaController {
    private $projectDAO;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: /enge-quadro/login');
            exit;
        }

        $this->projectDAO = new ProjectDAO();
    }

    public function index() {
        $projectId = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
        $targetBrandId = isset($_GET['target_brand_id']) ? intval($_GET['target_brand_id']) : 0;
        $equivalenceProject = null;
        $equivalenceBrands = $this->projectDAO->getBrands();
        $equivalenceData = [
            'rows' => [],
            'source_total' => 0,
            'equivalent_total' => 0,
            'matched_count' => 0,
            'line_count' => 0
        ];

        if ($projectId > 0) {
            $equivalenceProject = $this->projectDAO->getProjectById($projectId);

            if ($targetBrandId <= 0 && !empty($equivalenceBrands)) {
                foreach ($equivalenceBrands as $brand) {
                    if (strtoupper($brand['name'] ?? '') === 'HAGER') {
                        $targetBrandId = (int) $brand['id'];
                        break;
                    }
                }

                if ($targetBrandId <= 0) {
                    $targetBrandId = (int) ($equivalenceBrands[0]['id'] ?? 0);
                }
            }

            if ($targetBrandId > 0) {
                $equivalenceData = $this->projectDAO->buildProjectEquivalence($projectId, $targetBrandId);
            }
        }

        require_once __DIR__ . '/../Views/equivalencia.php';
    }
}

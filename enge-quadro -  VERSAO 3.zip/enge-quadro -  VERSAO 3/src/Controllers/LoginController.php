<?php
// src/Controllers/LoginController.php

require_once __DIR__ . '/../DAO/UserDAO.php';
require_once __DIR__ . '/../Utils/PasswordUtils.php';
require_once __DIR__ . '/../DAO/RoleDAO.php';

class LoginController {
    private $userDAO;

    public function __construct() {
        $this->userDAO = new UserDAO();
        // Garante que a sessão está ativa para podermos salvar e ler os erros/dados do utilizador
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    /**
     * Exibir o ecrã de login (GET)
     * Rota: /enge-quadro/login
     */
    public function showLogin() {
        // Se o utilizador já tiver uma sessão ativa, manda-o direto para a Home
        if (isset($_SESSION['user_id'])) {
            header('Location: /enge-quadro/home');
            exit();
        }
        
        // Caso contrário, carrega a View do login
        require_once __DIR__ . '/../Views/login.php';
    }

    /**
     * Processar o formulário de login (POST) - MODO SEGURO DEFINITIVO
     */
    public function login() {
        // 1. Captura o email e a password sem alterar os caracteres
        $email = isset($_POST['email']) ? trim($_POST['email']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';

        if (empty($email) || empty($password)) {
            $_SESSION['error'] = "Por favor, preencha todos os campos.";
            header("Location: /enge-quadro/login");
            exit();
        }

        // 2. Procura o utilizador na Base de Dados pelo email
        $user = $this->userDAO->findByEmail($email);

        // 3. Validação segura usando o password_verify contra o hash corrigido
        if ($user && $user->estado === 'ativo' && password_verify($password, $user->password_hash)) {
            
            // Gravar dados oficiais na sessão
            $_SESSION['user_id'] = $user->id;
            $_SESSION['nome'] = $user->nome;
            $_SESSION['email'] = $user->email;
            $_SESSION['role_id'] = $user->role_id;

            $roleDAO = new RoleDAO();
            $role = $roleDAO->getRoleForUser($user->id);
            $_SESSION['role_name'] = $role->nome ?? 'user';

            unset($_SESSION['error']);

            // 4. Redireciona para a Home
            header("Location: /enge-quadro/home");
            exit();
        } else {
            // Se falhar, define o erro e volta para o login
            $_SESSION['error'] = "E-mail ou password incorretos!";
            header("Location: /enge-quadro/login");
            exit();
        }
    }

    /**
     * Efetuar o logout do sistema
     */
    public function logout() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        session_destroy();
        header("Location: /enge-quadro/login");
        exit();
    }

    public function changePassword() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /enge-quadro/login');
            exit();
        }

        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') {
            $_SESSION['profile_error'] = 'Preencha todos os campos da password.';
            header('Location: /enge-quadro/profile');
            exit();
        }

        if ($newPassword !== $confirmPassword) {
            $_SESSION['profile_error'] = 'A nova password e a confirmação não coincidem.';
            header('Location: /enge-quadro/profile');
            exit();
        }

        $strength = PasswordUtils::validateStrength($newPassword);
        if (!$strength['valid']) {
            $_SESSION['profile_error'] = 'A nova password deve ' . implode(', ', $strength['errors']) . '.';
            header('Location: /enge-quadro/profile');
            exit();
        }

        $user = $this->userDAO->findById($_SESSION['user_id']);
        if (!$user || !password_verify($currentPassword, $user->password_hash)) {
            $_SESSION['profile_error'] = 'A password atual não está correta.';
            header('Location: /enge-quadro/profile');
            exit();
        }

        $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
        if (!$this->userDAO->updatePassword($_SESSION['user_id'], $passwordHash)) {
            $_SESSION['profile_error'] = 'Não foi possível alterar a password. Tente novamente.';
            header('Location: /enge-quadro/profile');
            exit();
        }

        $_SESSION['profile_success'] = 'Password alterada com sucesso.';
        header('Location: /enge-quadro/profile');
        exit();
    }

    public function validateCurrentPassword() {
        header('Content-Type: application/json');

        if (!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['valid' => false, 'message' => 'Sessão expirada.']);
            exit();
        }

        $currentPassword = $_POST['current_password'] ?? '';
        $user = $this->userDAO->findById($_SESSION['user_id']);

        if (!$user || !password_verify($currentPassword, $user->password_hash)) {
            echo json_encode(['valid' => false, 'message' => 'A password atual não está correta.']);
            exit();
        }

        echo json_encode(['valid' => true, 'message' => 'Password validada.']);
        exit();
    }

    public function showRecoverPassword() {
        require_once __DIR__ . '/../Views/recoverPassword.php';
    }

    public function sendPasswordResetCode() {
        $email = trim($_POST['email'] ?? '');

        if ($email === '') {
            $_SESSION['recover_error'] = 'Introduza o email da sua conta.';
            header('Location: /enge-quadro/recover-password');
            exit();
        }

        $user = $this->userDAO->findByEmail($email);
        if ($user && $user->estado === 'ativo') {
            $code = (string) random_int(100000, 999999);
            $expiresAt = date('Y-m-d H:i:s', time() + 15 * 60);
            $this->userDAO->createPasswordResetCode($user->id, $code, $expiresAt);

            $subject = 'Código de recuperação ENG-QUADROS';
            $message = "O seu código de recuperação é: {$code}\n\nEste código expira em 15 minutos.";
            @mail($user->email, $subject, $message, 'From: no-reply@enge-quadro.local');
            $_SESSION['recover_email'] = $user->email;
        } else {
            $_SESSION['recover_email'] = $email;
        }

        $_SESSION['recover_step'] = 'code';
        $_SESSION['recover_success'] = 'Se o email existir, enviámos um código de 6 dígitos.';
        header('Location: /enge-quadro/recover-password');
        exit();
    }

    public function verifyPasswordResetCode() {
        $email = $_SESSION['recover_email'] ?? '';
        $code = trim($_POST['code'] ?? '');
        $reset = $this->userDAO->findValidPasswordReset($email, $code);

        if (!$reset) {
            $_SESSION['recover_error'] = 'Código inválido ou expirado.';
            $_SESSION['recover_step'] = 'code';
            header('Location: /enge-quadro/recover-password');
            exit();
        }

        $_SESSION['recover_reset_id'] = $reset['id'];
        $_SESSION['recover_user_id'] = $reset['user_id'];
        $_SESSION['recover_step'] = 'password';
        header('Location: /enge-quadro/recover-password');
        exit();
    }

    public function resetPasswordWithCode() {
        $resetId = $_SESSION['recover_reset_id'] ?? null;
        $userId = $_SESSION['recover_user_id'] ?? null;
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!$resetId || !$userId) {
            $_SESSION['recover_error'] = 'Valide primeiro o código recebido por email.';
            $_SESSION['recover_step'] = 'code';
            header('Location: /enge-quadro/recover-password');
            exit();
        }

        if ($newPassword !== $confirmPassword) {
            $_SESSION['recover_error'] = 'A nova password e a confirmação não coincidem.';
            $_SESSION['recover_step'] = 'password';
            header('Location: /enge-quadro/recover-password');
            exit();
        }

        $strength = PasswordUtils::validateStrength($newPassword);
        if (!$strength['valid']) {
            $_SESSION['recover_error'] = 'A nova password deve ' . implode(', ', $strength['errors']) . '.';
            $_SESSION['recover_step'] = 'password';
            header('Location: /enge-quadro/recover-password');
            exit();
        }

        $this->userDAO->updatePassword($userId, password_hash($newPassword, PASSWORD_DEFAULT));
        $this->userDAO->markPasswordResetUsed($resetId);
        unset($_SESSION['recover_step'], $_SESSION['recover_email'], $_SESSION['recover_reset_id'], $_SESSION['recover_user_id']);
        $_SESSION['success'] = 'Password alterada com sucesso. Já pode iniciar sessão.';
        header('Location: /enge-quadro/login');
        exit();
    }
}

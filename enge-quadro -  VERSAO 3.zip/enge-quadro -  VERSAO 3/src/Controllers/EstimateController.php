<?php
// src/Controllers/EstimateController.php

require_once __DIR__ . '/../DAO/ProjectDAO.php';

class EstimateController {
    private $projectDAO;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: /enge-quadro/login');
            exit;
        }

        $this->projectDAO = new ProjectDAO();
    }

    public function index() {
        $projectId = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
        $estimateBoards = [];

        if ($projectId > 0) {
            $estimateBoards = $this->projectDAO->getProjectBoardsWithItems($projectId);
            $activeBoardId = isset($_GET['board_id']) ? intval($_GET['board_id']) : 0;

            if ($activeBoardId > 0) {
                usort($estimateBoards, function ($a, $b) use ($activeBoardId) {
                    return ((int) $b['id'] === $activeBoardId) <=> ((int) $a['id'] === $activeBoardId);
                });
            }
        }

        require_once __DIR__ . '/../Views/estimate.php';
    }

    public function exportMaterials() {
        $projectId = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;
        if ($projectId <= 0) {
            http_response_code(400);
            echo 'Projeto invalido.';
            exit;
        }

        $project = $this->projectDAO->getProjectById($projectId);
        $boards = $this->projectDAO->getProjectBoardsWithItems($projectId);
        $projectName = $project['project_name'] ?? ('projeto_' . $projectId);
        $safeName = preg_replace('/[^a-zA-Z0-9_-]+/', '_', $projectName);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="materiais_' . $safeName . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        fwrite($output, "\xEF\xBB\xBF");

        $writeCsvRow = static function ($handle, array $row): void {
            $escaped = array_map(static function ($value): string {
                return '"' . str_replace('"', '""', (string) $value) . '"';
            }, $row);
            fwrite($handle, implode(',', $escaped) . "\r\n");
        };

        if (empty($boards)) {
            $writeCsvRow($output, ['marca', 'referencia', 'descrição', 'quantidade']);
        }

        foreach ($boards as $index => $board) {
            if ($index > 0) {
                $writeCsvRow($output, ['', '', '', '']);
            }

            $writeCsvRow($output, ['Quadro: ' . ($board['board_name'] ?? ''), '', '', '']);
            $writeCsvRow($output, ['marca', 'referencia', 'descrição', 'quantidade']);

            foreach (($board['items'] ?? []) as $item) {
                $writeCsvRow($output, [
                    $item['marca'] ?? '',
                    $item['referencia'] ?? '',
                    $item['descricao'] ?? '',
                    $item['quantity'] ?? 0
                ]);
            }
        }

        fclose($output);
        exit;
    }
}

<?php
// index.php - O Front Controller (Roteador) do Enge-Quadro

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/src/Controllers/LoginController.php';
require_once __DIR__ . '/src/Controllers/HomeController.php';
require_once __DIR__ . '/src/Controllers/ProjectController.php';
require_once __DIR__ . '/src/Controllers/MaterialSurveyController.php';
require_once __DIR__ . '/src/Controllers/EstimateController.php';
require_once __DIR__ . '/src/Controllers/EquivalenciaController.php';
require_once __DIR__ . '/src/DAO/RoleDAO.php';

$route = $_SERVER['REQUEST_URI'];
$basePath = '/enge-quadro';

$route = str_replace($basePath, '', $route);
$route = parse_url($route, PHP_URL_PATH);

switch ($route) {
    case '/':
    case '/home':
        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: ' . $basePath . '/login');
            exit;
        }
        $homeController = new HomeController();
        $homeController->index();
        break;

    case '/login':
        $loginController = new LoginController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $loginController->login();
        } else {
            $loginController->showLogin();
        }
        break;

    case '/logout':
        $loginController = new LoginController();
        $loginController->logout();
        break;

    case '/recover-password':
        $loginController = new LoginController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = $_POST['action'] ?? 'send_code';
            if ($action === 'verify_code') {
                $loginController->verifyPasswordResetCode();
            } elseif ($action === 'reset_password') {
                $loginController->resetPasswordWithCode();
            } else {
                $loginController->sendPasswordResetCode();
            }
        } else {
            $loginController->showRecoverPassword();
        }
        break;

    case '/profile/change-password':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . $basePath . '/profile');
            exit;
        }
        $loginController = new LoginController();
        $loginController->changePassword();
        break;

    case '/profile/validate-password':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            exit;
        }
        $loginController = new LoginController();
        $loginController->validateCurrentPassword();
        break;

    case '/library':
        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: ' . $basePath . '/login');
            exit;
        }
        require_once __DIR__ . '/src/Views/library.php';
        break;

    case '/admin-panel':
        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: ' . $basePath . '/login');
            exit;
        }
        if (isset($_SESSION['user_id'])) {
            $roleDAO = new RoleDAO();
            if (!$roleDAO->userCanAccess($_SESSION['user_id'], '/admin-panel')) {
                http_response_code(403);
                echo "Acesso negado.";
                exit;
            }
        }
        require_once __DIR__ . '/src/Views/adminPainel.php';
        break;

    case '/settings':
    case '/profile':
        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: ' . $basePath . '/login');
            exit;
        }
        require_once __DIR__ . '/src/Views/profile.php';
        break;

    case '/electrical-diagram':
    case '/electricalDiagram':
        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: ' . $basePath . '/login');
            exit;
        }
        require_once __DIR__ . '/src/Views/electricalDiagram.php';
        break;

    case '/layout':
        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: ' . $basePath . '/login');
            exit;
        }
        require_once __DIR__ . '/src/Views/layout.php';
        break;

    case '/equivalencia':
        $equivalenciaController = new EquivalenciaController();
        $equivalenciaController->index();
        break;

    case '/estimate':
        $estimateController = new EstimateController();
        $estimateController->index();
        break;

    case '/estimate/export-materials':
        $estimateController = new EstimateController();
        $estimateController->exportMaterials();
        break;

    case '/material-survey':
    case '/materialSurvey':
        if (!isset($_SESSION['user_id']) && !isset($_COOKIE['enge_quadro_login'])) {
            header('Location: ' . $basePath . '/login');
            exit;
        }

        if (!isset($_GET['project_id'])) {
            $projectDAO = new ProjectDAO();
            $projects = $projectDAO->getAllProjects();

            if (!empty($projects)) {
                header('Location: ' . $basePath . '/project/material-survey?project_id=' . intval($projects[0]['id']));
                exit;
            }

            header('Location: ' . $basePath . '/home');
            exit;
        }

        $materialSurveyController = new MaterialSurveyController();
        $materialSurveyController->materialSurvey();
        break;

    case '/projects/create':
        $projectController = new ProjectController();
        $projectController->store();
        break;

    case '/projects/delete':
        $projectController = new ProjectController();
        $projectController->delete();
        break;

    case '/project/material-survey':
        $materialSurveyController = new MaterialSurveyController();
        $materialSurveyController->materialSurvey();
        break;

    case '/boards/create':
        $materialSurveyController = new MaterialSurveyController();
        $materialSurveyController->createBoard();
        break;

    case '/boards/delete':
        $materialSurveyController = new MaterialSurveyController();
        $materialSurveyController->deleteBoard();
        break;

    default:
        http_response_code(404);
        echo "Pagina nao encontrada.";
        break;
}
